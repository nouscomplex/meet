// ============================================================
// NOUS COMPLEX ORBIT — Application Logic
// ============================================================

(function() {
  "use strict";

  // ============================================================
  // 0. THEME (applied before login too)
  // ============================================================
  try {
    if (localStorage.getItem('orbit-theme') === 'dark') {
      document.body.classList.add('theme-dark');
    }
  } catch (e) { /* localStorage unavailable */ }

  // ============================================================
  // 0b. VIEWPORT HEIGHT (mobile keyboard fix)
  // ============================================================
  function setAppHeight() {
    const vv = window.visualViewport;
    const h = vv ? vv.height : window.innerHeight;
    document.documentElement.style.setProperty('--app-height', h + 'px');
  }
  setAppHeight();
  window.addEventListener('resize', setAppHeight);
  window.addEventListener('orientationchange', setAppHeight);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', setAppHeight);
    window.visualViewport.addEventListener('scroll', setAppHeight);
  }

  // ============================================================
  // 1. LOAD CONFIGURATION
  // ============================================================
  const CONFIG = window.CONFIG;

  if (!CONFIG) {
    console.error('❌ Config not loaded! Please include config.js');
    const loader = document.getElementById('appLoading');
    const authCardEl = document.getElementById('authCard');
    if (loader) loader.classList.add('hidden');
    if (authCardEl) authCardEl.classList.remove('hidden');
    alert('Configuration file not found. Please check your setup.');
    return;
  }

  console.log(`🏫 ${CONFIG.BRANDING.NAME} v${CONFIG.BRANDING.VERSION}`);
  console.log(`🔧 Environment: ${CONFIG.ENV}`);

  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  } else {
    console.warn('pdf.js failed to load — shared PDFs will fall back to a plain file icon (no page preview).');
  }

  // ============================================================
  // 2. SUPABASE CLIENT
  // ============================================================
  const supabase = window.supabase.createClient(
    CONFIG.SUPABASE.URL,
    CONFIG.SUPABASE.ANON_KEY
  );

  const adminAuthClient = window.supabase.createClient(
    CONFIG.SUPABASE.URL,
    CONFIG.SUPABASE.ANON_KEY,
    {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false,
        storageKey: 'orbit-admin-auth-noop',
      }
    }
  );

  supabase.auth.onAuthStateChange((event) => {
    if (event === 'SIGNED_OUT' && state.currentUser) {
      forceSignOut('Signed Out Successfully');
    }
  });

  // ============================================================
  // 3. APPLICATION STATE
  // ============================================================
  const state = {
    currentUser: null,
    currentChannel: null,
    // FIX: see isChatDetailVisible() and selectChannel() below — tracks
    // whether state.currentChannel got there because the user actually
    // clicked/tapped it, versus the app silently defaulting to the first
    // channel in the list on load (see renderChannels()). Read-receipt and
    // unread-badge logic should only fire for the former.
    channelExplicitlyOpened: false,
    currentMembers: [],
    statuses: [],
    messages: [],
    channelPreviews: {},
    isAdmin: false,
    isTeacher: false,
    videoActive: false,
    // FIX: root cause of "user can't see the buttons for minimizing/
    // maximizing in live meeting so they can text in group when needed" —
    // there was no minimized state at all; #videoContainer was always
    // either full-screen or fully hidden (see closeLiveSession(), which
    // tears down videoIframe.src entirely). This flag tracks the new
    // in-between state — call still connected, panel shrunk to a corner
    // pip — toggled by setVideoMinimized() below and reflected in the DOM
    // via the .video-panel-minimized class (styles.css).
    videoMinimized: false,
    progressInterval: null,
    messagesSubscription: null,
    replyingTo: null,
    unreadByChannel: {},
    roleCache: {},
    displayNameCache: {},
    onlineUsers: new Set(),
    currentTab: 'chats',
    screenReturn: 'chats',
    currentScreen: 'chats',
    cachedMessages: {},
    inactivityTimer: null,
    connectionWatchdog: null,
    INACTIVITY_TIMEOUT: 300000,
    isChannelActive: false,
    isTabFocused: true,
    tabChannel: null,
    isRefreshing: false,
    isMerging: false,
    messageReads: new Map(),
    readsSubscription: null,
    statusViews: new Map(),
    statusViewsSubscription: null,
    statusesSubscription: null,
    activeLightbox: null,
    sharedMediaUrls: [],
    // FIX: "can't see unloaded media of group in shared media section" —
    // see the loadSharedMedia()/renderSharedPhotos()/renderSharedVideos()
    // FIX comments further down for the full explanation. These hold the
    // channel's media fetched directly from the DB, independent of
    // whatever page of chat history happens to be scrolled into
    // state.messages right now.
    sharedPhotoMessages: [],
    sharedVideoMessages: [],
    sharedMediaChannelId: null,
    myMemberships: new Map(),
    sessionWatchdog: null,
    myUserRoleId: null,
    currentSchedule: null,
    activeCallScheduleId: null,
    lastTypingBroadcastAt: 0,
    // FIX: "load older messages" pagination support.
    // hasOlderMessages: true when the DB has messages older than the
    // earliest one currently in state.messages — a "Load older" button is
    // shown at the top of the chat when this is true.
    // oldestLoadedTimestamp: the created_at of the oldest message in
    // state.messages, used as the exclusive upper bound when fetching the
    // previous page.
    hasOlderMessages: false,
    oldestLoadedTimestamp: null,
    // FIX: needed for the attendance report's "staying duration" —
    // see joinLiveClass()/closeLiveSession(). The id of the attendance
    // row created when THIS person joined their current call, the
    // moment they joined it, and the scheduled session's own duration
    // (captured at join time so it can't drift if state.currentSchedule
    // changes later from navigating elsewhere while the call is
    // minimized) — used to cap the recorded duration at closeLiveSession().
    activeAttendanceRowId: null,
    activeAttendanceJoinedAt: null,
    activeAttendanceScheduleDurationMinutes: null,
  };

  // ============================================================
  // 4. DOM REFS
  // ============================================================
  const $ = (id) => document.getElementById(id);

  const DOM = {
    appLoading: $('appLoading'),
    authCard: $('authCard'),
    dashboard: $('dashboard'),
    usernameInput: $('usernameInput'),
    passwordInput: $('passwordInput'),
    loginBtn: $('loginBtn'),
    authError: $('authError'),
    authErrorText: $('authErrorText'),
    authLogo: $('authLogo'),
    sidebarLogo: $('sidebarLogo'),

    screenChats: $('screenChats'),
    screenUpdates: $('screenUpdates'),
    screenSettings: $('screenSettings'),
    screenChatDetail: $('screenChatDetail'),
    screenMembers: $('screenMembers'),
    screenProfile: $('screenProfile'),
    bottomNav: $('bottomNav'),
    navChatsBadge: $('navChatsBadge'),
    navUpdatesBadge: $('navUpdatesBadge'),

    chatSearchInput: $('chatSearchInput'),
    channelList: $('channelList'),
    brandHeader: $('brandHeader'),
    channelSelectHeader: $('channelSelectHeader'),
    channelSelectCloseBtn: $('channelSelectCloseBtn'),
    channelSelectCount: $('channelSelectCount'),
    channelSelectRenameBtn: $('channelSelectRenameBtn'),
    channelSelectRecordingsBtn: $('channelSelectRecordingsBtn'),
    channelSelectDeleteBtn: $('channelSelectDeleteBtn'),

    recordingsModal: $('recordingsModal'),
    closeRecordingsModal: $('closeRecordingsModal'),
    recordingsModalChannelName: $('recordingsModalChannelName'),
    recordingsListContainer: $('recordingsListContainer'),

    userBadge: $('userBadge'),
    updatesScreenHeader: $('updatesScreenHeader'),
    statusSelectHeader: $('statusSelectHeader'),
    statusSelectCloseBtn: $('statusSelectCloseBtn'),
    statusSelectCount: $('statusSelectCount'),
    statusSelectInfoBtn: $('statusSelectInfoBtn'),
    statusSelectDeleteBtn: $('statusSelectDeleteBtn'),
    statusTray: $('statusTray'),
    statusPlaceholder: $('statusPlaceholder'),
    statusAddBtn: $('statusAddBtn'),
    postStatusBtn: $('postStatusBtn'),
    postStatusFab: $('postStatusFab'),
    backFromUpdates: $('backFromUpdates'),

    settingsAvatar: $('settingsAvatar'),
    settingsName: $('settingsName'),
    settingsEmail: $('settingsEmail'),
    settingsDisplayName: $('settingsDisplayName'),
    notifToggle: $('notifToggle'),
    darkToggle: $('darkToggle'),
    adminSettingsCard: $('adminSettingsCard'),
    createChannelBtn: $('createChannelBtn'),
    viewCalendarBtn: $('viewCalendarBtn'),
    viewAttendanceReportBtn: $('viewAttendanceReportBtn'),
    signOutBtn: $('signOutBtn'),

    screenCalendar: $('screenCalendar'),
    backFromCalendar: $('backFromCalendar'),
    calendarList: $('calendarList'),

    screenAttendance: $('screenAttendance'),
    backFromAttendance: $('backFromAttendance'),
    attendanceReportTypeSelect: $('attendanceReportTypeSelect'),
    attendanceGroupSelect: $('attendanceGroupSelect'),
    attendanceStudentFieldWrap: $('attendanceStudentFieldWrap'),
    attendanceStudentSelect: $('attendanceStudentSelect'),
    attendanceFromDateInput: $('attendanceFromDateInput'),
    attendanceToDateInput: $('attendanceToDateInput'),
    generateAttendanceReportBtn: $('generateAttendanceReportBtn'),
    attendanceReportEmpty: $('attendanceReportEmpty'),
    attendanceReportResults: $('attendanceReportResults'),
    attendanceReportSummary: $('attendanceReportSummary'),
    attendanceReportTable: $('attendanceReportTable'),
    downloadAttendancePdfBtn: $('downloadAttendancePdfBtn'),

    adminCreateUserCard: $('adminCreateUserCard'),
    adminUserManagementCard: $('adminUserManagementCard'),
    addUserToggleBtn: $('addUserToggleBtn'),
    manageUsersToggleBtn: $('manageUsersToggleBtn'),
    newUserUsername: $('newUserUsername'),
    newUserDisplayName: $('newUserDisplayName'),
    newUserRole: $('newUserRole'),
    newUserPassword: $('newUserPassword'),
    generatePasswordBtn: $('generatePasswordBtn'),
    createUserBtn: $('createUserBtn'),
    
    manageUserSearch: $('manageUserSearch'),
    loadUserBtn: $('loadUserBtn'),
    registeredUsersListWrap: $('registeredUsersListWrap'),
    registeredUsersListView: $('registeredUsersListView'),
    userEditForm: $('userEditForm'),
    closeUserEditBtn: $('closeUserEditBtn'),
    editUsername: $('editUsername'),
    editDisplayName: $('editDisplayName'),
    editNewUsername: $('editNewUsername'),
    editPassword: $('editPassword'),
    editRole: $('editRole'),
    manageUserGroupsBtn: $('manageUserGroupsBtn'),
    updateUserBtn: $('updateUserBtn'),
    deleteUserBtn: $('deleteUserBtn'),

    backFromChat: $('backFromChat'),
    chatDetailHeader: document.querySelector('.chat-detail-header'),
    chatDetailTitleBtn: $('chatDetailTitleBtn'),
    chatDetailName: $('chatDetailName'),
    chatDetailSub: $('chatDetailSub'),
    msgSelectHeader: $('msgSelectHeader'),
    msgSelectCloseBtn: $('msgSelectCloseBtn'),
    msgSelectCount: $('msgSelectCount'),
    msgSelectReplyBtn: $('msgSelectReplyBtn'),
    msgSelectForwardBtn: $('msgSelectForwardBtn'),
    msgSelectCopyBtn: $('msgSelectCopyBtn'),
    msgSelectDeleteBtn: $('msgSelectDeleteBtn'),
    msgSelectInfoBtn: $('msgSelectInfoBtn'),
    joinLiveBtn: $('joinLiveBtn'),
    liveBtnText: $('liveBtnText'),
    scheduleBanner: $('scheduleBanner'),
    scheduleBannerText: $('scheduleBannerText'),
    chatContainer: $('chatContainer'),
    chatMessages: $('chatMessages'),
    fileUploadStatus: $('fileUploadStatus'),
    replyPreview: $('replyPreview'),
    replyPreviewAuthor: $('replyPreviewAuthor'),
    replyPreviewText: $('replyPreviewText'),
    replyPreviewCancel: $('replyPreviewCancel'),
    filePreview: $('filePreview'),
    filePreviewName: $('filePreviewName'),
    filePreviewRemove: $('filePreviewRemove'),
    fileInput: $('fileInput'),
    messageInput: $('messageInput'),
    sendMsgBtn: $('sendMsgBtn'),
    videoContainer: $('videoContainer'),
    videoIframe: $('videoIframe'),
    videoToolbar: $('videoToolbar'),
    endLiveSessionBtn: $('endLiveSessionBtn'),
    returnToChatBtn: $('returnToChatBtn'),
    minimizeVideoBtn: $('minimizeVideoBtn'),
    videoResizeHandle: $('videoResizeHandle'),

    backFromMembers: $('backFromMembers'),
    memberSearchInput: $('memberSearchInput'),
    adminAddMemberRow: $('adminAddMemberRow'),
    assignStudentInput: $('assignStudentInput'),
    registeredUsersList: $('registeredUsersList'),
    assignRoleSelect: $('assignRoleSelect'),
    assignStudentBtn: $('assignStudentBtn'),
    channelMembersList: $('channelMembersList'),
    alphaIndex: $('alphaIndex'),

    backFromProfile: $('backFromProfile'),
    profileChannelName: $('profileChannelName'),
    profileChannelMeta: $('profileChannelMeta'),
    profileChannelDesc: $('profileChannelDesc'),
    profileMembersBtn: $('profileMembersBtn'),
    profileSeeAllPhotos: $('profileSeeAllPhotos'),
    sharedPhotosGrid: $('sharedPhotosGrid'),
    profileSeeAllVideos: $('profileSeeAllVideos'),
    sharedVideosGrid: $('sharedVideosGrid'),
    adminProfileSchedule: $('adminProfileSchedule'),
    scheduleTeacherInput: $('scheduleTeacherInput'),
    scheduleTeacherSelect: $('scheduleTeacherSelect'),
    scheduleTeacherSingleLabel: $('scheduleTeacherSingleLabel'),
    scheduleRecordCheckbox: $('scheduleRecordCheckbox'),
    scheduleCalPrevBtn: $('scheduleCalPrevBtn'),
    scheduleCalNextBtn: $('scheduleCalNextBtn'),
    scheduleCalMonthLabel: $('scheduleCalMonthLabel'),
    scheduleCalGrid: $('scheduleCalGrid'),
    scheduleSelectedDates: $('scheduleSelectedDates'),
    scheduleStartTimeInput: $('scheduleStartTimeInput'),
    scheduleDurationInput: $('scheduleDurationInput'),
    scheduleEndPreview: $('scheduleEndPreview'),
    scheduleSameTimeCheckbox: $('scheduleSameTimeCheckbox'),
    schedulePerDateList: $('schedulePerDateList'),
    setScheduleBtn: $('setScheduleBtn'),
    groupScheduleList: $('groupScheduleList'),
    
    channelDescEditBtn: $('channelDescEditBtn'),
    adminDescEdit: $('adminDescEdit'),
    descFormatToolbar: $('descFormatToolbar'),
    channelDescInput: $('channelDescInput'),
    updateDescBtn: $('updateDescBtn'),
    cancelDescEditBtn: $('cancelDescEditBtn'),

    statusModal: $('statusModal'),
    statusSegments: $('statusSegments'),
    statusProgress: $('statusProgress'),
    closeStatusModal: $('closeStatusModal'),
    statusViewerAvatar: $('statusViewerAvatar'),
    statusModalTitle: $('statusModalTitle'),
    statusModalTime: $('statusModalTime'),
    statusModalMedia: $('statusModalMedia'),
    statusModalContent: $('statusModalContent'),
    statusLinkPreview: $('statusLinkPreview'),
    statusViewerBody: $('statusViewerBody'),
    statusPauseBtn: $('statusPauseBtn'),
    // FIX: "load older messages" pagination — small loading-circle
    // indicator injected at the top of #chatMessages by
    // renderLoadOlderIndicator() below, shown only while a fetch is in
    // flight; referenced here so the rest of the code can show/hide it
    // without querying the DOM each time.
    loadOlderBtn: null,
  };

  // FIX: "unselecting a channel shows the last channel's chat history
  // instead of the empty screen" — renderMessages() overwrites
  // #chatMessages' innerHTML with real message bubbles the first time a
  // channel is opened, permanently destroying the static ".chat-welcome"
  // placeholder markup that ships in index.html. deselectChannel() only
  // toggled the `.no-chat` CSS class back on, which re-centers whatever
  // is currently inside #chatMessages — but by then that's stale message
  // bubbles, not the welcome screen, so the old chat stayed visible.
  // Snapshot the original welcome markup here, at script init, before
  // any render has had a chance to replace it, so it can be restored
  // on demand.
  const CHAT_WELCOME_HTML = DOM.chatMessages ? DOM.chatMessages.innerHTML : '';

  // ============================================================
  // 5. LOGO HANDLING
  // ============================================================
  function setupLogos() {
    const logoPath = CONFIG.BRANDING.LOGO.PATH;
    const altText = CONFIG.BRANDING.LOGO.ALT;

    [DOM.authLogo, DOM.sidebarLogo].forEach((el) => {
      if (!el) return;
      el.src = logoPath;
      el.alt = altText;
      el.addEventListener('error', function onErr() {
        this.removeEventListener('error', onErr);
        this.style.display = 'none';
        const fallback = document.createElement('i');
        fallback.className = 'fas fa-graduation-cap';
        fallback.style.cssText = 'color:var(--accent); font-size:1.4rem; display:flex; align-items:center; justify-content:center;';
        this.parentNode.insertBefore(fallback, this);
      });
    });
  }

  // ============================================================
  // 5b. NOTIFICATION SOUND & VISUAL NOTIFICATIONS
  // ============================================================
  let audioCtx = null;

  function unlockAudioContext() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
    } catch (e) { /* ignore — playNotifySound() will retry and log if needed */ }
    ['click', 'keydown', 'touchstart'].forEach((evt) => window.removeEventListener(evt, unlockAudioContext));
  }
  ['click', 'keydown', 'touchstart'].forEach((evt) => window.addEventListener(evt, unlockAudioContext, { once: false }));

  // FIX: senderName used to read state.currentUser (the person who's
  // signed in and receiving the notification) instead of the message's
  // actual author — every notification announced you talking to yourself.
  // channelName used to read state.currentChannel unconditionally, which
  // only ever matched the channel the notification was actually about by
  // coincidence; now that playNotifySound() is called from
  // handleGlobalMessageInsert() for any channel (see the FIX comment
  // there), that mismatch would show every other channel's notification
  // labeled with whatever channel happens to be open. Both now come from
  // the message/channel that was actually passed in.
  function playNotifySound(msg, channel) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();

      const now = audioCtx.currentTime;
      [[880, 0], [1175, 0.09]].forEach(([freq, delay]) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, now + delay);
        gain.gain.exponentialRampToValueAtTime(0.18, now + delay + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + 0.16);
        osc.connect(gain).connect(audioCtx.destination);
        osc.start(now + delay);
        osc.stop(now + delay + 0.18);
      });
    } catch (e) {
      console.warn('Notification sound unavailable:', e);
    }

    try {
      if (typeof Notification !== 'undefined' && 
          Notification.permission === 'granted' && 
          document.hidden) {
        const senderName = msg && msg.username ? getDisplayName(msg.username) : 'Someone';
        const channelName = channel?.name || 'Class';
        
        const notification = new Notification(`💬 ${senderName} in ${channelName}`, {
          body: 'New message! Tap to open.',
          icon: CONFIG.BRANDING.LOGO.PATH || '/favicon.ico',
          badge: '/favicon.ico',
          tag: 'new-message-' + Date.now(),
          requireInteraction: true,
        });
        
        setTimeout(() => {
          notification.close();
        }, 10000);
        
        notification.onclick = function() {
          window.focus();
          notification.close();
        };
      }
    } catch (e) {
      console.warn('Could not show notification:', e);
    }
  }

  // ============================================================
  // 6. UTILITY FUNCTIONS
  // ============================================================
  function getRoleFromUsername(username) {
    if (!username) return CONFIG.AUTH.ROLES.STUDENT;
    const key = username.toLowerCase();

    if (state.roleCache[key]) return state.roleCache[key];

    console.warn(`No role found in role cache for "${username}" — defaulting to student.`);
    return CONFIG.AUTH.ROLES.STUDENT;
  }

  function getDisplayName(username) {
    if (!username) return username;
    const key = username.toLowerCase();
    return state.displayNameCache[key] || username;
  }

  async function getUserRoles(username) {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('username', username.toLowerCase());
    
    if (error || !data || data.length === 0) {
      return null;
    }
    return data.map(row => row.role);
  }

  async function loadRoleCache() {
    const { data, error } = await supabase.from('user_roles').select('username, role, display_name');
    if (error) {
      console.warn('Role cache unavailable:', error);
      return;
    }
    (data || []).forEach((row) => {
      const key = row.username.toLowerCase();
      state.roleCache[key] = row.role;
      if (row.display_name) {
        state.displayNameCache[key] = row.display_name;
      }
    });
    populateRegisteredUsersDatalist();
  }

  function populateRegisteredUsersDatalist() {
    if (!DOM.registeredUsersList) return;
    DOM.registeredUsersList.innerHTML = Object.keys(state.roleCache)
      .sort()
      .map((u) => `<option value="${escapeHtml(u)}"></option>`)
      .join('');
  }

  function roleKey(username) {
    const role = getRoleFromUsername(username);
    if (role === CONFIG.AUTH.ROLES.ADMIN) return 'admin';
    if (role === CONFIG.AUTH.ROLES.TEACHER) return 'teacher';
    return 'student';
  }

  // FIX: "make nous complex logo a group profile logo and teachers and
  // students profile logo" — the app previously had no photo assets at
  // all for avatars, just a colored circle with a role-tinted gradient and
  // the person/group's first initial (see avatar-admin/-teacher/-student
  // below in styles.css). This now doubles as: every group's profile photo
  // (channelAvatarHtml() below, plus the bigger picture at the top of the
  // group Profile screen — see #profileChannelLogo in index.html, set
  // directly in markup since it's the same image for every group, no
  // per-channel JS needed), and the default photo for every account role —
  // admin, teacher, and student (avatarHtml()/setAvatarEl() below, gated by
  // isLogoAvatarRole()) — fully consistent branding everywhere an avatar
  // shows up.
  //
  // FIX: root cause of "group profile and user profile logo is blur" was the
  // old nouscomplex.png being a low-quality/undersized asset — replaced with
  // a tightly-trimmed, high-res (1087x516) export of the real logo.
  //
  // FIX: "use full logo not just bulb" — briefly swapped this to a square
  // crop of just the lightbulb-in-the-O mark (nouscomplex-icon.png) so
  // object-fit: cover wouldn't have to crop the wide wordmark into a circle.
  // Reverted at the user's request: back to the full "NOUS Complex"
  // wordmark (nouscomplex.png). Paired with the object-fit: contain switch
  // in .avatar-img (styles.css) so the whole wordmark is visible,
  // letterboxed inside the circle, rather than cover cropping it down to a
  // sliver.
  const LOGO_AVATAR_IMG_HTML = '<img class="avatar-img" src="nouscomplex.png" alt="" draggable="false">';

  function isLogoAvatarRole(key) {
    // FIX: admin now shows the logo too, at the user's request — every
    // role (admin/teacher/student) and the group itself all show the same
    // Nous Complex logo, fully consistent branding across every avatar in
    // the app.
    return key === 'admin' || key === 'teacher' || key === 'student';
  }

  function avatarHtml(username, size) {
    const key = roleKey(username);
    const displayName = getDisplayName(username);
    const initial = (displayName || '?').charAt(0).toUpperCase();
    const sizeClass = size === 'sm' ? ' sm' : size === 'lg' ? ' lg' : '';
    const online = state.onlineUsers.has((username || '').toLowerCase());
    const content = isLogoAvatarRole(key) ? LOGO_AVATAR_IMG_HTML : initial;
    return `<div class="avatar avatar-${key}${sizeClass}">${content}<span class="avatar-dot${online ? ' online' : ''}"></span></div>`;
  }

  function channelAvatarHtml(ch) {
    // Every group shows the same Nous Complex logo as its profile picture
    // now, so there's no more need for channelColorKey()'s per-channel
    // color-hash background — avatar-group is just a plain white backing
    // circle behind the (already-square) logo image.
    return `<div class="avatar avatar-group">${LOGO_AVATAR_IMG_HTML}</div>`;
  }

  function setAvatarEl(el, username, extraClass) {
    if (!el) return;
    const key = roleKey(username);
    const displayName = getDisplayName(username);
    el.className = `avatar avatar-${key}${extraClass ? ' ' + extraClass : ''}`;
    if (isLogoAvatarRole(key)) {
      el.innerHTML = LOGO_AVATAR_IMG_HTML;
    } else {
      el.textContent = (displayName || '?').charAt(0).toUpperCase();
    }
  }

  function generateEmail(username) {
    return `${username}${CONFIG.AUTH.EMAIL_SUFFIX}`;
  }

  function normalizeUsername(raw) {
    return (raw || '').trim().toLowerCase();
  }

  function generatePassword(length = 10) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let out = '';
    for (let i = 0; i < length; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
  }

  function formatDate(ts) {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  }

  function dayKey(ts) {
    const d = new Date(ts);
    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  }

  function formatDayLabel(ts) {
    const d = new Date(ts);
    const now = new Date();
    const startOfDay = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86400000);
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays > 1 && diffDays < 7) return d.toLocaleDateString([], { weekday: 'long' });
    if (d.getFullYear() === now.getFullYear()) return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
    return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  }

  function buildDayDivider(dk, label) {
    const el = document.createElement('div');
    el.className = 'day-divider';
    el.dataset.day = dk;
    el.innerHTML = `<span class="day-divider-label">${escapeHtml(label)}</span>`;
    return el;
  }

  function formatFullDate(ts) {
    return new Date(ts).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: true });
  }

  function formatTimeAgo(ts) {
    if (!ts) return '';
    const diffMs = Date.now() - new Date(ts).getTime();
    const min = Math.floor(diffMs / 60000);
    if (min < 1) return 'now';
    if (min < 60) return `${min}m ago`;
    const hr = Math.floor(min / 60);
    if (hr < 24) return `${hr}h ago`;
    const day = Math.floor(hr / 24);
    if (day < 7) return `${day}d ago`;
    return new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' });
  }

  function truncate(str, n = 20) {
    if (!str) return '';
    return str.length > n ? str.substr(0, n) + '…' : str;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str ?? '';
    return div.innerHTML;
  }

  // ============================================================
  // LINK DETECTION (chat messages + updates)
  // ============================================================
  const COMMON_TLDS = 'com|net|org|io|co|dev|app|edu|gov|mil|info|biz|me|xyz|ai|tv|so|gg|pk|in|uk|us|ca|au|de|fr|jp|nl|ru|br|es|it|ch|se|no|dk|fi|pl|tech|online|store|site|shop|live|news|blog';
  const URL_REGEX = new RegExp(
    '\\b(' +
      'https?://[^\\s<>"\']+' +
      '|www\\.[a-z0-9-]+(?:\\.[a-z0-9-]+)*(?:/[^\\s<>"\']*)?' +
      `|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)*\\.(?:${COMMON_TLDS})(?:/[^\\s<>"\']*)?` +
    ')\\b',
    'gi'
  );
  const TRAILING_PUNCT = /[.,:;!?'")\]]+$/;

  function normalizeUrlHref(raw) {
    return /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
  }

  function linkifyText(text) {
    if (!text) return '';
    const parts = String(text).split(URL_REGEX);
    let html = '';
    for (let i = 0; i < parts.length; i++) {
      if (i % 2 === 1) {
        let raw = parts[i];
        const precededByAt = i > 0 && /@$/.test(parts[i - 1]);
        if (precededByAt) { html += escapeHtml(raw); continue; }
        let trail = '';
        const m = raw.match(TRAILING_PUNCT);
        if (m) {
          trail = m[0];
          raw = raw.slice(0, -trail.length);
        }
        if (!raw) { html += escapeHtml(parts[i]); continue; }
        const safeHref = escapeHtml(normalizeUrlHref(raw));
        const safeText = escapeHtml(raw);
        html += `<a href="${safeHref}" rel="noopener" class="msg-link">${safeText}</a>${escapeHtml(trail)}`;
      } else {
        html += escapeHtml(parts[i]);
      }
    }
    return html;
  }

  // ============================================================
  // TEXT FORMATTING TOOLBAR (group description + status updates)
  // WhatsApp-style inline markers, applied on top of linkifyText()'s
  // already-escaped HTML: *bold*, _italic_, ~strikethrough~, ```mono```.
  // Matches never cross a '<'/'>' so they can't reach into an <a> tag's
  // attributes or straddle two tags, and lookaround boundaries keep them
  // from firing mid-word (e.g. snake_case_name, 3*4) — only markers a
  // toolbar button actually inserted, or someone typed on purpose with
  // clear boundaries, get rendered.
  // ============================================================
  function applyInlineFormatting(html) {
    if (!html) return html;
    // Pull out ```mono``` spans first and stash their contents behind a
    // placeholder so a marker typed *inside* one (e.g. ```*raw*```) stays
    // literal instead of also being turned into <strong> etc. below —
    // matches how inline code normally behaves in markdown-style syntax.
    const monoStore = [];
    html = html.replace(/```([^`<>\n]+?)```/g, (_m, inner) => {
      monoStore.push(inner);
      return `\u0001MONO${monoStore.length - 1}\u0001`;
    });
    html = html.replace(/(?<![\w*])\*([^*<>\n]+?)\*(?![\w*])/g, '<strong>$1</strong>');
    html = html.replace(/(?<![\w_])_([^_<>\n]+?)_(?![\w_])/g, '<em>$1</em>');
    html = html.replace(/(?<![\w~])~([^~<>\n]+?)~(?![\w~])/g, '<s>$1</s>');
    html = html.replace(/\u0001MONO(\d+)\u0001/g, (_m, idx) => `<code class="msg-mono">${monoStore[Number(idx)]}</code>`);
    return html;
  }

  // ============================================================
  // RICH TEXT EDITOR (group description + status updates)
  // #channelDescInput and #statusComposeText are `contenteditable` <div>s
  // (not <input>/<textarea>) so bold/italic/strike/mono and alignment show
  // as REAL formatting while typing, not raw *marker* characters — that
  // was the whole point of switching over from the old plain-text +
  // separate-preview-box version.
  //
  // Storage format: still plain text in the `channels.description` /
  // `statuses.content` columns (no schema change) — one line per editor
  // line, each optionally prefixed with a `[[align:center]]` or
  // `[[align:right]]` directive (left is the default, no prefix). That's
  // what editorToMarkerValue()/renderRichBlocks() convert to and from.
  // Alignment is stored PER LINE, not once for the whole field, because
  // clicking Align only affects whichever line(s) the current
  // selection/cursor is actually in — same as Word/Google Docs, and what
  // was actually asked for (align was previously whole-field only).
  // ============================================================

  const LINE_ALIGN_RE = /^\[\[align:(center|right)\]\]/;

  // Renders saved marker text into the *display* HTML used by the actual
  // group-description and status views (#profileChannelDesc,
  // #statusModalContent — both plain <div>s now, not <p>, since each line
  // becomes its own block-level <div>). Unlike the editor, this DOES
  // linkify URLs, since it's read-only rendered output, not something
  // being typed into.
  function renderRichBlocks(text) {
    if (!text) return '';
    return String(text)
      .split('\n')
      .map((line) => {
        const m = LINE_ALIGN_RE.exec(line);
        const align = m ? m[1] : 'left';
        const body = m ? line.slice(m[0].length) : line;
        const html = applyInlineFormatting(linkifyText(body));
        // Always explicit, never omitted — .profile-card and
        // .status-viewer-body both default to text-align: center for
        // their own reasons (card heading, full-bleed status text), and
        // text-align is inherited, so leaving 'left' unset here would
        // silently inherit that center instead of actually showing left.
        return `<div style="text-align:${align};">${html || '<br>'}</div>`;
      })
      .join('');
  }

  // Strips a leading per-line align directive from the *start* of a raw
  // string — used only for the truncated single-line list-row previews
  // (status "Updates" list), so they don't show "[[align:center]]" as
  // literal text. Only the first line's directive; a truncated preview
  // that happens to reach a second line still shows that line's own
  // directive raw, which is an acceptable, pre-existing limitation of a
  // plain-text truncated snippet (inline *bold* markers show raw there
  // too — it's not the full rich render).
  function stripAlignPrefix(text) {
    return text ? text.replace(LINE_ALIGN_RE, '') : text;
  }

  // Converts one line's escaped body text into the initial editor HTML for
  // that line (used only when first populating the editor from a saved
  // value — see populateRichEditor()). Reuses applyInlineFormatting() so a
  // saved *bold*/_italic_/~strike~/```mono``` marker shows as real
  // formatting the moment the editor opens, not just after re-typing it.
  // Deliberately skips linkifyText() — auto-turning a URL into a live,
  // unfocusable <a> while someone is still composing text around it would
  // be more confusing than helpful; that only happens in the final
  // rendered view (renderRichBlocks() above).
  function inlineHtmlForEditorLine(body) {
    return applyInlineFormatting(escapeHtml(body));
  }

  // Clears the editor and rebuilds it as one <div> per line from a saved
  // marker-text value (or leaves it completely empty for '' — so the
  // :empty CSS placeholder shows). Every line gets an EXPLICIT
  // style.textAlign (defaulting to 'left'), same reasoning as
  // renderRichBlocks() above: both #channelDescInput (inside .profile-card)
  // and #statusComposeText (inside .modal-card) sit under ancestors that
  // could hand down an inherited alignment if left unset.
  function populateRichEditor(editorEl, text) {
    if (!editorEl) return;
    editorEl.innerHTML = '';
    if (text) {
      String(text).split('\n').forEach((line) => {
        const m = LINE_ALIGN_RE.exec(line);
        const align = m ? m[1] : 'left';
        const body = m ? line.slice(m[0].length) : line;
        const div = document.createElement('div');
        div.style.textAlign = align;
        div.innerHTML = inlineHtmlForEditorLine(body) || '<br>';
        editorEl.appendChild(div);
      });
    }
    editorEl.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Serializes one inline DOM node (text, <b>/<strong>, <i>/<em>,
  // <strike>/<s>/<del>, <code>, <br>, or a stray nested block from pasted
  // content) back into marker text. The counterpart to
  // inlineHtmlForEditorLine()/applyInlineFormatting().
  function inlineNodeToMarkerText(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      // Strip zero-width spaces used internally to give an empty
      // wrapSelectionInEditor() wrapper somewhere for the cursor to sit.
      return node.textContent.replace(/\u200b/g, '');
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return '';
    const tag = node.tagName.toLowerCase();
    if (tag === 'br') return '\n';
    const inner = inlineNodesToMarkerText(Array.from(node.childNodes));
    return wrapInlineMarker(tag, inner);
  }
  function inlineNodesToMarkerText(nodeList) {
    return nodeList.map(inlineNodeToMarkerText).join('');
  }

  // tag -> marker character(s) for the inline formatting tags produced by
  // inlineHtmlForEditorLine()/applyInlineFormatting(); anything else (span,
  // div, font, etc. from pasted content) passes its text through unwrapped.
  const INLINE_MARKER_BY_TAG = {
    b: '*', strong: '*',
    i: '_', em: '_',
    strike: '~', s: '~', del: '~',
    code: '```',
  };

  // Wraps `inner` in the marker pair for `tag`, but only when `inner` has
  // real visible text. Clicking a formatting button on an empty/unselected
  // line (or one that's just a line break) leaves behind an empty wrapper
  // like <b><br></b>; since inner would then be the non-empty string '\n',
  // a naive truthiness check treated it as real content and serialized it
  // as a marker pair spanning a newline (e.g. '*\n*'), which later renders
  // as bare '*' characters on their own line. Guard against that here, and
  // — for the rarer case where an inline tag genuinely wraps multiple
  // lines — only wrap the non-blank line segments, since a marker pair can
  // never span a newline (the parser doesn't support that either).
  function wrapInlineMarker(tag, inner) {
    const marker = INLINE_MARKER_BY_TAG[tag];
    if (!marker) return inner;
    if (!inner.replace(/\n/g, '').trim()) return '';
    return inner.split('\n').map((seg) => (seg.trim() ? `${marker}${seg}${marker}` : '')).join('\n');
  }

  // Serializes the whole editor's current DOM back into the plain
  // marker-text format that gets saved to Supabase — the inverse of
  // populateRichEditor(). Each top-level block (line) becomes one line of
  // output, prefixed with its own [[align:...]] directive if it isn't
  // left-aligned.
  // Every top-level child <div> of the editor is already one full line —
  // the block boundary itself IS the line break. When a line is empty (the
  // user pressed Enter to leave a blank row, or populateRichEditor() filled
  // one in), the browser leaves a lone trailing <br> inside that <div> just
  // so it has height and somewhere for the cursor to land — it's a
  // placeholder, not a second, extra line break. Serializing that <br> as
  // '\n' too (on top of the '\n' that already separates this block from
  // the next) doubled every blank line on save. Strip trailing <br>s before
  // serializing a line's content; a <br> that has real content AFTER it
  // (e.g. a genuine forced break from Shift+Enter) is left alone.
  function stripTrailingBrs(nodeList) {
    const out = nodeList.slice();
    while (out.length && out[out.length - 1].nodeType === Node.ELEMENT_NODE && out[out.length - 1].tagName === 'BR') {
      out.pop();
    }
    return out;
  }

  function editorToMarkerValue(editorEl) {
    if (!editorEl) return '';
    const blocks = Array.from(editorEl.children).filter((c) => c.nodeType === 1);
    const lineToText = (block) => {
      const align = block.style.textAlign;
      const text = inlineNodesToMarkerText(stripTrailingBrs(Array.from(block.childNodes)));
      return (align === 'center' || align === 'right') ? `[[align:${align}]]${text}` : text;
    };
    if (!blocks.length) {
      // No block children yet — a single line still living directly in
      // the editor (nothing pressed Enter). Only real browsers that
      // ignore defaultParagraphSeparator hit this; treat the editor
      // itself as that one line.
      return lineToText(editorEl);
    }
    return blocks.map(lineToText).join('\n');
  }

  // Wraps the current selection inside `editorEl` in a new element (used
  // for the Monospace button, which has no native execCommand). With
  // nothing selected, inserts an empty wrapper with a zero-width space so
  // there's somewhere for the cursor to land and start typing inside it.
  function wrapSelectionInEditor(editorEl, tagName, className) {
    editorEl.focus();
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!editorEl.contains(range.commonAncestorContainer)) return;
    const wrapper = document.createElement(tagName);
    if (className) wrapper.className = className;
    if (range.collapsed) {
      wrapper.appendChild(document.createTextNode('\u200b'));
      range.insertNode(wrapper);
      const newRange = document.createRange();
      newRange.setStart(wrapper.firstChild, 1);
      newRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(newRange);
    } else {
      wrapper.appendChild(range.extractContents());
      range.insertNode(wrapper);
      sel.removeAllRanges();
      const newRange = document.createRange();
      newRange.selectNodeContents(wrapper);
      sel.addRange(newRange);
    }
    editorEl.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Returns the top-level line(s) — direct block children of `editorEl` —
  // that the current selection/cursor touches. This is what makes Align
  // apply to only the selected text's line(s) instead of the whole field:
  // Range.intersectsNode() is true for any block the selection overlaps
  // even partially, and for a collapsed (no-selection) range it's true
  // exactly for the single block the caret is currently in — matching how
  // alignment works in Word/Docs (a paragraph-level property, applied to
  // whichever paragraph(s) the cursor/selection is in).
  function getSelectedEditorLines(editorEl, range) {
    const blocks = Array.from(editorEl.children).filter((c) => c.nodeType === 1);
    if (!blocks.length) return [editorEl]; // no lines yet — align the editor itself
    const touched = blocks.filter((block) => range.intersectsNode(block));
    return touched.length ? touched : blocks;
  }

  function applyEditorAlign(editorEl, align) {
    editorEl.focus();
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!editorEl.contains(range.commonAncestorContainer)) return;
    getSelectedEditorLines(editorEl, range).forEach((block) => {
      block.style.textAlign = align;
    });
    editorEl.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Freshly-created lines (Enter inside the editor) come out with no
  // explicit text-align — the browser doesn't copy inline styles from the
  // line they were split off from. Left unset, they'd inherit whatever the
  // editor's ancestor happens to default to (center, for both
  // .profile-card and .modal-card) instead of continuing the alignment of
  // the line they came from. Run after every edit: any block missing an
  // explicit left/center/right picks up whatever the line before it has.
  function normalizeEditorLineAlignment(editorEl) {
    let lastAlign = 'left';
    Array.from(editorEl.children).forEach((block) => {
      if (block.nodeType !== 1) return;
      const current = block.style.textAlign;
      if (current === 'left' || current === 'center' || current === 'right') {
        lastAlign = current;
      } else {
        block.style.textAlign = lastAlign;
      }
    });
  }

  const EDITOR_EXEC_COMMAND = {
    bold: 'bold',
    italic: 'italic',
    strike: 'strikeThrough',
  };

  // Wires up a .format-toolbar's buttons to act on `editorEl` (a
  // contenteditable <div>):
  //  - bold/italic/strike use the browser's native execCommand — still
  //    broadly supported despite the MDN deprecation notice, and buys
  //    native toggle-on-reselect behavior plus Ctrl/Cmd+Z undo support for
  //    free, which a hand-rolled DOM wrap wouldn't get.
  //  - mono has no native command, so it's a manual wrap (no toggle).
  //  - linebreak inserts a soft <br> within the current line (Enter alone
  //    already starts a new line/paragraph natively).
  //  - align-left/center/right realign just the selected line(s) — see
  //    applyEditorAlign() above.
  // Used for both the group description editor (#descFormatToolbar,
  // static markup) and each status composer's toolbar
  // (#statusFormatToolbar, built fresh per modal in openStatusComposer()).
  function initFormatToolbar(toolbarEl, editorEl) {
    if (!toolbarEl || !editorEl || toolbarEl.dataset.formatToolbarBound === '1') return;
    toolbarEl.dataset.formatToolbarBound = '1';

    // Best-effort: keep Enter creating a new <div> per line rather than a
    // <br>, so alignment (a per-<div> property) has a consistent block to
    // attach to. Modern Chrome/Firefox/Safari already default to this: this
    // is a safety net for the rare engine that doesn't, wrapped in
    // try/catch since execCommand can throw/warn in stricter contexts.
    editorEl.addEventListener('focus', () => {
      try { document.execCommand('defaultParagraphSeparator', false, 'div'); } catch (e) { /* ignore */ }
    });
    editorEl.addEventListener('input', () => normalizeEditorLineAlignment(editorEl));

    toolbarEl.querySelectorAll('[data-format]').forEach((btn) => {
      // Prevent the button from stealing focus (and collapsing the
      // selection) before the click handler runs.
      btn.addEventListener('mousedown', (e) => e.preventDefault());
      btn.addEventListener('click', () => {
        const fmt = btn.dataset.format;
        if (fmt === 'linebreak') {
          editorEl.focus();
          document.execCommand('insertHTML', false, '<br>');
          editorEl.dispatchEvent(new Event('input', { bubbles: true }));
          return;
        }
        if (fmt === 'align-left' || fmt === 'align-center' || fmt === 'align-right') {
          applyEditorAlign(editorEl, fmt.slice('align-'.length));
          return;
        }
        if (fmt === 'mono') {
          wrapSelectionInEditor(editorEl, 'code', 'msg-mono');
          return;
        }
        const command = EDITOR_EXEC_COMMAND[fmt];
        if (!command) return;
        editorEl.focus();
        document.execCommand(command);
        editorEl.dispatchEvent(new Event('input', { bubbles: true }));
      });
    });
  }

  function firstUrlIn(text) {
    if (!text) return null;
    const str = String(text);
    URL_REGEX.lastIndex = 0;
    let m;
    while ((m = URL_REGEX.exec(str))) {
      if (m.index > 0 && str[m.index - 1] === '@') continue;
      return normalizeUrlHref(m[0].replace(TRAILING_PUNCT, ''));
    }
    return null;
  }

  let lastOpenedExternalUrl = null;
  let lastOpenedExternalAt = 0;

  function openExternalLink(url) {
    if (!url) return;
    const now = Date.now();
    if (url === lastOpenedExternalUrl && (now - lastOpenedExternalAt) < 800) return;
    lastOpenedExternalUrl = url;
    lastOpenedExternalAt = now;

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function isImageFile(url) {
    return !!url && /\.(png|jpe?g|gif|webp|svg)$/i.test(url.split('?')[0]);
  }

  function isVideoFile(url) {
    return !!url && /\.(mp4|webm|mov|m4v|ogv)$/i.test(url.split('?')[0]);
  }

  function isPdfFile(url) {
    return !!url && /\.pdf$/i.test(url.split('?')[0]);
  }

  // ============================================================
  // CLIENT-SIDE IMAGE COMPRESSION (before upload)
  // ============================================================
  const IMAGE_COMPRESS_MAX_DIMENSION = 1600;
  const IMAGE_COMPRESS_QUALITY = 0.82;
  const IMAGE_COMPRESS_SKIP_UNDER_BYTES = 300 * 1024;

  function isCompressibleImageType(file) {
    return !!file && !!file.type && file.type.startsWith('image/') &&
      file.type !== 'image/gif' && file.type !== 'image/svg+xml';
  }

  function shouldCompressImage(file) {
    return isCompressibleImageType(file) && file.size > IMAGE_COMPRESS_SKIP_UNDER_BYTES;
  }

  function compressImageFile(file) {
    return new Promise((resolve) => {
      if (!shouldCompressImage(file)) { resolve(file); return; }

      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      const cleanupAndResolve = (result) => {
        URL.revokeObjectURL(objectUrl);
        resolve(result);
      };

      img.onload = () => {
        try {
          let { width, height } = img;
          const longestEdge = Math.max(width, height);
          if (longestEdge > IMAGE_COMPRESS_MAX_DIMENSION) {
            const scale = IMAGE_COMPRESS_MAX_DIMENSION / longestEdge;
            width = Math.round(width * scale);
            height = Math.round(height * scale);
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) { cleanupAndResolve(file); return; }
          ctx.drawImage(img, 0, 0, width, height);

          canvas.toBlob((blob) => {
            if (!blob || blob.size >= file.size) { cleanupAndResolve(file); return; }
            const newName = (file.name || 'photo').replace(/\.[a-z0-9]+$/i, '') + '.jpg';
            const compressed = new File([blob], newName, { type: 'image/jpeg', lastModified: Date.now() });
            cleanupAndResolve(compressed);
          }, 'image/jpeg', IMAGE_COMPRESS_QUALITY);
        } catch (e) {
          console.warn('Image compression failed, sending original file:', e);
          cleanupAndResolve(file);
        }
      };
      img.onerror = () => cleanupAndResolve(file);
      img.src = objectUrl;
    });
  }

  function getFileNameFromUrl(url) {
    if (!url) return 'File';
    try {
      const path = url.split('?')[0];
      const last = path.substring(path.lastIndexOf('/') + 1);
      const decoded = decodeURIComponent(last);
      return decoded.replace(/^\d{10,}-/, '') || 'File';
    } catch {
      return 'File';
    }
  }

  function getFileExt(name) {
    const match = /\.([a-z0-9]+)$/i.exec(name || '');
    return match ? match[1].toUpperCase() : '';
  }

  function getFileIconClass(ext) {
    const e = (ext || '').toLowerCase();
    if (e === 'pdf') return 'fa-file-pdf';
    if (['doc', 'docx'].includes(e)) return 'fa-file-word';
    if (['xls', 'xlsx', 'csv'].includes(e)) return 'fa-file-excel';
    if (['ppt', 'pptx'].includes(e)) return 'fa-file-powerpoint';
    if (['zip', 'rar', '7z'].includes(e)) return 'fa-file-zipper';
    if (['txt', 'md'].includes(e)) return 'fa-file-lines';
    if (['mp3', 'wav', 'ogg', 'm4a'].includes(e)) return 'fa-file-audio';
    return 'fa-file';
  }

  function showError(message) {
    DOM.authErrorText.textContent = message;
    DOM.authError.classList.remove('hidden');
  }

  function hideError() {
    DOM.authError.classList.add('hidden');
  }

  function hideAppLoading() {
    if (DOM.appLoading) DOM.appLoading.classList.add('hidden');
    if (window.__orbitLoadingFallback) {
      clearTimeout(window.__orbitLoadingFallback);
      window.__orbitLoadingFallback = null;
    }
  }

  // NOTE: no longer called — Supabase Storage upload paths (message
  // attachments and status media both used this) were replaced by
  // uploadFileToR2() below, which gets its object key from the
  // "chat-media-upload-url" Edge Function instead. Left in place
  // (harmless, unused) rather than deleted, to keep this diff minimal.
  function generateStoragePath(channelId, filename) {
    const timestamp = Date.now();
    return CONFIG.UPLOAD.STORAGE_PATH
      .replace('{channelId}', channelId)
      .replace('{timestamp}', timestamp)
      .replace('{filename}', filename);
  }

  // ============================================================
  // CLOUDFLARE R2 CHAT MEDIA UPLOAD
  // Photos/videos/PDFs/files attached to messages or status updates now
  // go to a Cloudflare R2 bucket instead of Supabase Storage, to stay
  // within Supabase's free-tier egress/storage limits (R2 has no egress
  // fees). This is a SEPARATE R2 account/bucket from the one used for
  // live-session recordings (see openChannelRecordings() above) — keep
  // their credentials distinct in Supabase's Edge Function secrets.
  //
  // Flow: ask the "chat-media-upload-url" Edge Function for a short-lived
  // presigned PUT url (the browser uploads straight to R2, the Edge
  // Function's R2 credentials never reach the browser), then PUT the file
  // there directly. The Edge Function also hands back a presigned GET url
  // (valid 7 days, matching MESSAGE_MEDIA_EXPIRY_MS below) which is stored
  // as file_url/media_url exactly like the old public Supabase Storage URL
  // was — every existing render/display function (isImageFile, isPdfFile,
  // getFileNameFromUrl, etc.) works unchanged since they just operate on
  // the URL string.
  //
  // Cleanup: unlike the Supabase Storage path, there's no client-side
  // orphan-file cleanup here on a failed DB insert — instead, an R2
  // Lifecycle rule (configured directly in the Cloudflare dashboard, not
  // in code) auto-deletes every object after 7 days regardless of whether
  // its message/status row ever got created. Simpler and it can't be
  // skipped by a network error the way a client-side delete call could be.
  async function uploadFileToR2(file, context) {
    const { data: signed, error: signError } = await supabase.functions.invoke('chat-media-upload-url', {
      body: {
        fileName: file.name,
        fileType: file.type || 'application/octet-stream',
        fileSize: file.size,
        context, // 'message' | 'status'
      },
    });
    if (signError || !signed?.uploadUrl) {
      throw new Error(signed?.error || signError?.message || 'Could not get an upload URL');
    }

    const putRes = await fetch(signed.uploadUrl, {
      method: 'PUT',
      headers: { 'Content-Type': file.type || 'application/octet-stream' },
      body: file,
    });
    if (!putRes.ok) throw new Error(`R2 upload failed (${putRes.status})`);

    return signed.fileUrl;
  }

  // ============================================================
  // 6a. REALTIME CONNECTION STATUS BANNER
  // ============================================================
  const connectionIssues = new Set();
  let connectionBannerEl = null;

  function setConnectionIssue(key, hasIssue) {
    const had = connectionIssues.has(key);
    if (hasIssue) connectionIssues.add(key);
    else connectionIssues.delete(key);
    if (had !== connectionIssues.has(key)) renderConnectionBanner();
  }

  function renderConnectionBanner() {
    if (connectionIssues.size === 0) {
      if (connectionBannerEl) {
        connectionBannerEl.remove();
        connectionBannerEl = null;
      }
      return;
    }
    if (!connectionBannerEl) {
      connectionBannerEl = document.createElement('div');
      connectionBannerEl.setAttribute('role', 'status');
      connectionBannerEl.style.cssText = [
        'position:fixed', 'left:50%', 'bottom:16px', 'transform:translateX(-50%)',
        'z-index:99999', 'max-width:min(92vw,440px)',
        'background:#E24C43', 'color:#fff', 'font:600 12.5px/1.4 -apple-system,system-ui,sans-serif',
        'padding:10px 14px', 'border-radius:12px',
        'box-shadow:0 8px 24px -6px rgba(0,0,0,0.35)',
        'display:flex', 'align-items:center', 'gap:10px',
      ].join(';');
      document.body.appendChild(connectionBannerEl);
    }
    connectionBannerEl.innerHTML =
      '<span style="flex:1;">⚠️ Live updates aren\'t connecting — new messages and unread counts may be delayed. Try refreshing the page.</span>' +
      '<button type="button" aria-label="Dismiss" style="flex-shrink:0;background:rgba(255,255,255,0.18);border:none;color:#fff;width:22px;height:22px;border-radius:50%;cursor:pointer;font-size:13px;line-height:1;">✕</button>';
    connectionBannerEl.querySelector('button').addEventListener('click', () => {
      connectionBannerEl.remove();
      connectionBannerEl = null;
    });
  }

  // ============================================================
  // 6b. SCREEN NAVIGATION
  // ============================================================
  const ROOT_TABS = ['chats', 'updates', 'settings'];
  const SCREEN_EL = {
    chats: DOM.screenChats,
    updates: DOM.screenUpdates,
    settings: DOM.screenSettings,
    chatDetail: DOM.screenChatDetail,
    members: DOM.screenMembers,
    profile: DOM.screenProfile,
    calendar: DOM.screenCalendar,
    attendance: DOM.screenAttendance,
  };

  const CHAT_GROUP_SCREENS = ['chats', 'chatDetail', 'members', 'profile'];
  const isDesktopLayout = () => window.matchMedia('(min-width: 1024px)').matches;

  // FIX: root cause of "received message is marked read / the unread badge
  // disappears for a channel the user never actually opened" — on desktop,
  // CHAT_GROUP_SCREENS (below) deliberately includes 'chats' so the right-
  // hand message pane stays visible while browsing the channel list, since
  // that's a real split-pane layout choice. But this function was also
  // being used to gate read-receipts (markDelivered/markSeen — see the
  // message INSERT handler and selectChannel()), and it used the exact
  // same "screen is one of CHAT_GROUP_SCREENS" check for that. That meant
  // ANY channel sitting in state.currentChannel counted as "visible" and
  // got its messages marked seen and its badge cleared automatically,
  // even if it got there some way other than a genuine click. Requiring
  // channelExplicitlyOpened here keeps the pane-visibility behavior for
  // rendering, but only allows read-receipts once the user has actually
  // clicked/tapped into that specific channel at least once.
  function isChatDetailVisible(channelId) {
    if (!state.currentChannel || String(state.currentChannel.id) !== String(channelId)) return false;
    if (!state.channelExplicitlyOpened) return false;
    if (isDesktopLayout()) {
      return CHAT_GROUP_SCREENS.includes(state.currentScreen);
    }
    return state.currentScreen === 'chatDetail';
  }

  function updateChatEmptyState() {
    if (!DOM.screenChatDetail) return;
    const noChat = !state.currentChannel;
    DOM.screenChatDetail.classList.toggle('no-chat', noChat);
    // FIX: restore the original welcome placeholder into #chatMessages
    // whenever there's no channel selected, instead of leaving whatever
    // messages were last rendered there. Without this, the `.no-chat`
    // class alone just re-centers the previous channel's chat history.
    if (noChat && DOM.chatMessages && CHAT_WELCOME_HTML) {
      DOM.chatMessages.innerHTML = CHAT_WELCOME_HTML;
    }
  }

  function goToScreen(name) {
    if (name !== 'chatDetail' && typeof exitMessageSelection === 'function') exitMessageSelection();
    if (name !== 'updates' && typeof exitStatusSelection === 'function') exitStatusSelection();
    updateChatEmptyState();
    const isDesktop = isDesktopLayout();
    const keepChatsVisible = isDesktop && CHAT_GROUP_SCREENS.includes(name);

    Object.entries(SCREEN_EL).forEach(([key, el]) => {
      if (!el) return;
      
      let shouldBeVisible = false;
      
      if (key === name) {
        shouldBeVisible = true;
      } else if (isDesktop && key === 'chats' && CHAT_GROUP_SCREENS.includes(name)) {
        shouldBeVisible = true;
      } else if (isDesktop && keepChatsVisible && key === 'chats') {
        shouldBeVisible = true;
      } else if (isDesktop && key === 'chatDetail' && name === 'chats') {
        shouldBeVisible = true;
      }
      
      if (shouldBeVisible) {
        el.classList.remove('hidden');
        el.style.display = 'flex';
        el.style.flexDirection = 'column';
      } else {
        el.classList.add('hidden');
        el.style.display = 'none';
      }
    });
    
    const isRoot = ROOT_TABS.includes(name);
    const hideNav = !isRoot && !isDesktop;
    DOM.bottomNav.classList.toggle('hidden', hideNav);
    
    if (isDesktop) {
      DOM.bottomNav.classList.remove('hidden');
      DOM.bottomNav.style.display = 'flex';
    }
    
    if (isRoot) {
      state.currentTab = name;
      DOM.bottomNav.querySelectorAll('.nav-btn').forEach((b) => {
        b.classList.toggle('active', b.dataset.tab === name);
      });
    }
    
    state.currentScreen = name;

    if (name === 'settings' && typeof syncNotificationToggleState === 'function') {
      syncNotificationToggleState();
    }
    if (name === 'settings' && state.isAdmin) {
      loadRegisteredUsersList();
    }

    if (!isBackNavigation) {
      pushScreenState(name);
    }
  }

  let lastIsDesktop = isDesktopLayout();
  window.addEventListener('resize', () => {
    const nowDesktop = isDesktopLayout();
    if (nowDesktop !== lastIsDesktop) {
      lastIsDesktop = nowDesktop;
      if (state.currentScreen) goToScreen(state.currentScreen);
    }
  });

  let suppressChatOpenClicksUntil = 0;
  let suppressStatusOpenClicksUntil = 0;

  // ============================================================
  // 5i. HISTORY NAVIGATION (mobile back button)
  // ============================================================
  let screenHistory = [];
  let isBackNavigation = false;

  function pushScreenState(screenName) {
    if (screenHistory.length === 0 || screenHistory[screenHistory.length - 1] !== screenName) {
      screenHistory.push(screenName);
      if (history.pushState) {
        history.pushState({ orbitScreen: screenName }, '', '#' + screenName);
      }
    }
  }

  function closeLightboxIfOpen() {
    if (state.activeLightbox) {
      if (typeof state.activeLightbox._lightboxCleanup === 'function') {
        state.activeLightbox._lightboxCleanup();
      }
      state.activeLightbox.remove();
      state.activeLightbox = null;
      if (state.currentScreen && history.replaceState) {
        history.replaceState({ orbitScreen: state.currentScreen }, '', '#' + state.currentScreen);
      }
      return true;
    }
    return false;
  }

  function handleBackNavigation(event) {
    if (closeLightboxIfOpen()) {
      return;
    }
    
    if (DOM.statusModal && !DOM.statusModal.classList.contains('hidden')) {
      closeStatusViewer();
      if (state.currentScreen) pushScreenState(state.currentScreen);
      return;
    }
    
    // FIX: only force-close the call here while it's full-screen — that's
    // the state where it would otherwise swallow every back gesture with
    // no other way out. Once minimized (see setVideoMinimized()) the call
    // is already out of the way and the composer/chat list are usable, so
    // back should behave normally (e.g. leave the chat screen) instead of
    // also disconnecting a call the user deliberately kept running.
    if (DOM.videoContainer && !DOM.videoContainer.classList.contains('hidden') && !state.videoMinimized) {
      closeLiveSession();
      if (state.currentScreen) pushScreenState(state.currentScreen);
      return;
    }

    const targetScreen = event.state && event.state.orbitScreen;

    if (targetScreen && SCREEN_EL[targetScreen]) {
      isBackNavigation = true;
      const idx = screenHistory.lastIndexOf(targetScreen);
      screenHistory = idx !== -1 ? screenHistory.slice(0, idx + 1) : [targetScreen];
      goToScreen(targetScreen);
      isBackNavigation = false;
      return;
    }

    if (state.currentScreen && state.currentScreen !== 'chats') {
      isBackNavigation = true;
      goToScreen('chats');
      isBackNavigation = false;
    }
  }

  // ============================================================
  // 7. AUTHENTICATION
  // ============================================================
  async function loginWithUsername(username, password) {
    const email = generateEmail(username);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      return data.user;
    } catch (e) {
      console.error('Auth error:', e);
      if (/email not confirmed/i.test(e.message || '')) {
        throw new Error('This account is waiting on an email confirmation. Ask your admin to turn off "Confirm email" in Supabase.');
      }
      throw new Error('Incorrect Orbit ID or Password.');
    }
  }

  // ============================================================
  // 8. CHANNELS (CRUD)
  // ============================================================
  async function createChannel(name) {
    if (!name || !name.trim()) return;

    const basePayload = {
      name: name.trim(),
      created_by: state.currentUser?.username,
      created_at: new Date().toISOString()
    };

    let { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.CHANNELS)
      .insert(basePayload)
      .select();

    if (error && /created_by.*schema cache/i.test(error.message || '')) {
      console.warn('channels.created_by column missing — retrying insert without it.');
      const { created_by, ...fallbackPayload } = basePayload;
      ({ data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.CHANNELS)
        .insert(fallbackPayload)
        .select());
    }

    if (error) {
      alert('Could not create channel: ' + error.message);
      return;
    }
    
    await renderChannels();
    if (data && data[0]) {
      selectChannel(data[0]);
    }
  }

  async function loadChannels() {
    if (!state.currentUser) return [];

    if (state.isAdmin) {
      state.myMemberships = new Map();
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.CHANNELS)
        .select('*')
        .order('name');

      if (error) {
        console.warn('Channels fallback:', error);
        return [
          { id: '1', name: 'Math 101' },
          { id: '2', name: 'Science' },
          { id: '3', name: 'History' }
        ];
      }
      return data || [];
    }

    const { data: memberships, error: memberError } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MEMBERS)
      .select('id, channel_id')
      .eq('username', state.currentUser.username);

    if (memberError) {
      console.warn('Membership lookup failed:', memberError);
      return [];
    }

    state.myMemberships = new Map((memberships || []).map((m) => [String(m.channel_id), m.id]));

    const channelIds = (memberships || []).map((m) => m.channel_id);
    if (!channelIds.length) return [];

    const { data: channels, error: channelError } = await supabase
      .from(CONFIG.SUPABASE.TABLES.CHANNELS)
      .select('*')
      .in('id', channelIds)
      .order('name');

    if (channelError) {
      console.warn('Channels fallback:', channelError);
      return [];
    }
    return channels || [];
  }

  async function loadChannelPreviews(channelIds) {
    if (!channelIds.length) return {};
    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MESSAGES)
      .select('channel_id, content, username, created_at, file_url')
      .in('channel_id', channelIds)
      .order('created_at', { ascending: false })
      .limit(300);

    if (error) {
      console.warn('Preview lookup failed:', error);
      return {};
    }
    const map = {};
    (data || []).forEach((m) => {
      if (!map[m.channel_id]) map[m.channel_id] = m;
    });
    return map;
  }

  let allChannels = [];
  let allGroupsCache = [];
  let registeredUserMemberships = new Map();
  let registeredUsersListHasData = false;
  let registeredUsersListLoading = false;

  async function renderChannels() {
    const channels = await loadChannels();
    allChannels = channels;
    syncChannelBadgeSubscriptions(channels.map((c) => c.id));
    state.channelPreviews = await loadChannelPreviews(channels.map((c) => c.id));
    renderChatList(channels);

    // FIX: "on refresh the app auto-opens 'Brand New Class' instead of
    // staying neutral" — this block used to call
    // selectChannel(channels[0], ...) whenever no channel was selected yet.
    // loadChannels() sorts channels alphabetically by name, so "first in
    // the list" was never "most recent" or "intentional" — it was just
    // whichever channel happened to sort first (e.g. "Brand New Class"
    // beats "E-Commerce...", "English Communication", "Graphic Design").
    // Every reload silently opened that channel, marked it as the active
    // chat, and highlighted its row — even though the user never clicked
    // it. Removed entirely: state.currentChannel now stays null after
    // renderChannels() runs, so the UI stays on the neutral "Select a
    // session" welcome screen until the user actually taps a channel
    // (openChannel() -> selectChannel(..., { userInitiated: true })).
  }

  // FIX: root cause of "chat doesn't move to top in real-time when it
  // receives a message" — loadChannels() always orders channels
  // alphabetically by name (`.order('name')` in the DB query), and every
  // realtime message handler (handleGlobalMessageInsert, and the two
  // INSERT handlers inside subscribeToMessages) only ever updated
  // state.channelPreviews[channelId] and then re-rendered `allChannels` in
  // that same untouched alphabetical order. The preview text/time updated
  // in place, but nothing ever reordered the rows by recency, so a channel
  // could never visually "jump" to the top. sortChannelsByActivity() below
  // sorts by each channel's most recent preview timestamp (falling back to
  // alphabetical for channels with no messages yet), and renderChatList()
  // now always renders through it — on initial load and on every realtime
  // update alike — so the most recently active chat is always at the top,
  // like a normal chat app.
  function sortChannelsByActivity(channels) {
    return [...channels].sort((a, b) => {
      const aTime = state.channelPreviews[a.id]?.created_at;
      const bTime = state.channelPreviews[b.id]?.created_at;
      if (aTime && bTime) return new Date(bTime) - new Date(aTime);
      if (aTime) return -1;
      if (bTime) return 1;
      return a.name.localeCompare(b.name);
    });
  }

  function renderChatList(channels) {
    exitChannelSelection();
    DOM.channelList.innerHTML = '';

    if (!channels || channels.length === 0) {
      DOM.channelList.innerHTML = state.isAdmin
        ? '<div class="empty-note">No channels yet — tap + to create one</div>'
        : '<div class="empty-note">You haven\'t been added to an Orbit yet.</div>';
      return;
    }

    const sortedChannels = sortChannelsByActivity(channels);

    sortedChannels.forEach((ch) => {
      const preview = state.channelPreviews[ch.id];
      const unread = state.unreadByChannel[ch.id] || 0;
      const previewLinkUrl = preview && preview.content ? firstUrlIn(preview.content) : null;
      const previewText = preview
        ? (preview.content
            ? (previewLinkUrl
                ? `<a href="${escapeHtml(previewLinkUrl)}" rel="noopener" class="msg-link">${escapeHtml(truncate(preview.content, 42))}</a>`
                : escapeHtml(truncate(preview.content, 42)))
            : (preview.file_url ? '📎 Attachment' : ''))
        : 'No messages yet';
      const previewAuthor = preview && preview.username ? `${escapeHtml(getDisplayName(preview.username))}: ` : '';
      const time = preview ? formatTimeAgo(preview.created_at) : '';

      const row = document.createElement('div');
      row.className = 'chat-row' + (state.currentChannel && state.currentChannel.id === ch.id ? ' active' : '');
      row.dataset.id = ch.id;
      row.dataset.name = ch.name.toLowerCase();
      row.innerHTML = `
        ${channelAvatarHtml(ch)}
        <div class="chat-row-body">
          <div class="chat-row-top">
            <span class="chat-row-name">${escapeHtml(ch.name)}</span>
            <span class="chat-row-time">${time}</span>
          </div>
          <div class="chat-row-bottom">
            <span class="chat-row-preview">${previewAuthor}${previewText}</span>
            ${unread > 0 ? `<span class="unread-badge">${unread > 99 ? '99+' : unread}</span>` : ''}
          </div>
        </div>
      `;
      if (state.isAdmin) {
        row.addEventListener('touchstart', () => startChannelLongPress(row, ch), { passive: true });
        ['touchend', 'touchmove', 'touchcancel'].forEach((evt) => {
          row.addEventListener(evt, clearChannelLongPressTimer);
        });
        row.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          selectChannelForActions(row, ch);
        });
      }
      row.addEventListener('pointerup', (e) => {
        if (e.button === 2) return;
        if (channelLongPressFired) { channelLongPressFired = false; return; }
        if (e.target.closest('a.msg-link')) return;
        e.preventDefault();
        openChannel(ch);
      });
      row.addEventListener('click', (e) => {
        const link = e.target.closest('a.msg-link');
        if (!link) return;
        e.preventDefault();
        e.stopPropagation();
        openExternalLink(link.getAttribute('href'));
      });
      DOM.channelList.appendChild(row);
    });
  }

  function highlightActiveChatRow() {
    if (!DOM.channelList) return;
    DOM.channelList.querySelectorAll('.chat-row').forEach((row) => {
      row.classList.toggle('active', !!state.currentChannel && row.dataset.id === String(state.currentChannel.id));
    });
  }

  function filterChatList(query) {
    const q = query.trim().toLowerCase();
    DOM.channelList.querySelectorAll('.chat-row').forEach((row) => {
      row.classList.toggle('hidden', !!q && !row.dataset.name.includes(q));
    });
  }

  async function openChannel(channel) {
    suppressChatOpenClicksUntil = Date.now() + 80;
    selectChannel(channel);
    goToScreen('chatDetail');
    requestAnimationFrame(scrollToBottom);
  }

  async function renameChannel(channelId) {
    const newName = prompt('New channel name:');
    if (!newName) return;
    const { error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.CHANNELS)
      .update({ name: newName })
      .eq('id', channelId);
    if (error) { alert('Rename failed: ' + error.message); return; }
    if (state.currentChannel?.id === channelId) state.currentChannel.name = newName;
    await renderChannels();
  }

  async function deleteChannel(channelId) {
    if (!confirm('Delete this channel? This also removes its messages and member list. This cannot be undone.')) return;
    const { error } = await supabase.from(CONFIG.SUPABASE.TABLES.CHANNELS).delete().eq('id', channelId);
    if (error) { alert('Delete failed: ' + error.message); return; }
    if (state.currentChannel?.id === channelId) {
      state.currentChannel = null;
      teardownMessagesSubscription();
    }
    await renderChannels();
  }

  let channelLongPressTimer = null;
  let channelLongPressFired = false;
  let selectedChannel = null;

  function clearChannelLongPressTimer() {
    if (channelLongPressTimer) { clearTimeout(channelLongPressTimer); channelLongPressTimer = null; }
  }

  function startChannelLongPress(row, ch) {
    clearChannelLongPressTimer();
    channelLongPressTimer = setTimeout(() => {
      channelLongPressFired = true;
      selectChannelForActions(row, ch);
    }, 500);
  }

  function selectChannelForActions(row, ch) {
    exitChannelSelection();
    selectedChannel = ch;
    row.classList.add('active');

    if (DOM.brandHeader) DOM.brandHeader.classList.add('hidden');
    if (DOM.channelSelectHeader) DOM.channelSelectHeader.classList.remove('hidden');
    if (DOM.channelSelectCount) DOM.channelSelectCount.textContent = ch.name;
  }

  function exitChannelSelection() {
    if (!selectedChannel) return;
    selectedChannel = null;

    if (DOM.channelSelectHeader) DOM.channelSelectHeader.classList.add('hidden');
    if (DOM.brandHeader) DOM.brandHeader.classList.remove('hidden');
    highlightActiveChatRow();
  }

  if (DOM.channelSelectCloseBtn) DOM.channelSelectCloseBtn.addEventListener('click', exitChannelSelection);

  if (DOM.channelSelectRenameBtn) {
    DOM.channelSelectRenameBtn.addEventListener('click', () => {
      const ch = selectedChannel;
      exitChannelSelection();
      if (ch) renameChannel(ch.id);
    });
  }

  if (DOM.channelSelectDeleteBtn) {
    DOM.channelSelectDeleteBtn.addEventListener('click', () => {
      const ch = selectedChannel;
      exitChannelSelection();
      if (ch) deleteChannel(ch.id);
    });
  }

  if (DOM.channelSelectRecordingsBtn) {
    DOM.channelSelectRecordingsBtn.addEventListener('click', () => {
      const ch = selectedChannel;
      exitChannelSelection();
      if (ch) openChannelRecordings(ch);
    });
  }

  // ============================================================
  // RECORDINGS LIBRARY (Cloudflare R2) — per channel
  // ============================================================
  // Whether a given session gets recorded, and its retention, is decided
  // once, at scheduling time (see the "Record this session automatically"
  // checkbox in the Set-class-time form / setClassSchedule() above) —
  // not here. This panel is just a read/download/delete library:
  // recordings themselves are produced entirely outside this app by the
  // plugnmeet-recorder's post_transcoding hook (Oracle box), which
  // uploads the finished MP4 straight to Cloudflare R2 and calls the
  // "register-recording" Edge Function to insert a row per recording.
  let recordingsModalChannel = null;

  async function openChannelRecordings(channel) {
    recordingsModalChannel = channel;
    if (DOM.recordingsModalChannelName) DOM.recordingsModalChannelName.textContent = channel.name;
    if (DOM.recordingsModal) DOM.recordingsModal.classList.remove('hidden');
    await renderRecordingsList(channel.id);
  }

  function closeChannelRecordingsModal() {
    recordingsModalChannel = null;
    if (DOM.recordingsModal) DOM.recordingsModal.classList.add('hidden');
  }

  if (DOM.closeRecordingsModal) {
    DOM.closeRecordingsModal.addEventListener('click', closeChannelRecordingsModal);
  }

  async function renderRecordingsList(channelId) {
    if (!DOM.recordingsListContainer) return;
    DOM.recordingsListContainer.innerHTML = '<div class="empty-note">Loading recordings…</div>';

    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.RECORDINGS.TABLE)
      .select('*')
      .eq('channel_id', channelId)
      .is('deleted_at', null)
      .order('recorded_at', { ascending: false });

    if (error) {
      DOM.recordingsListContainer.innerHTML = `<div class="empty-note">Could not load recordings: ${escapeHtml(error.message)}</div>`;
      return;
    }

    if (!data || !data.length) {
      DOM.recordingsListContainer.innerHTML = '<div class="empty-note">No recordings yet for this Orbit.</div>';
      return;
    }

    DOM.recordingsListContainer.innerHTML = '';
    data.forEach((rec) => {
      const sizeMb = rec.file_size_bytes ? (rec.file_size_bytes / (1024 * 1024)).toFixed(1) + ' MB' : '—';
      const when = rec.recorded_at ? new Date(rec.recorded_at).toLocaleString() : '—';
      const row = document.createElement('div');
      row.className = 'recording-row';
      row.dataset.id = rec.id;
      row.innerHTML = `
        <div class="recording-row-info">
          <div class="recording-row-title">${escapeHtml(rec.title || rec.file_name || 'Recording')}</div>
          <div class="recording-row-meta">${escapeHtml(when)} · ${escapeHtml(sizeMb)}</div>
        </div>
        <div class="recording-row-actions">
          <button class="icon-btn recording-download-btn" title="Download"><i class="fas fa-download"></i></button>
          <button class="icon-btn recording-delete-btn" title="Delete from R2" style="color:var(--danger);"><i class="fas fa-trash"></i></button>
        </div>
      `;
      row.querySelector('.recording-download-btn').addEventListener('click', () => downloadRecording(rec.id));
      row.querySelector('.recording-delete-btn').addEventListener('click', () => deleteRecordingAdmin(rec.id, channelId));
      DOM.recordingsListContainer.appendChild(row);
    });
  }

  async function downloadRecording(recordingId) {
    const { data, error } = await supabase.functions.invoke(CONFIG.SUPABASE.RECORDINGS.DOWNLOAD_URL_FUNCTION, {
      body: { recording_id: recordingId },
    });
    if (error || !data?.url) {
      alert('Could not get a download link: ' + (data?.error || error?.message || 'Unknown error'));
      return;
    }
    // Opens the presigned R2 URL (valid a few minutes) in a new tab so
    // the browser/OS handles the actual download.
    window.open(data.url, '_blank', 'noopener');
  }

  async function deleteRecordingAdmin(recordingId, channelId) {
    if (!confirm('Delete this recording from Cloudflare R2? This cannot be undone — make sure it has been downloaded first if you need to keep it.')) return;
    const { data, error } = await supabase.functions.invoke(CONFIG.SUPABASE.RECORDINGS.DELETE_FUNCTION, {
      body: { recording_id: recordingId },
    });
    if (error || data?.error) {
      alert('Delete failed: ' + (data?.error || error?.message || 'Unknown error'));
      return;
    }
    await renderRecordingsList(channelId);
  }

  // ============================================================
  // UNREAD BADGE REFRESH
  // ============================================================
  // FIX: "unread count stays stuck even though the message is open and
  // visible" — refreshUnreadBadges() does two sequential DB round trips
  // (fetch messages, fetch read receipts) before it applies the result.
  // It's called from several places that can legitimately overlap in
  // time — most commonly here: subscribeToMessages()'s INSERT handler
  // calls it once immediately for every new message, then (if the chat is
  // open) calls it again at the tail of markSeen(). When two messages
  // arrive close together, two of these overlapping call chains are in
  // flight at once, each awaiting its own network round trips — nothing
  // ties their completion order to their start order. It was entirely
  // possible for an OLDER refresh (started before markSeen() had recorded
  // the read receipt) to finish its network round trip AFTER a NEWER,
  // already-correct refresh, and stomp the correct "0 unread" back to a
  // stale "1 unread" on its way out. requestId is a simple "ignore stale
  // responses" guard: every call grabs a ticket, and only the call still
  // holding the most recently issued ticket by the time its data comes
  // back is allowed to touch state/DOM. See also queueMarkSeen() below,
  // which addresses the other half of this same race by preventing the
  // markDelivered/markSeen writes themselves from overlapping in the
  // first place.
  let unreadBadgeRequestId = 0;
  async function refreshUnreadBadges() {
    if (!state.currentUser) return;
    const myRequestId = ++unreadBadgeRequestId;

    try {
      const channelIds = allChannels.map((c) => c.id);

      if (!channelIds.length) {
        if (myRequestId !== unreadBadgeRequestId) return; // stale — a newer refresh has since started
        state.unreadByChannel = {};
        DOM.navChatsBadge.textContent = '0';
        DOM.navChatsBadge.classList.add('hidden');
        renderChatList(allChannels);
        return;
      }

      // FIX: "badge disappears, but it takes a while" (part 1) — these two
      // selects don't depend on each other at all, but were awaited one
      // after another, so the badge sat waiting for two round trips back
      // to back instead of one. Firing them together and awaiting both
      // roughly halves this function's own latency.
      const [
        { data: fromOthers, error: msgError },
        { data: myReads, error: readsError },
      ] = await Promise.all([
        supabase
          .from(CONFIG.SUPABASE.TABLES.MESSAGES)
          .select('id, channel_id')
          .in('channel_id', channelIds)
          .neq('username', state.currentUser.username)
          .is('deleted_at', null),
        supabase
          .from('message_reads')
          .select('message_id')
          .eq('username', state.currentUser.username),
      ]);

      if (msgError) {
        console.warn('Failed to fetch messages for badge:', msgError);
        setConnectionIssue('badges', true);
        return;
      }
      if (readsError) {
        console.warn('Failed to fetch read receipts for badge:', readsError);
        setConnectionIssue('badges', true);
        return;
      }
      setConnectionIssue('badges', false);

      const readIds = new Set((myReads || []).map((r) => r.message_id));
      const counts = {};
      
      (fromOthers || []).forEach((row) => {
        if (!readIds.has(row.id)) {
          counts[row.channel_id] = (counts[row.channel_id] || 0) + 1;
        }
      });

      // FIX: see the requestId comment above buildwise this function —
      // don't let a slower, older call apply its (now-stale) result on top
      // of a newer call that already finished and rendered.
      if (myRequestId !== unreadBadgeRequestId) return;

      state.unreadByChannel = counts;

      const total = Object.values(counts).reduce((a, b) => a + b, 0);
      DOM.navChatsBadge.textContent = total > 99 ? '99+' : String(total);
      DOM.navChatsBadge.classList.toggle('hidden', total === 0);

      state.channelPreviews = await loadChannelPreviews(channelIds);
      renderChatList(allChannels);

      console.log(`🔔 Badge updated: ${total} unread messages`);
    } catch (e) {
      console.warn('Error refreshing unread badges:', e);
    }
  }

  // ============================================================
  // GLOBAL CHANNEL-LIST REALTIME
  // ============================================================
  let channelListSubscription = null;

  function isKnownChannelId(channelId) {
    return allChannels.some((c) => String(c.id) === String(channelId));
  }

  // FIX: root cause of "no realtime notification numbers on groups when no
  // chat is selected — behaves like the browser tab is closed" —
  // playNotifySound() (audio ping + OS Notification popup) used to only be
  // called from inside subscribeToMessages()'s own INSERT handler, which
  // only exists for the ONE channel currently selected (see selectChannel()
  // → subscribeToMessages()). That meant: new messages in every OTHER
  // channel never played a sound or triggered an OS notification at all,
  // and when no channel was selected (state.currentChannel === null),
  // there was no per-channel subscription running for anything, so
  // nothing ever notified, full stop — exactly like the tab wasn't
  // receiving realtime updates at all. handleGlobalMessageInsert() below
  // is the one subscription that's always active for every channel the
  // user belongs to (see subscribeToChannelListUpdates()), so it's the
  // right place to own notifications — gated on !isOpenChannel so it
  // still stays quiet for whichever chat the user is actually looking at.
  function handleGlobalMessageInsert(msg) {
    if (!msg || !isKnownChannelId(msg.channel_id)) return;

    const existing = state.channelPreviews[msg.channel_id];
    if (!existing || new Date(msg.created_at) >= new Date(existing.created_at || 0)) {
      state.channelPreviews[msg.channel_id] = msg;
    }

    const isOpenChannel = isChatDetailVisible(msg.channel_id);
    if (!isOpenChannel && msg.username !== state.currentUser?.username) {
      state.unreadByChannel[msg.channel_id] = (state.unreadByChannel[msg.channel_id] || 0) + 1;
      const total = Object.values(state.unreadByChannel).reduce((a, b) => a + b, 0);
      DOM.navChatsBadge.textContent = total > 99 ? '99+' : String(total);
      DOM.navChatsBadge.classList.toggle('hidden', total === 0);
      playNotifySound(msg, allChannels.find((c) => String(c.id) === String(msg.channel_id)));
    }

    renderChatList(allChannels);
  }

  async function expelFromChannel(removedChannelId, { showAlert = true } = {}) {
    if (!removedChannelId) return;
    removedChannelId = String(removedChannelId);

    console.log(`🚪 Removed from channel ${removedChannelId}, updating UI.`);

    state.myMemberships.delete(removedChannelId);
    allChannels = allChannels.filter((c) => String(c.id) !== removedChannelId);
    delete state.unreadByChannel[removedChannelId];
    delete state.channelPreviews[removedChannelId];
    unsubscribeChannelBadge(removedChannelId);

    const wasOpen = state.currentChannel && String(state.currentChannel.id) === removedChannelId;
    if (wasOpen) {
      teardownMessagesSubscription();
      teardownReadsSubscription();
      if (scheduleSubscription) {
        supabase.removeChannel(scheduleSubscription);
        scheduleSubscription = null;
      }
      state.currentChannel = null;
      state.messages = [];
      state.currentMembers = [];
      goToScreen('chats');
      if (showAlert) alert('You were removed from This Session.');
    }

    renderChatList(allChannels);
    await refreshUnreadBadges();
  }

  async function handleMembershipRemoved(oldRow) {
    if (!oldRow || !state.currentUser) return;

    let removedChannelId = null;
    for (const [channelId, membershipId] of state.myMemberships.entries()) {
      if (String(membershipId) === String(oldRow.id)) {
        removedChannelId = channelId;
        break;
      }
    }
    if (!removedChannelId && oldRow.username &&
        normalizeUsername(oldRow.username) === state.currentUser.username) {
      removedChannelId = String(oldRow.channel_id);
    }
    if (!removedChannelId) return;

    await expelFromChannel(removedChannelId);
  }

  // FIX: root cause of "group doesn't show to the added person in
  // real-time — only shows after refreshing the app" — the
  // channel-list-updates realtime channel below only ever listened for
  // DELETE events on the MEMBERS table (feeding handleMembershipRemoved
  // above) and DELETE on user_roles; there was no INSERT listener at all.
  // So when addMemberToChannel() inserts a new MEMBERS row for someone,
  // that student/teacher's already-open tab never hears about it — the
  // new group only ever appeared after a full reload, because that's the
  // only path that re-runs loadChannels() and re-reads membership rows
  // from the DB from scratch. handleMembershipAdded() is the INSERT
  // counterpart to handleMembershipRemoved(): every member's client gets
  // the INSERT event, checks whether the new row is *for them*, and if so
  // re-runs renderChannels() (loads channels + previews + re-subscribes
  // badges + re-renders the list) so the new group shows up immediately.
  // Admins already see every channel regardless of membership rows (see
  // loadChannels()), so this is a no-op for them.
  async function handleMembershipAdded(newRow) {
    if (!newRow || !state.currentUser || state.isAdmin) return;
    if (normalizeUsername(newRow.username || '') !== state.currentUser.username) return;
    if (state.myMemberships.has(String(newRow.channel_id))) return; // already known, nothing to do
    console.log('➕ Realtime: added to a new channel, refreshing channel list.');
    await renderChannels();
  }

  async function verifyChannelMembership(channelId) {
    try {
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MEMBERS)
        .select('id')
        .eq('channel_id', channelId)
        .eq('username', state.currentUser.username)
        .maybeSingle();

      if (error) {
        console.warn('Membership verification failed, allowing send:', error);
        return true;
      }
      return !!data;
    } catch (e) {
      console.warn('Membership verification error, allowing send:', e);
      return true;
    }
  }

  function handleAccountDeleted(oldRow) {
    if (!oldRow || !state.currentUser) return;
    const matchesById = state.myUserRoleId != null && String(oldRow.id) === String(state.myUserRoleId);
    const deletedUsername = normalizeUsername(oldRow.username || '');
    const matchesByUsername = !!deletedUsername && deletedUsername === state.currentUser.username;
    if (matchesById || matchesByUsername) {
      console.warn('🚫 Realtime: this account was removed, Signing Out.');
      forceSignOut('Your account has been removed. You have been Signed Out.');
    }
  }

  let channelListReconnectTimer = null;
  let channelListReconnectAttempts = 0;
  let channelListIntentionalTeardown = false;

  function scheduleChannelListReconnect() {
    if (channelListReconnectTimer || !state.currentUser) return;
    channelListReconnectAttempts += 1;
    const delay = Math.min(30000, 2000 * Math.pow(2, channelListReconnectAttempts - 1));
    console.log(`🔁 channel-list-updates reconnect attempt ${channelListReconnectAttempts} in ${delay / 1000}s...`);
    channelListReconnectTimer = setTimeout(() => {
      channelListReconnectTimer = null;
      if (state.currentUser) subscribeToChannelListUpdates();
    }, delay);
  }

  // FIX: "still doesn't show realtime notification numbers on groups" —
  // this channel used to also carry an UNFILTERED postgres_changes INSERT
  // listener on the whole messages table (no `filter`) to catch messages
  // for every group at once. The per-channel subscription used for
  // whichever chat is actually open (subscribeToMessages(), below) has
  // always used a FILTERED listener (`filter: channel_id=eq.${id}`) and
  // that one reliably receives events. Supabase Realtime evaluates RLS
  // differently for unfiltered postgres_changes subscriptions than for
  // filtered ones on some project configurations, which is consistent
  // with "works for whichever chat happens to be open, silent for every
  // other group" — exactly this bug. Rather than depend on the unfiltered
  // form, badges/notifications for every group now come from one FILTERED
  // subscription per group the user belongs to (see
  // syncChannelBadgeSubscriptions() below), reusing the exact pattern
  // that's already proven to work for the open chat.
  function subscribeToChannelListUpdates() {
    if (channelListReconnectTimer) {
      clearTimeout(channelListReconnectTimer);
      channelListReconnectTimer = null;
    }
    if (channelListSubscription) {
      channelListIntentionalTeardown = true;
      supabase.removeChannel(channelListSubscription);
      channelListIntentionalTeardown = false;
      channelListSubscription = null;
    }
    if (!state.currentUser) return;

    // FIX: root cause of "admin adds a member to a group and it still
    // doesn't show up for that person in real-time" — these two
    // postgres_changes listeners on the MEMBERS table were UNFILTERED
    // (no `filter`), same shape as the messages-table subscription that
    // the FIX comment on subscribeToChannelListUpdates() above already
    // identified as unreliable: this project's Realtime/RLS config only
    // consistently delivers postgres_changes events on FILTERED
    // subscriptions, not unfiltered ones. handleMembershipAdded() already
    // existed to refresh the channel list on INSERT, but the event itself
    // was frequently never delivered to the client, so the new group only
    // ever appeared after a manual reload (which re-reads membership rows
    // straight from the DB via loadChannels(), bypassing Realtime
    // entirely). Adding `filter: username=eq.<me>` — the same trick
    // subscribeToChannelBadge()/subscribeToMessages() already rely on —
    // makes both listeners FILTERED, which is the form proven to work.
    const myUsernameFilter = `username=eq.${state.currentUser.username}`;

    channelListSubscription = supabase
      .channel('channel-list-updates')
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: CONFIG.SUPABASE.TABLES.MEMBERS,
        filter: myUsernameFilter,
      }, (payload) => handleMembershipRemoved(payload.old))
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: CONFIG.SUPABASE.TABLES.MEMBERS,
        filter: myUsernameFilter,
      }, (payload) => handleMembershipAdded(payload.new))
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'user_roles',
        ...(state.myUserRoleId != null ? { filter: `id=eq.${state.myUserRoleId}` } : {}),
      }, (payload) => handleAccountDeleted(payload.old))
      .subscribe((status, err) => {
        if (status === 'SUBSCRIBED') {
          channelListReconnectAttempts = 0;
          setConnectionIssue('channel-list', false);
          console.log('✅ Subscribed to channel-list updates');
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          if (channelListIntentionalTeardown) return;
          console.warn(`⚠️ channel-list-updates: ${status}`, err || '');
          if (channelListSubscription) {
            channelListSubscription = null;
            scheduleChannelListReconnect();
            if (channelListReconnectAttempts >= 5) {
              setConnectionIssue('channel-list', true);
            }
          }
        }
      });
  }

  function unsubscribeFromChannelListUpdates() {
    if (channelListReconnectTimer) {
      clearTimeout(channelListReconnectTimer);
      channelListReconnectTimer = null;
    }
    if (channelListSubscription) {
      channelListIntentionalTeardown = true;
      supabase.removeChannel(channelListSubscription);
      channelListIntentionalTeardown = false;
      channelListSubscription = null;
    }
  }

  // ============================================================
  // PER-CHANNEL BADGE/NOTIFICATION REALTIME
  // ============================================================
  // FIX: see the FIX comment on subscribeToChannelListUpdates() above.
  // One small FILTERED postgres_changes subscription per group the user
  // belongs to — each identical in shape to the subscription
  // subscribeToMessages() already uses for whichever chat happens to be
  // open, which is the one we know reliably delivers events. This is what
  // makes badges/notifications work for every group in real time,
  // including while no chat is selected at all, instead of depending on a
  // single broad subscription.
  const channelBadgeSubscriptions = new Map();

  function subscribeToChannelBadge(channelId) {
    const key = String(channelId);
    if (channelBadgeSubscriptions.has(key)) return;
    const sub = supabase
      .channel(`badge:${key}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: CONFIG.SUPABASE.TABLES.MESSAGES,
        filter: `channel_id=eq.${key}`,
      }, (payload) => handleGlobalMessageInsert(payload.new))
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          console.warn(`⚠️ badge subscription for channel ${key}: ${status}`, err || '');
          channelBadgeSubscriptions.delete(key);
          // Only resubscribe if this channel is still one the user belongs
          // to — syncChannelBadgeSubscriptions() re-adds it on the next
          // channel-list refresh regardless, this just recovers sooner.
          if (isKnownChannelId(key)) subscribeToChannelBadge(key);
        }
      });
    channelBadgeSubscriptions.set(key, sub);
  }

  function unsubscribeChannelBadge(channelId) {
    const key = String(channelId);
    const sub = channelBadgeSubscriptions.get(key);
    if (sub) {
      supabase.removeChannel(sub);
      channelBadgeSubscriptions.delete(key);
    }
  }

  // Keeps exactly one badge subscription alive per current member channel —
  // called whenever the channel list is (re)loaded (see renderChannels()),
  // so joining/leaving/creating groups keeps this in sync automatically.
  function syncChannelBadgeSubscriptions(channelIds) {
    const idSet = new Set(channelIds.map(String));
    Array.from(channelBadgeSubscriptions.keys()).forEach((key) => {
      if (!idSet.has(key)) unsubscribeChannelBadge(key);
    });
    idSet.forEach((id) => subscribeToChannelBadge(id));
  }

  function unsubscribeAllChannelBadges() {
    Array.from(channelBadgeSubscriptions.keys()).forEach(unsubscribeChannelBadge);
  }

  // ============================================================
  // CHAT-LIST PREVIEW POLLING FALLBACK
  // ============================================================
  let channelPreviewPollTimer = null;
  const CHANNEL_PREVIEW_POLL_INTERVAL = 12000;

  async function pollChannelPreviews() {
    if (!state.currentUser || !allChannels.length) return;
    try {
      const fresh = await loadChannelPreviews(allChannels.map((c) => c.id));
      let changed = false;
      allChannels.forEach((ch) => {
        const incoming = fresh[ch.id];
        const existing = state.channelPreviews[ch.id];
        if (incoming && (!existing || incoming.id !== existing.id)) {
          changed = true;
        }
      });
      state.channelPreviews = fresh;
      if (changed) {
        console.log('🔄 Preview poll found new messages — refreshing chat list.');
        renderChatList(allChannels);
        await refreshUnreadBadges();
      }
    } catch (e) {
      console.warn('Channel preview poll failed:', e);
    }
  }

  function startChannelPreviewPolling() {
    stopChannelPreviewPolling();
    channelPreviewPollTimer = setInterval(pollChannelPreviews, CHANNEL_PREVIEW_POLL_INTERVAL);
  }

  function stopChannelPreviewPolling() {
    if (channelPreviewPollTimer) {
      clearInterval(channelPreviewPollTimer);
      channelPreviewPollTimer = null;
    }
  }

  // ============================================================
  // INSTANT MEMBERSHIP NOTIFICATIONS (Realtime Broadcast)
  // ============================================================
  // FIX: "decrease the time from 15 seconds to real-time" — the 15s
  // membership poll (below) is a safety net, not a real-time mechanism;
  // shrinking its interval only trades DB load for a smaller worst-case
  // delay, it can't reach "instant". True real-time here doesn't need
  // postgres_changes at all: Supabase Realtime's Broadcast feature is a
  // plain pub/sub push over the same websocket, sent directly from the
  // admin's client the moment addMemberToChannel()/removeMember()
  // succeed — no dependency on the MEMBERS table being in the
  // `supabase_realtime` publication, no WAL decoding, and no RLS
  // evaluation on postgres_changes, all of which we've been fighting.
  // Every non-admin client subscribes to a channel named after their own
  // username at login (subscribeToMyMembershipBroadcast) and reacts the
  // instant a message for them arrives. The admin side
  // (notifyMembershipChange) opens that same-named channel just long
  // enough to send one message, then tears it down.
  function memberBroadcastChannelName(username) {
    return `member-updates:${username}`;
  }

  function notifyMembershipChange(username, event, channelId) {
    const name = memberBroadcastChannelName(username);
    const ch = supabase.channel(name);
    ch.subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        ch.send({ type: 'broadcast', event, payload: { channelId: String(channelId) } });
        // Small delay before teardown — send() fires immediately over the
        // already-open socket, this just avoids racing the removal.
        setTimeout(() => supabase.removeChannel(ch), 500);
      } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
        supabase.removeChannel(ch);
      }
    });
  }

  let myMembershipBroadcastChannel = null;

  function subscribeToMyMembershipBroadcast() {
    unsubscribeFromMyMembershipBroadcast();
    if (!state.currentUser || state.isAdmin) return; // admins see every channel regardless of membership rows
    myMembershipBroadcastChannel = supabase
      .channel(memberBroadcastChannelName(state.currentUser.username))
      .on('broadcast', { event: 'membership-added' }, (payload) => {
        const channelId = payload?.payload?.channelId;
        if (channelId) handleMembershipAdded({ username: state.currentUser.username, channel_id: channelId });
      })
      .on('broadcast', { event: 'membership-removed' }, (payload) => {
        const channelId = payload?.payload?.channelId;
        if (channelId) expelFromChannel(String(channelId));
      })
      .subscribe();
  }

  function unsubscribeFromMyMembershipBroadcast() {
    if (myMembershipBroadcastChannel) {
      supabase.removeChannel(myMembershipBroadcastChannel);
      myMembershipBroadcastChannel = null;
    }
  }

  // ============================================================
  // MEMBERSHIP POLLING FALLBACK (safety net only)
  // ============================================================
  // FIX: "still need to refresh to see the channel after being added" —
  // handleMembershipAdded() + the now-FILTERED INSERT listener in
  // subscribeToChannelListUpdates() fix the *common* case, but they still
  // depend on Supabase Realtime actually delivering a postgres_changes
  // event for that INSERT — which requires (a) the MEMBERS table to be
  // added to the `supabase_realtime` publication in the DB, and (b) the
  // RLS SELECT policy on that table to be one Realtime can evaluate for
  // this row. Either of those being misconfigured silently drops the
  // event with no client-side error, no matter how the subscription is
  // filtered. Exactly this project already hit that wall once before —
  // see CHAT-LIST PREVIEW POLLING FALLBACK above, which exists because
  // message-preview updates had the same problem — so membership changes
  // get the same treatment: a lightweight poll that re-reads this user's
  // own membership rows and calls renderChannels() the moment it sees a
  // channel_id that isn't already known, so the new group shows up within
  // one poll interval even if Realtime never fires at all. Admins are
  // skipped — they already see every channel unconditionally (see
  // loadChannels()), so there's nothing for them to miss.
  let membershipPollTimer = null;
  const MEMBERSHIP_POLL_INTERVAL = 45000;

  async function pollMyMemberships() {
    if (!state.currentUser || state.isAdmin) return;
    try {
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MEMBERS)
        .select('channel_id')
        .eq('username', state.currentUser.username);

      if (error) {
        console.warn('Membership poll failed:', error);
        return;
      }

      const freshIds = new Set((data || []).map((m) => String(m.channel_id)));
      const knownIds = new Set(state.myMemberships.keys());

      let changed = freshIds.size !== knownIds.size;
      if (!changed) {
        for (const id of freshIds) {
          if (!knownIds.has(id)) { changed = true; break; }
        }
      }

      if (changed) {
        console.log('🔄 Membership poll found a change — refreshing channel list.');
        await renderChannels();
      }
    } catch (e) {
      console.warn('Membership poll error:', e);
    }
  }

  function startMembershipPolling() {
    stopMembershipPolling();
    membershipPollTimer = setInterval(pollMyMemberships, MEMBERSHIP_POLL_INTERVAL);
  }

  function stopMembershipPolling() {
    if (membershipPollTimer) {
      clearInterval(membershipPollTimer);
      membershipPollTimer = null;
    }
  }

  // ============================================================
  // DELIVERED / SEEN TRACKING
  // ============================================================
  // FIX: "badge disappears, but it takes a while" — correctness (previous
  // fix) meant the badge always eventually lands on the right number, but
  // it still only updated after markDelivered + markSeen's DB writes and
  // refreshUnreadBadges' reads all round-tripped — several sequential
  // network calls the person has to sit through before the number they're
  // already looking past just... goes away. The person reading the chat
  // is the actual "read" event; the DB writes are bookkeeping that other
  // devices/tabs need eventually, not something this tab's own badge
  // should visibly wait on. clearUnreadBadgeForChannel() updates
  // state.unreadByChannel and the DOM immediately, synchronously, the
  // moment we know the channel is genuinely visible — the network calls
  // below still run right after to persist the real read receipts (and
  // refreshUnreadBadges() at the end of markSeen() reconciles anything
  // this optimistic guess got wrong), but the person never has to wait on
  // them to see the badge go away.
  function clearUnreadBadgeForChannel(channelId) {
    const key = String(channelId);
    if (!state.unreadByChannel[key] && state.unreadByChannel[key] !== 0) return;
    delete state.unreadByChannel[key];
    const total = Object.values(state.unreadByChannel).reduce((a, b) => a + b, 0);
    DOM.navChatsBadge.textContent = total > 99 ? '99+' : String(total);
    DOM.navChatsBadge.classList.toggle('hidden', total === 0);
    renderChatList(allChannels);
  }

  // FIX: the other half of the "unread badge doesn't clear in realtime"
  // race — see the requestId comment on refreshUnreadBadges() above for
  // the read side of it. This is the write side: markDelivered()/
  // markSeen() are each a short chain of sequential DB calls (SELECT,
  // UPSERT, UPDATE). subscribeToMessages()'s INSERT handler used to just
  // call `await markDelivered(channelId); await markSeen(channelId);`
  // directly — safe for a single message, but every new INSERT event
  // triggers its own independent call to that same handler, and nothing
  // stopped two of those chains from running concurrently when messages
  // arrived close together. Two overlapping markSeen() calls can both
  // SELECT "unread messages" before either has finished UPSERTing read
  // receipts, so both think they still need to write rows the other is
  // about to write anyway — wasted work at best, and it's what let the
  // read side observe an inconsistent in-between state. queueMarkSeen()
  // chains every call onto one promise per tab, so this channel's
  // delivered/seen writes always run one at a time, strictly in the order
  // their messages arrived, and each one only starts once the previous
  // one (and its own trailing refreshUnreadBadges()) has fully finished.
  // markDelivered/markSeen touch different columns and don't depend on
  // each other, so they now run via Promise.all instead of one after the
  // other — this queue's total latency (background bookkeeping, not
  // something the badge waits on anymore) is roughly halved too.
  let markReadQueue = Promise.resolve();
  function queueMarkSeen(channelId) {
    markReadQueue = markReadQueue
      .then(() => Promise.all([markDelivered(channelId), markSeen(channelId)]))
      .catch((e) => console.warn('queueMarkSeen error:', e));
    return markReadQueue;
  }

  async function markDelivered(channelId) {
    if (!state.currentUser) return;
    
    try {
      console.log(`📬 Marking messages as delivered for channel ${channelId}`);
      
      const { error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .update({ 
          delivered_at: new Date().toISOString() 
        })
        .eq('channel_id', channelId)
        .neq('username', state.currentUser.username)
        .is('delivered_at', null);
        
      if (error) {
        console.warn('Failed to mark delivered:', error);
      } else {
        console.log('✅ Messages marked as delivered');
      }
    } catch (e) {
      console.warn('Mark delivered error:', e);
    }
  }

  async function markSeen(channelId) {
    if (!state.currentUser || document.hidden) {
      console.log('⏭️ Skipping markSeen - no user or tab not visible');
      return;
    }
    
    try {
      console.log(`👁️ Marking messages as seen for channel ${channelId}`);

      // FIX: the SELECT-then-UPSERT (building message_reads rows) and the
      // blanket seen_at UPDATE below don't depend on each other's result —
      // the UPDATE targets every unseen row in the channel by channel_id
      // alone, it doesn't need the SELECT's id list. They were awaited
      // one after another regardless, tacking a third sequential round
      // trip onto this background write. Running them together cuts this
      // function's own latency by roughly a third.
      const [readsResult, seenResult] = await Promise.all([
        (async () => {
          const { data: unreadMsgs, error: unreadError } = await supabase
            .from(CONFIG.SUPABASE.TABLES.MESSAGES)
            .select('id')
            .eq('channel_id', channelId)
            .neq('username', state.currentUser.username)
            .is('deleted_at', null);

          if (unreadError) {
            console.warn('Failed to get unread messages:', unreadError);
            return { error: unreadError };
          }
          if (!unreadMsgs || !unreadMsgs.length) return { count: 0 };

          const rows = unreadMsgs.map((m) => ({
            message_id: m.id,
            channel_id: channelId,
            username: state.currentUser.username,
          }));
          const { error: readsError } = await supabase
            .from('message_reads')
            .upsert(rows, { onConflict: 'message_id,username', ignoreDuplicates: true });
          return { error: readsError, count: rows.length };
        })(),
        supabase
          .from(CONFIG.SUPABASE.TABLES.MESSAGES)
          .update({
            seen_at: new Date().toISOString(),
            seen_by: state.currentUser.username
          })
          .eq('channel_id', channelId)
          .neq('username', state.currentUser.username)
          .is('seen_at', null),
      ]);

      if (readsResult.error) {
        console.warn('Failed to record read receipts:', readsResult.error);
        setConnectionIssue('badges', true);
      } else {
        console.log(`✅ Recorded ${readsResult.count || 0} read receipts`);
        setConnectionIssue('badges', false);
      }

      if (seenResult.error) {
        console.warn('Failed to mark seen:', seenResult.error);
      } else {
        console.log('✅ Messages marked as seen');
      }

      await refreshUnreadBadges();
      
    } catch (e) {
      console.warn('Mark seen error:', e);
      try {
        await refreshUnreadBadges();
      } catch (badgeError) {
        console.warn('Failed to refresh badge after error:', badgeError);
      }
    }
  }

  // ============================================================
  // GROUP READ RECEIPTS
  // ============================================================
  async function loadMessageReads(channelId) {
    const { data, error } = await supabase
      .from('message_reads')
      .select('message_id, username, seen_at')
      .eq('channel_id', channelId);

    state.messageReads = new Map();
    if (error) {
      console.warn('Failed to load read receipts:', error);
      return;
    }
    (data || []).forEach((row) => {
      const list = state.messageReads.get(row.message_id) || [];
      list.push({ username: row.username, seen_at: row.seen_at });
      state.messageReads.set(row.message_id, list);
    });
  }

  function teardownReadsSubscription() {
    if (!state.readsSubscription) return;
    supabase.removeChannel(state.readsSubscription);
    state.readsSubscription = null;
  }

  function subscribeToMessageReads(channelId) {
    teardownReadsSubscription();
    state.readsSubscription = supabase
      .channel(`message_reads:${channelId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'message_reads',
        filter: `channel_id=eq.${channelId}`,
      }, (payload) => {
        const row = payload.new;
        const list = state.messageReads.get(row.message_id) || [];
        if (!list.some((r) => r.username === row.username)) {
          list.push({ username: row.username, seen_at: row.seen_at });
          state.messageReads.set(row.message_id, list);
        }
      })
      .subscribe();
  }

  // ============================================================
  // SAFE MESSAGE MERGING
  // ============================================================
  function mergeMessagesSafely(newMessages, forceScroll) {
    if (state.isMerging) {
      console.log('⏳ Merge already in progress, skipping');
      return;
    }
    
    state.isMerging = true;
    
    try {
      const messagesToAdd = Array.isArray(newMessages) ? newMessages : [newMessages];
      
      const messageMap = new Map();
      
      state.messages.forEach(msg => {
        messageMap.set(msg.id, msg);
      });
      
      messagesToAdd.forEach(msg => {
        if (msg && msg.id) {
          if (msg.id.startsWith('temp_') || msg.isPending) {
            const realVersion = messagesToAdd.find(m => 
              !m.isPending && m.client_id === msg.client_id
            );
            if (realVersion) {
              messageMap.set(realVersion.id, realVersion);
              messageMap.delete(msg.id);
              return;
            }
          }
          messageMap.set(msg.id, msg);
        }
      });
      
      const mergedMessages = Array.from(messageMap.values());
      
      mergedMessages.sort((a, b) => {
        const dateA = new Date(a.created_at || a.createdAt || 0);
        const dateB = new Date(b.created_at || b.createdAt || 0);
        return dateA - dateB;
      });
      
      state.messages = mergedMessages;
      
      if (state.currentChannel) {
        saveCachedMessages(state.currentChannel.id, mergedMessages);
      }
      
      scheduleRenderMessages(forceScroll);

      console.log(`✅ Merged ${messagesToAdd.length} messages, total: ${mergedMessages.length}`);
      
    } catch (error) {
      console.error('Error merging messages:', error);
    } finally {
      state.isMerging = false;
    }
  }

  // ============================================================
  // CACHED MESSAGES
  // ============================================================
  function getCachedMessages(channelId) {
    try {
      const cacheKey = `cached_chat_history_${channelId}`;
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        console.log(`📦 Loaded ${parsed.length} cached messages for channel ${channelId}`);
        return parsed;
      }
    } catch (e) {
      console.warn('Failed to load cached messages:', e);
    }
    return null;
  }

  function saveCachedMessages(channelId, messages) {
    try {
      const cacheKey = `cached_chat_history_${channelId}`;
      // FIX: increased from 50 to 100 so that after a "load older" page
      // the newly fetched older messages aren't immediately evicted from
      // cache on the next save, causing them to re-disappear after a
      // channel switch.
      const toCache = messages.slice(-100);
      localStorage.setItem(cacheKey, JSON.stringify(toCache));
      console.log(`💾 Cached ${toCache.length} messages for channel ${channelId}`);
    } catch (e) {
      console.warn('Failed to cache messages:', e);
    }
  }

  function clearCachedMessages(channelId) {
    try {
      const cacheKey = `cached_chat_history_${channelId}`;
      localStorage.removeItem(cacheKey);
    } catch (e) {
      console.warn('Failed to clear cached messages:', e);
    }
  }

  // ============================================================
  // FETCH FRESH HISTORY
  // ============================================================
  async function fetchFreshHistory(channelId) {
    if (!channelId) return;
    
    try {
      console.log('🔄 Fetching fresh message history...');
      
      // FIX: same +1 trick as loadMessages() so hasOlderMessages is
      // correctly maintained after a reconnect / tab-focus refresh too.
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .select('*')
        .eq('channel_id', channelId)
        .order('created_at', { ascending: false })
        .limit(MESSAGES_PER_PAGE + 1);

      if (error) {
        console.warn('Failed to fetch fresh history:', error);
        return;
      }

      if (data && data.length > 0) {
        const hasMore = data.length > MESSAGES_PER_PAGE;
        const page = hasMore ? data.slice(0, MESSAGES_PER_PAGE) : data;
        state.hasOlderMessages = hasMore;
        if (hasMore || !state.oldestLoadedTimestamp) {
          state.oldestLoadedTimestamp = page[page.length - 1]?.created_at || null;
        }
        mergeMessagesSafely(page);
        console.log(`✅ Fetched ${page.length} fresh messages`);
      }
      
      updateProfileScreen();
      
    } catch (error) {
      console.error('Error fetching fresh history:', error);
    }
  }

  // ============================================================
  // 8b. REALTIME MESSAGE SYNC
  // ============================================================
  let reconnectTimer = null;
  let reconnectAttempts = 0;
  let isIntentionalTeardown = false;

  function teardownMessagesSubscription() {
    if (!state.messagesSubscription) return;
    isIntentionalTeardown = true;
    supabase.removeChannel(state.messagesSubscription);
    isIntentionalTeardown = false;
    state.messagesSubscription = null;
  }

  function scheduleReconnect(channelId) {
    if (reconnectTimer) return;
    if (!state.currentChannel || state.currentChannel.id !== channelId) return;

    reconnectAttempts += 1;
    const delay = Math.min(30000, 2000 * Math.pow(2, reconnectAttempts - 1));
    console.log(`🔁 Reconnect attempt ${reconnectAttempts} in ${delay / 1000}s...`);

    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      if (state.currentChannel && state.currentChannel.id === channelId) {
        subscribeToMessages(channelId);
      }
    }, delay);
  }

  function subscribeToMessages(channelId) {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }

    teardownMessagesSubscription();

    let thisChannel;

    thisChannel = supabase
      .channel(`messages:${channelId}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: CONFIG.SUPABASE.TABLES.MESSAGES, 
        filter: `channel_id=eq.${channelId}` 
      }, async (payload) => {
        const newMessage = payload.new;
        
        if (state.messages.some(msg => msg.id === newMessage.id)) {
          console.log(`✋ Message ${newMessage.id} already exists, skipping`);
          return;
        }
        
        if (newMessage.client_id) {
          const optimisticIndex = state.messages.findIndex(m =>
            m.client_id === newMessage.client_id
          );

          if (optimisticIndex !== -1) {
            console.log(`✅ Replacing optimistic message (clientId: ${newMessage.client_id})`);
            state.messages[optimisticIndex] = newMessage;
            delete state.messages[optimisticIndex].isPending;
            state.messages.sort((a, b) => new Date(a.created_at || 0) - new Date(b.created_at || 0));
            scheduleRenderMessages();
            saveCachedMessages(channelId, state.messages);

            if (isKnownChannelId(channelId)) {
              state.channelPreviews[channelId] = newMessage;
              renderChatList(allChannels);
            }

            if (newMessage.username !== state.currentUser?.username) {
              console.log('🔔 New message from someone else - marking delivered');
              if (isChatDetailVisible(channelId)) {
                clearUnreadBadgeForChannel(channelId);
                await queueMarkSeen(channelId);
              }
            }
            return;
          }
        }
        
        console.log(`📥 Adding new message (ID: ${newMessage.id})`);
        mergeMessagesSafely(newMessage);

        if (isKnownChannelId(channelId)) {
          state.channelPreviews[channelId] = newMessage;
          renderChatList(allChannels);
        }

        // FIX: this used to unconditionally call refreshUnreadBadges()
        // here, then (below) separately queue up markDelivered/markSeen
        // when the chat is open — two independent async chains touching
        // the same badge state. When the chat IS open, skip straight to
        // clearUnreadBadgeForChannel() (instant, local) + queueMarkSeen()
        // (background persistence, which ends with its own
        // refreshUnreadBadges() to reconcile) — the person is looking
        // right at this message, there's nothing to wait on the network
        // for. Only channels the user *isn't* currently looking at need
        // the network-backed refresh to show their new unread count.
        if (newMessage.username !== state.currentUser?.username && isChatDetailVisible(channelId)) {
          console.log('🔔 New message from someone else - marking delivered');
          clearUnreadBadgeForChannel(channelId);
          await queueMarkSeen(channelId);
        } else {
          await refreshUnreadBadges();
        }

        if (state.inactivityTimer) {
          clearTimeout(state.inactivityTimer);
          state.inactivityTimer = null;
        }
      })
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: CONFIG.SUPABASE.TABLES.MESSAGES, 
        filter: `channel_id=eq.${channelId}` 
      }, (payload) => {
        const idx = state.messages.findIndex((m) => m.id === payload.new.id);
        if (idx !== -1) { 
          state.messages[idx] = payload.new; 
          scheduleRenderMessages();
          saveCachedMessages(channelId, state.messages);
        }
      })
      .on('postgres_changes', { 
        event: 'DELETE', 
        schema: 'public', 
        table: CONFIG.SUPABASE.TABLES.MESSAGES, 
        filter: `channel_id=eq.${channelId}` 
      }, (payload) => {
        const initialCount = state.messages.length;
        state.messages = state.messages.filter((m) => m.id !== payload.old.id);
        
        if (state.messages.length < initialCount) {
          console.log(`🗑️ Message deleted (ID: ${payload.old.id})`);
          scheduleRenderMessages();
          saveCachedMessages(channelId, state.messages);
        }
      })
      .on('broadcast', { event: 'typing' }, (payload) => {
        handleIncomingTyping(channelId, payload.payload);
      })
      .on('broadcast', { event: 'stopped_typing' }, (payload) => {
        handleIncomingStoppedTyping(channelId, payload.payload);
      })
      .subscribe((status, err) => {
        if (status === 'SUBSCRIBED') {
          reconnectAttempts = 0;
          state.isChannelActive = true;
          setConnectionIssue('messages', false);
          console.log(`✅ Subscribed to channel ${channelId}`);
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          if (isIntentionalTeardown) {
            console.log(`↩️ Channel ${status} for ${channelId} — intentional teardown, not reconnecting`);
            return;
          }

          if (err) console.error(`❌ Channel ${status} for ${channelId}:`, err.message || err);
          else console.error(`❌ Channel ${status} for ${channelId}`);
          state.isChannelActive = false;

          if (state.messagesSubscription === thisChannel) {
            state.messagesSubscription = null;
            scheduleReconnect(channelId);

            if (reconnectAttempts === 5) {
              console.warn(
                '⚠️ Realtime channel has failed to stay connected 5 times in a row. ' +
                'This usually means Realtime replication is not enabled for the ' +
                `"${CONFIG.SUPABASE.TABLES.MESSAGES}" table in the Supabase dashboard ` +
                '(Database → Replication), or a Row Level Security policy is blocking it — ' +
                'not a transient network issue. Still retrying, but check that config.'
              );
              setConnectionIssue('messages', true);
            }
          }
        }
      });

    state.messagesSubscription = thisChannel;
  }

  // ============================================================
  // 8c. REAL-TIME "TYPING…" INDICATOR
  // ============================================================
  const typingTimers = new Map();

  function getTypingUsernames(channelId) {
    const prefix = `${channelId}:`;
    return [...typingTimers.keys()]
      .filter((key) => key.startsWith(prefix))
      .map((key) => key.slice(prefix.length));
  }

  function handleIncomingTyping(channelId, payload) {
    if (!payload || !payload.username) return;
    if (payload.username === state.currentUser?.username) return;
    const key = `${channelId}:${payload.username}`;
    if (typingTimers.has(key)) clearTimeout(typingTimers.get(key));
    typingTimers.set(key, setTimeout(() => {
      typingTimers.delete(key);
      renderTypingIndicator(channelId);
    }, 3000));
    renderTypingIndicator(channelId);
  }

  function broadcastStoppedTyping() {
    if (!state.currentChannel || !state.messagesSubscription || !state.currentUser) return;
    state.lastTypingBroadcastAt = 0;
    state.messagesSubscription.send({
      type: 'broadcast',
      event: 'stopped_typing',
      payload: { username: state.currentUser.username },
    });
  }

  function handleIncomingStoppedTyping(channelId, payload) {
    if (!payload || !payload.username) return;
    if (payload.username === state.currentUser?.username) return;
    const key = `${channelId}:${payload.username}`;
    if (!typingTimers.has(key)) return;
    clearTimeout(typingTimers.get(key));
    typingTimers.delete(key);
    renderTypingIndicator(channelId);
  }

  function renderTypingIndicator(channelId) {
    if (!state.currentChannel || state.currentChannel.id !== channelId) return;
    if (!DOM.chatDetailSub) return;
    const names = getTypingUsernames(channelId).map(getDisplayName);
    if (names.length === 0) {
      updateChatDetailSubtitle();
      return;
    }
    DOM.chatDetailSub.textContent = names.length === 1
      ? `${names[0]} is typing…`
      : `${names.length} people are typing…`;
    DOM.chatDetailSub.classList.add('typing-active');
  }

  function clearTypingIndicator(channelId) {
    const prefix = `${channelId}:`;
    [...typingTimers.keys()]
      .filter((key) => key.startsWith(prefix))
      .forEach((key) => {
        clearTimeout(typingTimers.get(key));
        typingTimers.delete(key);
      });
  }

  function broadcastTyping() {
    if (!state.currentChannel || !state.messagesSubscription || !state.currentUser) return;
    const now = Date.now();
    if (now - state.lastTypingBroadcastAt < 2000) return;
    state.lastTypingBroadcastAt = now;
    state.messagesSubscription.send({
      type: 'broadcast',
      event: 'typing',
      payload: { username: state.currentUser.username },
    });
  }

  // ============================================================
  // LOAD MESSAGES
  // ============================================================
  const MESSAGES_PER_PAGE = 50;

  async function loadMessages(channelId) {
    if (!channelId) return;

    try {
      // FIX: root cause of "why the chat has been removed from a one
      // channel from day before yesterday including picture, videos, and
      // everything" — the old query fetched exactly 50 rows with no
      // pagination, so any channel with more than 50 messages simply
      // didn't show the older ones. The messages were never deleted; they
      // just fell outside the 50-row window.
      //
      // We now fetch 51 rows. If we get 51 back, we know there are more
      // in the DB older than row #51, so we slice it to 50 for display
      // and set hasOlderMessages = true — which causes renderMessages()
      // to show the "Load older messages" button at the top of the chat.
      // If we get ≤ 50 rows, we know we have the full history and
      // hasOlderMessages stays false.
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .select('*')
        .eq('channel_id', channelId)
        .order('created_at', { ascending: false })
        .limit(MESSAGES_PER_PAGE + 1);

      if (error) {
        console.warn('Messages fallback:', error);
        if (state.messages.length === 0) {
          state.messages = [{ id: '1', content: 'Welcome to the channel!', username: 'system', created_at: Date.now() }];
        }
        renderMessages(true);
        return;
      }

      if (data && data.length > 0) {
        const hasMore = data.length > MESSAGES_PER_PAGE;
        const page = hasMore ? data.slice(0, MESSAGES_PER_PAGE) : data;

        state.hasOlderMessages = hasMore;
        // The page is sorted descending from Supabase; the last item in
        // this slice is the oldest one currently loaded.
        state.oldestLoadedTimestamp = page[page.length - 1]?.created_at || null;

        mergeMessagesSafely(page, true);
        console.log(`📥 Loaded ${page.length} messages from Supabase${hasMore ? ' (more available — "Load older" button shown)' : ' (full history)'}`);
      } else if (state.messages.length === 0) {
        state.hasOlderMessages = false;
        state.oldestLoadedTimestamp = null;
        state.messages = [];
        renderMessages(true);
      }

      updateProfileScreen();
    } catch (error) {
      console.error('Error loading messages:', error);
      if (state.messages.length === 0) {
        state.messages = [{ id: '1', content: 'Welcome to the channel!', username: 'system', created_at: Date.now() }];
        renderMessages(true);
      }
    }
  }

  // ============================================================
  // LOAD OLDER MESSAGES (pagination)
  // ============================================================
  // FIX: previously there was no way to see messages older than the
  // initial 50-row window. This function loads the next page of 50
  // messages older than the earliest message currently in state.messages,
  // using the oldest message's created_at as a cursor (exclusive upper
  // bound via `.lt`). The button at the top of the chat that calls this
  // is rendered by renderMessages() whenever state.hasOlderMessages is
  // true and hidden once we know we have the full history.
  let isLoadingOlderMessages = false;

  async function loadOlderMessages() {
    if (isLoadingOlderMessages || !state.currentChannel || !state.oldestLoadedTimestamp) return;
    isLoadingOlderMessages = true;
    // FIX: replaced the button's "Loading…" text state with a loading
    // circle — show it the moment the fetch starts.
    renderLoadOlderIndicator();

    try {
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .select('*')
        .eq('channel_id', state.currentChannel.id)
        .lt('created_at', state.oldestLoadedTimestamp)
        .order('created_at', { ascending: false })
        .limit(MESSAGES_PER_PAGE + 1);

      if (error) {
        console.warn('Failed to load older messages:', error);
        return;
      }

      if (!data || data.length === 0) {
        state.hasOlderMessages = false;
        state.oldestLoadedTimestamp = null;
        renderMessages();
        return;
      }

      const hasMore = data.length > MESSAGES_PER_PAGE;
      const page = hasMore ? data.slice(0, MESSAGES_PER_PAGE) : data;

      state.hasOlderMessages = hasMore;
      // Update cursor to the oldest message in this new page
      state.oldestLoadedTimestamp = page[page.length - 1]?.created_at || null;

      // Preserve scroll position: record the first currently-visible
      // message's DOM node before we inject older messages above it, then
      // restore its position in the viewport after the render so the user
      // stays anchored where they were.
      const firstVisible = DOM.chatMessages?.querySelector('.msg');
      const scrollAnchorId = firstVisible?.dataset?.id || null;
      const anchorTopBefore = firstVisible ? firstVisible.getBoundingClientRect().top : 0;

      // Merge without forcing scroll to bottom (forceScroll = false)
      mergeMessagesSafely(page, false);
      saveCachedMessages(state.currentChannel.id, state.messages);

      // After the render settles, restore scroll position so the user
      // doesn't jump to the top.
      requestAnimationFrame(() => {
        if (scrollAnchorId) {
          const anchorEl = DOM.chatMessages?.querySelector(`.msg[data-id="${CSS.escape(scrollAnchorId)}"]`);
          if (anchorEl && DOM.chatContainer) {
            const anchorTopAfter = anchorEl.getBoundingClientRect().top;
            DOM.chatContainer.scrollTop += (anchorTopAfter - anchorTopBefore);
          }
        }
        renderLoadOlderIndicator();
      });

      console.log(`📜 Loaded ${page.length} older messages${hasMore ? ' (even more available)' : ' (reached beginning of chat)'}`);
    } catch (err) {
      console.error('Error loading older messages:', err);
    } finally {
      isLoadingOlderMessages = false;
      // FIX: hide the loading circle once the fetch settles (success,
      // empty page, or error).
      renderLoadOlderIndicator();
    }
  }

  // Injects (or removes) a small loading-circle indicator at the very top
  // of #chatMessages. FIX: this used to be a clickable "Load older
  // messages" button whose label swapped to the text "Loading…" mid-fetch;
  // it's now a non-interactive spinner that only appears while
  // isLoadingOlderMessages is true. Older history loads automatically as
  // the user scrolls near the top of the chat (see the scroll listener in
  // EVENT BINDINGS), so there's no idle "click to load" state to render.
  function renderLoadOlderIndicator() {
    if (!DOM.chatMessages) return;

    if (!isLoadingOlderMessages) {
      if (DOM.loadOlderBtn && DOM.loadOlderBtn.isConnected) {
        DOM.loadOlderBtn.remove();
      }
      DOM.loadOlderBtn = null;
      return;
    }

    if (!DOM.loadOlderBtn || !DOM.loadOlderBtn.isConnected) {
      const indicator = document.createElement('div');
      indicator.id = 'loadOlderBtn';
      indicator.className = 'load-older-indicator';
      indicator.innerHTML = '<span class="load-older-spinner" aria-hidden="true"></span>';
      DOM.loadOlderBtn = indicator;
    }

    // Always keep it as the very first child
    if (DOM.chatMessages.firstChild !== DOM.loadOlderBtn) {
      DOM.chatMessages.insertBefore(DOM.loadOlderBtn, DOM.chatMessages.firstChild);
    }
  }

  function ticksHtml(msg) {
    if (msg.seen_at) return `<span class="msg-ticks seen" title="Seen"><i class="fas fa-check-double"></i></span>`;
    if (msg.delivered_at) return `<span class="msg-ticks delivered" title="Delivered"><i class="fas fa-check-double"></i></span>`;
    return `<span class="msg-ticks" title="Sent"><i class="fas fa-check"></i></span>`;
  }

  // ============================================================
  // RENDER MESSAGES
  // ============================================================
  function messageSignature(msg) {
    // isMessageMediaExpired(msg) is included so that when a media message
    // crosses the 168h window, its signature changes and renderMessages()
    // rebuilds its bubble to show the "no longer available" placeholder.
    // Text-only messages are unaffected — isMessageMediaExpired returns
    // false for them because hasAttachment is false (no file_url).
    return JSON.stringify([
      msg.content, msg.file_url, msg.reply_to, msg.reply_username, msg.reply_content,
      msg.username, msg.created_at, msg.seen_at, msg.delivered_at, msg.isPending,
      msg.deleted_at, msg.deleted_by, isMessageMediaExpired(msg),
    ]);
  }

  // ============================================================
  // PDF THUMBNAIL PREVIEW
  // ============================================================
  const pdfThumbCache = new Map();
  const pdfThumbInFlight = new Map();

  function getPdfThumbnail(url) {
    if (pdfThumbCache.has(url)) return Promise.resolve(pdfThumbCache.get(url));
    if (pdfThumbInFlight.has(url)) return pdfThumbInFlight.get(url);
    if (!window.pdfjsLib) return Promise.resolve(null);

    const promise = pdfjsLib.getDocument(url).promise
      .then((pdf) => pdf.getPage(1))
      .then((page) => {
        const baseViewport = page.getViewport({ scale: 1 });
        const targetWidth = 360;
        const scale = targetWidth / baseViewport.width;
        const viewport = page.getViewport({ scale });

        const canvas = document.createElement('canvas');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext('2d');

        return page.render({ canvasContext: ctx, viewport }).promise
          .then(() => canvas.toDataURL('image/jpeg', 0.82));
      })
      .then((dataUrl) => {
        pdfThumbCache.set(url, dataUrl);
        pdfThumbInFlight.delete(url);
        return dataUrl;
      })
      .catch((err) => {
        console.warn(`PDF thumbnail failed for ${url}:`, err);
        pdfThumbCache.set(url, null);
        pdfThumbInFlight.delete(url);
        return null;
      });

    pdfThumbInFlight.set(url, promise);
    return promise;
  }

  // FIX: root cause of "scrolling up/down is not smooth and it keeps
  // returning to the last message" — isNearBottom() re-checks the LIVE
  // scroll position, on demand, instead of trusting a boolean snapshot
  // taken once at some earlier point in time. See stickToBottomOnMediaLoad()
  // below for why that distinction matters.
  const NEAR_BOTTOM_PX = 80;
  function isNearBottom() {
    if (!DOM.chatContainer) return true;
    return DOM.chatContainer.scrollHeight - DOM.chatContainer.scrollTop - DOM.chatContainer.clientHeight < NEAR_BOTTOM_PX;
  }

  // FIX: root cause of "scrolling up/down is not smooth and it keeps
  // returning to the last message" — `pinToBottom` here is just a snapshot
  // of "was the user near the bottom" taken once, back when the message
  // bubble was first built (see buildMessageEl()). But images use
  // loading="lazy", PDF thumbnails render asynchronously via pdf.js, and
  // link previews are fetched over the network — all of which can finish
  // loading seconds later, often while the user has since scrolled away to
  // read older messages. The old code fired scrollTop = scrollHeight
  // unconditionally whenever that load event eventually landed, with no
  // regard for where the user was actually scrolled to *at that moment* —
  // yanking them back to the bottom mid-scroll. `pinToBottom` is still
  // used as a cheap gate (skip attaching the listener at all for bubbles
  // built while already scrolled away), but the actual decision to jump is
  // made live, via isNearBottom(), at the instant the media finishes
  // loading — not from the stale snapshot.
  function stickToBottomOnMediaLoad(mediaEl, eventName, pinToBottom) {
    if (!mediaEl || !pinToBottom) return;
    mediaEl.addEventListener(eventName, () => {
      if (DOM.chatContainer && isNearBottom()) {
        DOM.chatContainer.scrollTop = DOM.chatContainer.scrollHeight;
      }
    }, { once: true });
  }

  function hydratePdfThumb(wrapEl, url, pinToBottom) {
    const thumbEl = wrapEl.querySelector('.msg-pdf-thumb');
    if (!thumbEl) return;
    getPdfThumbnail(url).then((dataUrl) => {
      if (!dataUrl || !thumbEl.isConnected) return;
      const img = document.createElement('img');
      img.className = 'msg-media-img';
      img.alt = 'PDF preview';
      img.loading = 'lazy';
      stickToBottomOnMediaLoad(img, 'load', pinToBottom);
      img.src = dataUrl;
      thumbEl.innerHTML = '';
      thumbEl.appendChild(img);
      thumbEl.classList.add('loaded');
    });
  }

  // ============================================================
  // LINK PREVIEW THUMBNAILS
  // ============================================================
  const LINK_PREVIEW_NEGATIVE_TTL_MS = 10 * 60 * 1000;
  const linkPreviewCache = new Map();
  const linkPreviewInFlight = new Map();

  function getLinkPreview(url) {
    const cached = linkPreviewCache.get(url);
    if (cached) {
      const stale = cached.value === null && (Date.now() - cached.ts) >= LINK_PREVIEW_NEGATIVE_TTL_MS;
      if (!stale) return Promise.resolve(cached.value);
      linkPreviewCache.delete(url);
    }
    if (linkPreviewInFlight.has(url)) return linkPreviewInFlight.get(url);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const promise = fetch(`https://api.microlink.io/?url=${encodeURIComponent(url)}`, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) {
          console.warn(`Link preview request for ${url} failed: HTTP ${res.status} ${res.statusText} (Microlink's free tier is rate-limited — this is expected if it's been called a lot recently; it will retry automatically in ${Math.round(LINK_PREVIEW_NEGATIVE_TTL_MS / 60000)} min)`);
        }
        return res.json();
      })
      .then((json) => {
        const data = json && json.status === 'success' ? json.data : null;
        const image = data && data.image && data.image.url;
        const logo = data && data.logo && data.logo.url;
        const preview = (data && (image || data.title)) ? {
          title: data.title || '',
          image: image || logo || null,
          siteName: (() => {
            try { return new URL(url).hostname.replace(/^www\./, ''); }
            catch { return ''; }
          })(),
        } : null;
        linkPreviewCache.set(url, { value: preview, ts: Date.now() });
        return preview;
      })
      .catch((err) => {
        console.warn(`Link preview failed for ${url}:`, err);
        linkPreviewCache.set(url, { value: null, ts: Date.now() });
        return null;
      })
      .finally(() => {
        clearTimeout(timeoutId);
        linkPreviewInFlight.delete(url);
      });

    linkPreviewInFlight.set(url, promise);
    return promise;
  }

  function hydrateLinkPreview(slotEl, url, pinToBottom) {
    if (!slotEl) return;
    getLinkPreview(url).then((preview) => {
      if (!preview || !slotEl.isConnected) return;
      slotEl.classList.remove('hidden');
      slotEl.innerHTML = `
        <a href="${escapeHtml(url)}" rel="noopener" class="msg-link-preview">
          ${preview.image ? `<img class="msg-link-preview-img" src="${escapeHtml(preview.image)}" alt="" loading="lazy">` : ''}
          <span class="msg-link-preview-body">
            ${preview.title ? `<span class="msg-link-preview-title">${escapeHtml(truncate(preview.title, 90))}</span>` : ''}
            <span class="msg-link-preview-site">${escapeHtml(preview.siteName)}</span>
          </span>
        </a>
      `;
      const img = slotEl.querySelector('img.msg-link-preview-img');
      if (img) stickToBottomOnMediaLoad(img, 'load', pinToBottom);
    });
  }

  // Media (pictures, videos, PDFs) expire after 168 hours — the "no longer
  // available" placeholder replaces the attachment bubble once this window
  // passes. Text-only messages are never affected: hasAttachment (see
  // buildMessageEl) is false when file_url is null, so mediaExpired is
  // always false for pure-text messages regardless of age. They are kept
  // permanently until the group is deleted.
  const MESSAGE_MEDIA_EXPIRY_MS = 168 * 60 * 60 * 1000;

  function isMessageMediaExpired(msg) {
    if (!msg || !msg.created_at) return false;
    return (Date.now() - new Date(msg.created_at).getTime()) >= MESSAGE_MEDIA_EXPIRY_MS;
  }

  // FIX: the placeholder text below used to read "Can't view this media
  // because it's no longer on your device" — the media was never on the
  // viewer's device to begin with (it lived in Supabase Storage), so that
  // wording was actively misleading about what happened. It's the file
  // itself that's gone after the 168h retention window, so say that.
  const MESSAGE_MEDIA_EXPIRED_TEXT = "This file is no longer available for download";

  // Shared markup for the expired-attachment bubble — used both when
  // isMessageMediaExpired() says a message has aged past the 168h window,
  // AND (see attachMediaFailureHandler() below) when an image/video
  // actually fails to load before that — e.g. someone manually deleted the
  // object straight from the R2/Storage dashboard. Age alone can't catch
  // that second case, since created_at hasn't changed; only a real load
  // failure can, which is why this needs to be reachable from both places.
  function mediaExpiredBubbleHtml(ticksMarkup) {
    const inlineTicks = ticksMarkup ? `<span class="msg-inline-ticks">${ticksMarkup}</span>` : '';
    return `
      <div class="msg-bubble msg-media-expired">
        <i class="fas fa-file-circle-xmark"></i> ${escapeHtml(MESSAGE_MEDIA_EXPIRED_TEXT)}${inlineTicks}
      </div>
    `;
  }

  // FIX: root cause of "manually deleting a file from R2/Storage shows a
  // broken image icon instead of the custom expired message" —
  // isMessageMediaExpired() only ever checked the message's age, which
  // can't detect a file that was deleted early (out-of-band, not via the
  // normal 168h flow). This listens for the browser's own 'error' event
  // (fires on a 404/failed load) and swaps the whole media bubble for the
  // same placeholder used for a normally-expired attachment, so a manual
  // delete looks the same as an aged-out one instead of a raw broken icon.
  function attachMediaFailureHandler(el, ticksMarkup) {
    if (!el) return;
    el.addEventListener('error', () => {
      const container = el.closest('.msg-media-preview');
      if (container) container.outerHTML = mediaExpiredBubbleHtml(ticksMarkup);
    }, { once: true });
  }

  // FIX: root cause of "the expired-media message never shows up, media
  // just silently stays broken" — isMessageMediaExpired() is a pure
  // function of the current time vs. created_at, but nothing was ever
  // re-evaluating it *as time passed*. renderMessages() only runs when
  // something else changes the message list (a new message arrives, a
  // read receipt updates, a reconnect happens, etc.), so a chat opened
  // and then just left sitting (or an already-rendered message nobody
  // touches again) would never get re-checked once the 7-day mark
  // actually passed — the DOM kept showing the same image/video/file link
  // it always had, now pointing at a deleted file, forever. This timer
  // exists purely to make sure a renderMessages() pass actually happens
  // periodically while a chat is open, so the messageSignature() change
  // above (which now flips once isMessageMediaExpired(msg) flips) has a
  // chance to take effect close to when it actually should. A 60s tick is
  // more than fine against a 7-day window.
  const MEDIA_EXPIRY_WATCH_INTERVAL = 60 * 1000;
  let mediaExpiryWatcherTimer = null;

  function startMediaExpiryWatcher() {
    stopMediaExpiryWatcher();
    mediaExpiryWatcherTimer = setInterval(() => {
      if (!state.currentChannel || !state.messages.length) return;
      if (!DOM.screenChatDetail || DOM.screenChatDetail.classList.contains('hidden')) return;
      renderMessages();
    }, MEDIA_EXPIRY_WATCH_INTERVAL);
  }

  function stopMediaExpiryWatcher() {
    if (mediaExpiryWatcherTimer) {
      clearInterval(mediaExpiryWatcherTimer);
      mediaExpiryWatcherTimer = null;
    }
  }

  function buildMessageEl(msg, signature, pinToBottom, skipEnterAnim) {
    const isMine = msg.username === state.currentUser?.username;
    const wrap = document.createElement('div');
    wrap.className = `msg ${isMine ? 'msg-mine' : 'msg-theirs'}${skipEnterAnim ? ' msg-no-enter-anim' : ''}`;
    wrap.dataset.id = msg.id;
    wrap.dataset.role = roleKey(msg.username);
    wrap.dataset.sig = signature;
    wrap.dataset.clientId = msg.client_id || '';

    let replyHtml = '';
    if (msg.reply_to) {
      // FIX: "reply bubble is huge / distorted" — this used to be a
      // multi-line template literal. That's normally invisible, but this
      // markup gets injected straight into .msg-bubble, which sets
      // white-space:pre-wrap so real newlines in a user's message render
      // as real line breaks. pre-wrap doesn't know the difference between
      // "a newline the user typed" and "indentation left over from how the
      // JS template literal was formatted" — it preserved both, so the
      // whitespace between </div>/<span> tags rendered as visible blank
      // lines, inflating the quote box height. Built as one unbroken
      // string now so there's no stray whitespace/newline text nodes left
      // for pre-wrap to render. (Also backstopped in CSS — see
      // .msg-reply-quote's white-space:normal in styles.css — in case this
      // ever gets reformatted back into a multi-line template by mistake.)
      const replyAuthor = escapeHtml(getDisplayName(msg.reply_username || 'Message'));
      const replyText = escapeHtml(truncate(msg.reply_content || '', 60));
      replyHtml = `<div class="msg-reply-quote" data-reply-to-id="${escapeHtml(String(msg.reply_to))}" role="button" tabindex="0"><span class="reply-author">${replyAuthor}</span><span class="reply-text">${replyText}</span></div>`;
    }

    const ticksMarkup = (isMine && !msg.deleted_at) ? ticksHtml(msg) : '';
    const hasAttachment = !!msg.file_url && !msg.deleted_at;
    const mediaExpired = hasAttachment && isMessageMediaExpired(msg);

    const linkUrl = (!hasAttachment && msg.content) ? firstUrlIn(msg.content) : null;

    let bubbleHtml = '';
    if (msg.deleted_at) {
      bubbleHtml = `<div class="msg-bubble msg-deleted"><i class="fas fa-ban"></i> This message was deleted by Nous Complex admin</div>`;
    } else if (msg.content) {
      const inlineTicks = (!hasAttachment && ticksMarkup) ? `<span class="msg-bubble-ticks">${ticksMarkup}</span>` : '';
      bubbleHtml += `<div class="msg-bubble">${replyHtml}${linkifyText(msg.content)}${inlineTicks}</div>`;
      if (linkUrl) bubbleHtml += `<div class="msg-link-preview-slot hidden"></div>`;
    } else if (replyHtml) {
      const inlineTicks = (!hasAttachment && ticksMarkup) ? `<span class="msg-bubble-ticks">${ticksMarkup}</span>` : '';
      bubbleHtml += `<div class="msg-bubble">${replyHtml}${inlineTicks}</div>`;
    }
    if (hasAttachment) {
      const cornerTicks = ticksMarkup ? `<span class="msg-corner-ticks">${ticksMarkup}</span>` : '';
      if (mediaExpired) {
        bubbleHtml += mediaExpiredBubbleHtml(ticksMarkup);
      } else if (isImageFile(msg.file_url)) {
        bubbleHtml += `
          <div class="msg-media-preview" data-media-url="${escapeHtml(msg.file_url)}">
            <img class="msg-media-img" src="${escapeHtml(msg.file_url)}" alt="Attached image" loading="lazy">
            <span class="msg-media-expand"><i class="fas fa-expand"></i></span>
            ${cornerTicks}
          </div>
        `;
      } else if (isVideoFile(msg.file_url)) {
        bubbleHtml += `
          <div class="msg-media-preview msg-media-video-wrap">
            <video class="msg-media-img" src="${escapeHtml(msg.file_url)}" controls preload="metadata"></video>
            ${cornerTicks}
          </div>
        `;
      } else if (isPdfFile(msg.file_url)) {
        const fileName = getFileNameFromUrl(msg.file_url);
        const inlineTicks = ticksMarkup ? `<span class="msg-inline-ticks">${ticksMarkup}</span>` : '';
        bubbleHtml += `
          <a href="${escapeHtml(msg.file_url)}" data-file-name="${escapeHtml(fileName)}" target="_blank" rel="noopener" class="msg-doc-card msg-pdf-card">
            <div class="msg-pdf-thumb"><i class="fas fa-file-pdf"></i></div>
            <div class="msg-pdf-info-bar">
              <span class="msg-doc-icon"><i class="fas fa-file-pdf"></i></span>
              <span class="msg-doc-info">
                <span class="msg-doc-name">${escapeHtml(fileName)}</span>
                <span class="msg-doc-ext">PDF</span>
              </span>
              <span class="msg-doc-download"><i class="fas fa-download"></i></span>
              ${inlineTicks}
            </div>
          </a>
        `;
      } else {
        const fileName = getFileNameFromUrl(msg.file_url);
        const ext = getFileExt(fileName);
        const inlineTicks = ticksMarkup ? `<span class="msg-inline-ticks">${ticksMarkup}</span>` : '';
        bubbleHtml += `
          <a href="${escapeHtml(msg.file_url)}" data-file-name="${escapeHtml(fileName)}" target="_blank" rel="noopener" class="msg-doc-card">
            <span class="msg-doc-icon"><i class="fas ${getFileIconClass(ext)}"></i></span>
            <span class="msg-doc-info">
              <span class="msg-doc-name">${escapeHtml(fileName)}</span>
              <span class="msg-doc-ext">${escapeHtml(ext || 'FILE')}</span>
            </span>
            <span class="msg-doc-download"><i class="fas fa-download"></i></span>
            ${inlineTicks}
          </a>
        `;
      }
    }

    // FIX: safety net for rows the *old* purge function already nulled
    // out before this fix — those messages have no file_url, no content,
    // and no reply left, so nothing above produces any bubble at all
    // (this is exactly the "just sender name is showing" bug). There's
    // no way to recover what those rows used to contain (file_url was
    // the only record of it), but a message can never be sent with
    // neither text nor a file (see the `if (!content && !file) return;`
    // guard on the composer's send handler), so any message that still
    // ends up with a fully empty bubbleHtml here is guaranteed to be one
    // of these already-purged rows rather than a legitimate empty
    // message. Show the same placeholder instead of leaving it blank.
    if (!bubbleHtml) {
      bubbleHtml = mediaExpiredBubbleHtml(ticksMarkup);
    }

    const displayName = getDisplayName(msg.username);
    wrap.innerHTML = `
      ${avatarHtml(msg.username, 'sm')}
      <div class="msg-body">
        <div class="msg-meta">
          <span class="msg-author">${escapeHtml(displayName)}</span>
          <span class="msg-time">${formatDate(msg.created_at)}</span>
        </div>
        ${bubbleHtml}
      </div>
    `;

    if (hasAttachment && !mediaExpired && isPdfFile(msg.file_url)) {
      hydratePdfThumb(wrap, msg.file_url, pinToBottom);
    } else if (hasAttachment && !mediaExpired && isImageFile(msg.file_url)) {
      const imgEl = wrap.querySelector('img.msg-media-img');
      stickToBottomOnMediaLoad(imgEl, 'load', pinToBottom);
      attachMediaFailureHandler(imgEl, ticksMarkup);
    } else if (hasAttachment && !mediaExpired && isVideoFile(msg.file_url)) {
      const videoEl = wrap.querySelector('video.msg-media-img');
      stickToBottomOnMediaLoad(videoEl, 'loadedmetadata', pinToBottom);
      attachMediaFailureHandler(videoEl, ticksMarkup);
    }

    if (linkUrl) {
      hydrateLinkPreview(wrap.querySelector('.msg-link-preview-slot'), linkUrl, pinToBottom);
    }

    return wrap;
  }

  let chatNeedsInitialPaint = false;

  function renderMessages(forceScrollBottom) {
    if (!DOM.chatMessages) return;

    const isInitialPaint = chatNeedsInitialPaint;

    if (!state.messages.length) {
      DOM.chatMessages.innerHTML = '<div class="empty-note center-text" style="width:100%;">No Messages Yet</div>';
      return;
    }

    if (!DOM.chatMessages.querySelector('.msg')) {
      DOM.chatMessages.innerHTML = '';
    }

    const existingNodes = new Map();
    const existingByClientId = new Map();
    DOM.chatMessages.querySelectorAll('.msg, .day-divider').forEach((el) => {
      if (el.classList.contains('day-divider')) {
        existingNodes.set(`day:${el.dataset.day}`, el);
        return;
      }
      const key = `msg:${el.dataset.id}`;
      existingNodes.set(key, el);
      if (el.dataset.clientId) {
        existingByClientId.set(`client:${el.dataset.clientId}`, key);
      }
    });

    const wasNearBottom = forceScrollBottom || isNearBottom();

    let prevNode = null;
    let changed = false;
    let lastDayKey = null;

    state.messages.forEach((msg) => {
      const dk = dayKey(msg.created_at);
      if (dk !== lastDayKey) {
        lastDayKey = dk;
        const dividerKey = `day:${dk}`;
        let dividerNode = existingNodes.get(dividerKey);
        if (dividerNode) {
          existingNodes.delete(dividerKey);
        } else {
          dividerNode = buildDayDivider(dk, formatDayLabel(msg.created_at));
          changed = true;
        }
        const desiredNext = prevNode ? prevNode.nextSibling : DOM.chatMessages.firstChild;
        if (desiredNext !== dividerNode) {
          DOM.chatMessages.insertBefore(dividerNode, desiredNext);
          changed = true;
        }
        prevNode = dividerNode;
      }

      let key = `msg:${msg.id}`;
      const signature = messageSignature(msg);
      let node = existingNodes.get(key);
      let alreadyOnScreen = !!node;

      if (!node && msg.client_id) {
        const fallbackKey = existingByClientId.get(`client:${msg.client_id}`);
        if (fallbackKey) {
          node = existingNodes.get(fallbackKey);
          key = fallbackKey;
          alreadyOnScreen = true;
        }
      }

      if (node && node.dataset.sig === signature) {
        existingNodes.delete(key);
      } else {
        const freshNode = buildMessageEl(msg, signature, wasNearBottom, isInitialPaint || alreadyOnScreen);
        if (node) {
          node.replaceWith(freshNode);
          existingNodes.delete(key);
        }
        node = freshNode;
        changed = true;
      }

      const desiredNext = prevNode ? prevNode.nextSibling : DOM.chatMessages.firstChild;
      if (desiredNext !== node) {
        DOM.chatMessages.insertBefore(node, desiredNext);
        changed = true;
      }
      prevNode = node;
    });

    existingNodes.forEach((el) => { el.remove(); changed = true; });

    if (changed && wasNearBottom && DOM.chatContainer) {
      DOM.chatContainer.scrollTop = DOM.chatContainer.scrollHeight;
    }

    chatNeedsInitialPaint = false;

    // FIX: keep the loading-circle indicator in sync (e.g. re-anchor it
    // as the first child) every time the message list is rendered.
    renderLoadOlderIndicator();

    reapplySelectionHighlight();
  }

  let renderMessagesQueued = false;
  let renderMessagesForceScroll = false;

  function scheduleRenderMessages(forceScrollBottom) {
    if (forceScrollBottom) renderMessagesForceScroll = true;
    if (renderMessagesQueued) return;
    renderMessagesQueued = true;
    requestAnimationFrame(() => {
      renderMessagesQueued = false;
      const force = renderMessagesForceScroll;
      renderMessagesForceScroll = false;
      renderMessages(force);
    });
  }

  function scrollToBottom() {
    if (DOM.chatContainer) {
      DOM.chatContainer.scrollTop = DOM.chatContainer.scrollHeight;
    }
  }

  async function deleteMessage(messageId) {
    if (!confirm('Delete this message for everyone?')) return;

    const deletedAt = new Date().toISOString();
    const deletedBy = state.currentUser?.username || 'admin';

    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MESSAGES)
      .update({
        content: null,
        file_url: null,
        deleted_at: deletedAt,
        deleted_by: deletedBy,
      })
      .eq('id', messageId)
      .select();

    if (error) { alert('Delete failed: ' + error.message); return; }
    if (!data || data.length === 0) {
      alert('Delete failed: the server didn\'t allow this change (likely a permissions/RLS issue) — the message was NOT deleted. Check that the admin-only UPDATE policy on messages is set up correctly (see soft_delete_messages.sql) and that this account\'s role is exactly "admin".');
      return;
    }

    const idx = state.messages.findIndex((m) => m.id === messageId);
    if (idx !== -1) {
      state.messages[idx] = {
        ...state.messages[idx],
        content: null,
        file_url: null,
        deleted_at: deletedAt,
        deleted_by: deletedBy,
      };
    }
    renderMessages();
    if (state.currentChannel) {
      saveCachedMessages(state.currentChannel.id, state.messages);
    }
  }

  let longPressTimer = null;
  let selectedMessageId = null;

  function clearLongPressTimer() {
    if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
  }

  function startLongPress(e) {
    const bubbleWrap = e.target.closest('.msg');
    if (!bubbleWrap || !bubbleWrap.dataset.id || bubbleWrap.querySelector('.msg-deleted')) return;
    if (e.target.closest('.msg-media-preview, .msg-doc-card')) return;
    clearLongPressTimer();
    longPressTimer = setTimeout(() => {
      selectMessageForInfo(bubbleWrap);
    }, 500);
  }

  DOM.chatMessages.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.msg')) e.preventDefault();
  });

  DOM.chatMessages.addEventListener('touchstart', startLongPress, { passive: true });
  ['touchend', 'touchmove', 'touchcancel'].forEach((evt) => {
    DOM.chatMessages.addEventListener(evt, clearLongPressTimer);
  });

  DOM.chatMessages.addEventListener('click', (e) => {
    if (Date.now() < suppressChatOpenClicksUntil) return;
    if (!isDesktopLayout()) return;
    const bubbleWrap = e.target.closest('.msg');
    if (!bubbleWrap || !bubbleWrap.dataset.id) return;
    if (bubbleWrap.querySelector('.msg-deleted')) return;
    if (e.target.closest('.msg-media-preview, .msg-doc-card')) return;
    if (e.target.closest('a.msg-link, a.msg-link-preview')) return;
    selectMessageForInfo(bubbleWrap);
  });

  function selectMessageForInfo(bubbleWrap) {
    const msg = state.messages.find((m) => m.id === bubbleWrap.dataset.id);
    if (!msg || msg.deleted_at) return;
    const isMine = msg.username === state.currentUser?.username;

    exitMessageSelection();
    selectedMessageId = bubbleWrap.dataset.id;
    bubbleWrap.classList.add('msg-selected');

    if (DOM.chatDetailHeader) DOM.chatDetailHeader.classList.add('hidden');
    if (DOM.msgSelectHeader) DOM.msgSelectHeader.classList.remove('hidden');
    if (DOM.msgSelectCount) DOM.msgSelectCount.textContent = '1 selected';

    if (DOM.msgSelectCopyBtn) DOM.msgSelectCopyBtn.classList.toggle('hidden', !msg.content);
    if (DOM.msgSelectDeleteBtn) DOM.msgSelectDeleteBtn.classList.toggle('hidden', !state.isAdmin);
    // FIX: root cause of "admin can't see the viewers of teachers or
    // students message" — this only showed the "Message info" ("Seen by")
    // button for a message's own sender, so an admin looking at a teacher's
    // or student's message had no way to open the read-receipt list, even
    // though loadMessageReads() already loads read receipts for every
    // message in the channel, not just the current user's own — the data
    // was there, the button just wasn't. Admins can now open it for
    // anyone's message; non-admins still only get it for their own.
    if (DOM.msgSelectInfoBtn) DOM.msgSelectInfoBtn.classList.toggle('hidden', !(isMine || state.isAdmin));
  }

  function exitMessageSelection() {
    if (!selectedMessageId) return;
    const prev = DOM.chatMessages.querySelector('.msg-selected');
    if (prev) prev.classList.remove('msg-selected');
    selectedMessageId = null;

    if (DOM.msgSelectHeader) DOM.msgSelectHeader.classList.add('hidden');
    if (DOM.chatDetailHeader) DOM.chatDetailHeader.classList.remove('hidden');
  }

  function reapplySelectionHighlight() {
    if (!selectedMessageId) return;
    const el = DOM.chatMessages.querySelector(`.msg[data-id="${CSS.escape(selectedMessageId)}"]`);
    if (el) el.classList.add('msg-selected');
  }

  function getSelectedMessage() {
    return state.messages.find((m) => m.id === selectedMessageId) || null;
  }

  if (DOM.msgSelectCloseBtn) DOM.msgSelectCloseBtn.addEventListener('click', exitMessageSelection);

  if (DOM.msgSelectInfoBtn) {
    DOM.msgSelectInfoBtn.addEventListener('click', () => {
      const msg = getSelectedMessage();
      exitMessageSelection();
      if (msg) openMessageInfoModal(msg);
    });
  }

  if (DOM.msgSelectReplyBtn) {
    DOM.msgSelectReplyBtn.addEventListener('click', () => {
      const msg = getSelectedMessage();
      exitMessageSelection();
      startReplyTo(msg);
    });
  }

  if (DOM.msgSelectCopyBtn) {
    DOM.msgSelectCopyBtn.addEventListener('click', async () => {
      const msg = getSelectedMessage();
      exitMessageSelection();
      if (!msg || !msg.content) return;
      try {
        await navigator.clipboard.writeText(msg.content);
      } catch (e) {
        console.warn('Clipboard write failed:', e);
        alert('Could not copy automatically — your browser blocked clipboard access.');
      }
    });
  }

  if (DOM.msgSelectDeleteBtn) {
    DOM.msgSelectDeleteBtn.addEventListener('click', () => {
      const msg = getSelectedMessage();
      exitMessageSelection();
      if (msg) deleteMessage(msg.id);
    });
  }

  if (DOM.msgSelectForwardBtn) {
    DOM.msgSelectForwardBtn.addEventListener('click', () => {
      const msg = getSelectedMessage();
      exitMessageSelection();
      if (msg) openForwardPicker(msg);
    });
  }

  function openForwardPicker(msg) {
    const targets = allChannels.filter((c) => !state.currentChannel || c.id !== state.currentChannel.id);

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card">
        <div class="modal-title"><i class="fas fa-share"></i> Forward to</div>
        <div class="forward-channel-list">
          ${targets.length
            ? targets.map((c) => `
                <button class="forward-channel-row" data-channel-id="${escapeHtml(String(c.id))}">
                  <i class="fas fa-hashtag" style="color:var(--chat-accent);"></i>
                  <span class="forward-channel-name">${escapeHtml(c.name)}</span>
                </button>
              `).join('')
            : `<div class="empty-note">No other channels to forward to</div>`}
        </div>
        <button class="btn-secondary msg-info-close" style="width:100%;">Cancel</button>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.msg-info-close').addEventListener('click', close);

    overlay.querySelectorAll('.forward-channel-row').forEach((row) => {
      row.addEventListener('click', async () => {
        close();
        await forwardMessageToChannel(msg, row.dataset.channelId);
      });
    });
  }

  async function forwardMessageToChannel(msg, targetChannelId) {
    if (!state.currentUser) return;
    // FIX: forwarding an already-expired attachment used to carry its
    // (now purged) file_url straight into the new message row. The new
    // message gets a fresh created_at, so isMessageMediaExpired() sees it
    // as brand new and buildMessageEl tries to render it as live media —
    // pointing at either the EXPIRED_MARKER sentinel or a deleted storage
    // object, i.e. a broken link, instead of correctly showing nothing/
    // the expired placeholder. Don't carry forward a file_url that's
    // already past its expiry window.
    const forwardableFileUrl = (msg.file_url && !isMessageMediaExpired(msg)) ? msg.file_url : null;
    const payload = {
      channel_id: targetChannelId,
      username: state.currentUser.username,
      content: msg.content || '',
      file_url: forwardableFileUrl,
      client_id: `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };
    const { error } = await supabase.from(CONFIG.SUPABASE.TABLES.MESSAGES).insert(payload);
    if (error) {
      console.error('Forward failed:', error);
      alert('Forward failed: ' + error.message);
      return;
    }
    const targetName = allChannels.find((c) => String(c.id) === String(targetChannelId))?.name || 'the channel';
    alert(`Forwarded to ${targetName}.`);
  }

  function openMessageInfoModal(msg) {
    const reads = (state.messageReads.get(msg.id) || [])
      .slice()
      .sort((a, b) => new Date(a.seen_at) - new Date(b.seen_at));
    const readUsernames = new Set(reads.map((r) => r.username));

    // FIX: was `m.username !== state.currentUser?.username` only — correct
    // back when this modal could only ever be opened for your OWN message
    // (currentUser was always the sender), but now an admin can open it for
    // a teacher's/student's message too, where currentUser (the admin) and
    // msg.username (the sender) are two different people. Without also
    // excluding the sender here, the sender showed up listed as "delivered"
    // or "not delivered" on their own message, which doesn't make sense —
    // a message obviously reached its own author.
    const others = state.currentMembers.filter((m) => m.username !== state.currentUser?.username && m.username !== msg.username);
    const delivered = [];
    const notDelivered = [];
    others.forEach((m) => {
      if (readUsernames.has(m.username)) return;
      if (state.onlineUsers.has((m.username || '').toLowerCase())) {
        delivered.push(m.username);
      } else {
        notDelivered.push(m.username);
      }
    });

    const rowHtml = (username, timeHtml) => `
      <div class="msg-info-row">
        ${avatarHtml(username, 'sm')}
        <span class="msg-info-name">${escapeHtml(getDisplayName(username))}</span>
        ${timeHtml}
      </div>
    `;

    const readRows = reads.length
      ? reads.map((r) => rowHtml(r.username, `<span class="msg-info-time">${escapeHtml(formatFullDate(r.seen_at))}</span>`)).join('')
      : `<div class="empty-note">No one yet</div>`;

    const deliveredRows = delivered.length
      ? delivered.map((u) => rowHtml(u, `<span class="msg-info-time">Delivered</span>`)).join('')
      : `<div class="empty-note">No one in this state</div>`;

    const notDeliveredRows = notDelivered.length
      ? notDelivered.map((u) => rowHtml(u, `<span class="msg-info-time msg-info-notdelivered">Not delivered</span>`)).join('')
      : `<div class="empty-note">No one in this state</div>`;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card">
        <div class="modal-title"><i class="fas fa-circle-info"></i> Message info</div>
        <div class="msg-info-section-label">Seen (${reads.length})</div>
        <div class="msg-info-list">${readRows}</div>
        <div class="msg-info-section-label">Delivered, not seen (${delivered.length})</div>
        <div class="msg-info-list">${deliveredRows}</div>
        <div class="msg-info-section-label">Not delivered (${notDelivered.length})</div>
        <div class="msg-info-list">${notDeliveredRows}</div>
        <button class="btn-secondary msg-info-close" style="width:100%; margin-top:14px;">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.msg-info-close').addEventListener('click', close);
  }

  function startReplyTo(msg) {
    if (!msg) return;
    state.replyingTo = msg;
    DOM.replyPreviewAuthor.textContent = getDisplayName(msg.username);
    DOM.replyPreviewText.textContent = msg.content || (msg.file_url ? 'Attached file' : '');
    DOM.replyPreview.classList.remove('hidden');
    DOM.messageInput.focus();
  }

  function jumpToMessage(id) {
    if (!id) return;
    const target = DOM.chatMessages.querySelector(`.msg[data-id="${cssEscape(id)}"]`);
    if (!target) {
      showToast("Original message isn't loaded");
      return;
    }
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    target.classList.add('msg-highlight');
    setTimeout(() => target.classList.remove('msg-highlight'), 1500);
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === 'function') return CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function showToast(message) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2200);
  }

  DOM.chatMessages.addEventListener('click', (e) => {
    if (Date.now() < suppressChatOpenClicksUntil) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    const replyQuote = e.target.closest('.msg-reply-quote[data-reply-to-id]');
    if (replyQuote) {
      jumpToMessage(replyQuote.dataset.replyToId);
      return;
    }

    const mediaPreview = e.target.closest('.msg-media-preview:not(.msg-media-video-wrap)');
    if (mediaPreview) {
      openImageLightbox(mediaPreview.dataset.mediaUrl);
      return;
    }

    const docCard = e.target.closest('.msg-doc-card');
    if (docCard) {
      e.preventDefault();
      const url = docCard.getAttribute('href');
      const fileName = docCard.dataset.fileName || getFileNameFromUrl(url);
      openDocViewer(url, fileName);
      return;
    }

    const sharedLink = e.target.closest('a.msg-link, a.msg-link-preview');
    if (sharedLink) {
      e.preventDefault();
      e.stopPropagation();
      openExternalLink(sharedLink.getAttribute('href'));
      return;
    }
  });

  DOM.chatMessages.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const replyQuote = e.target.closest('.msg-reply-quote[data-reply-to-id]');
    if (replyQuote) {
      e.preventDefault();
      jumpToMessage(replyQuote.dataset.replyToId);
    }
  });

  function openDocViewer(url, fileName) {
    if (!url) return;
    const canPreviewInline = isPdfFile(url);
    const overlay = document.createElement('div');
    overlay.className = 'lightbox-overlay doc-viewer-overlay';
    overlay.innerHTML = `
      <div class="doc-viewer-panel">
        <div class="doc-viewer-header">
          <span class="doc-viewer-name">${escapeHtml(fileName)}</span>
          <div class="doc-viewer-actions">
            <button type="button" class="icon-btn doc-viewer-download" title="Download" aria-label="Download"><i class="fas fa-download"></i></button>
            <button type="button" class="icon-btn doc-viewer-close" title="Close" aria-label="Close"><i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="doc-viewer-body">
          ${canPreviewInline
            ? `<iframe class="doc-viewer-frame" src="${escapeHtml(url)}" title="${escapeHtml(fileName)}"></iframe>`
            : `<div class="doc-viewer-no-preview"><i class="fas fa-file"></i><p>Preview isn't available for this file type.</p></div>`
          }
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    state.activeLightbox = overlay;

    const close = () => {
      if (state.activeLightbox === overlay) state.activeLightbox = null;
      overlay.remove();
    };
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.doc-viewer-close').addEventListener('click', close);
    overlay.querySelector('.doc-viewer-download').addEventListener('click', () => downloadAttachment(url, fileName));
  }

  async function downloadAttachment(url, fileName) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = fileName || 'file';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
    } catch (e) {
      console.warn('Blob download failed, falling back to a direct link:', e);
      window.open(url, '_blank', 'noopener');
    }
  }

  function openImageLightbox(url, mediaList, startIndex) {
    if (!url) return;
    const gallery = Array.isArray(mediaList) ? mediaList.filter(Boolean) : [];
    const hasGallery = gallery.length > 1;
    let index = hasGallery
      ? (Number.isInteger(startIndex) && startIndex >= 0 && startIndex < gallery.length ? startIndex : Math.max(0, gallery.indexOf(url)))
      : 0;

    const overlay = document.createElement('div');
    overlay.className = 'lightbox-overlay';
    overlay.innerHTML = `
      <button class="lightbox-close" aria-label="Close"><i class="fas fa-times"></i></button>
      ${hasGallery ? `
        <button class="lightbox-nav lightbox-prev" aria-label="Previous image"><i class="fas fa-chevron-left"></i></button>
        <button class="lightbox-nav lightbox-next" aria-label="Next image"><i class="fas fa-chevron-right"></i></button>
      ` : ''}
      <div class="lightbox-spinner" aria-hidden="true"></div>
      <img class="lightbox-img" src="${escapeHtml(hasGallery ? gallery[index] : url)}" alt="Attached image, full size">
    `;
    document.body.appendChild(overlay);

    state.activeLightbox = overlay;

    const imgEl = overlay.querySelector('.lightbox-img');
    const spinnerEl = overlay.querySelector('.lightbox-spinner');

    const showSpinner = () => { imgEl.classList.add('loading'); if (spinnerEl) spinnerEl.classList.remove('hidden'); };
    const hideSpinner = () => { imgEl.classList.remove('loading'); if (spinnerEl) spinnerEl.classList.add('hidden'); };
    imgEl.addEventListener('load', hideSpinner);
    imgEl.addEventListener('error', () => {
      hideSpinner();
      imgEl.classList.add('hidden');
      let brokenEl = overlay.querySelector('.lightbox-broken');
      if (!brokenEl) {
        brokenEl = document.createElement('div');
        brokenEl.className = 'lightbox-broken';
        brokenEl.innerHTML = '<i class="fas fa-image"></i><span>Couldn\'t load this media</span>';
        overlay.appendChild(brokenEl);
      }
      brokenEl.classList.remove('hidden');
    });
    if (imgEl.complete && imgEl.naturalWidth > 0) hideSpinner(); else showSpinner();

    const showAt = (newIndex) => {
      if (!hasGallery) return;
      index = ((newIndex % gallery.length) + gallery.length) % gallery.length;
      const brokenEl = overlay.querySelector('.lightbox-broken');
      if (brokenEl) brokenEl.classList.add('hidden');
      imgEl.classList.remove('hidden');
      showSpinner();
      imgEl.src = gallery[index];
    };
    const showNext = () => showAt(index + 1);
    const showPrev = () => showAt(index - 1);

    const onKeydown = (e) => {
      if (e.key === 'Escape') { close(); return; }
      if (!hasGallery) return;
      if (e.key === 'ArrowRight') showNext();
      else if (e.key === 'ArrowLeft') showPrev();
    };
    document.addEventListener('keydown', onKeydown);

    const close = () => {
      if (state.activeLightbox === overlay) {
        state.activeLightbox = null;
      }
      document.removeEventListener('keydown', onKeydown);
      overlay.remove();
    };
    overlay._lightboxCleanup = () => document.removeEventListener('keydown', onKeydown);

    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.lightbox-close').addEventListener('click', close);

    if (hasGallery) {
      overlay.querySelector('.lightbox-prev').addEventListener('click', (e) => { e.stopPropagation(); showPrev(); });
      overlay.querySelector('.lightbox-next').addEventListener('click', (e) => { e.stopPropagation(); showNext(); });

      let touchStartX = null;
      let touchStartY = null;
      const SWIPE_THRESHOLD = 40;
      overlay.addEventListener('touchstart', (e) => {
        if (e.touches.length !== 1) return;
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }, { passive: true });
      overlay.addEventListener('touchend', (e) => {
        if (touchStartX === null) return;
        const touch = e.changedTouches[0];
        const dx = touch.clientX - touchStartX;
        const dy = touch.clientY - touchStartY;
        touchStartX = null;
        touchStartY = null;
        if (Math.abs(dx) > SWIPE_THRESHOLD && Math.abs(dx) > Math.abs(dy)) {
          if (dx < 0) showNext(); else showPrev();
        }
      }, { passive: true });
    }
  }

  // FIX: companion to the "shared videos are not being considered media"
  // fix in updateProfileScreen() — tapping a video tile in the Shared
  // Media grid used to do nothing (no click target matched it at all). This
  // is a deliberately simpler single-item viewer, not a video-aware
  // extension of openImageLightbox() above: that function's prev/next
  // gallery swaps `<img>.src` between calls, which can't play a video, and
  // teaching it to juggle mixed image/video items for what's a fairly rare
  // click path wasn't worth the added complexity. Same .lightbox-overlay
  // shell (and the same state.activeLightbox teardown contract — see
  // closeActiveLightbox() around state.activeLightbox usage elsewhere) as
  // openImageLightbox()/openDocViewer(), just with a <video controls> in
  // place of the <img>.
  function openVideoLightbox(url) {
    if (!url) return;
    const overlay = document.createElement('div');
    overlay.className = 'lightbox-overlay';
    overlay.innerHTML = `
      <button class="lightbox-close" aria-label="Close"><i class="fas fa-times"></i></button>
      <video class="lightbox-video" src="${escapeHtml(url)}" controls autoplay playsinline></video>
    `;
    document.body.appendChild(overlay);
    state.activeLightbox = overlay;

    const onKeydown = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKeydown);

    const close = () => {
      if (state.activeLightbox === overlay) state.activeLightbox = null;
      document.removeEventListener('keydown', onKeydown);
      const videoEl = overlay.querySelector('video');
      if (videoEl) videoEl.pause();
      overlay.remove();
    };
    overlay._lightboxCleanup = () => document.removeEventListener('keydown', onKeydown);

    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.lightbox-close').addEventListener('click', close);
  }

  DOM.replyPreviewCancel.addEventListener('click', () => {
    state.replyingTo = null;
    DOM.replyPreview.classList.add('hidden');
  });

  // ============================================================
  // 9. SEND MESSAGE
  // ============================================================
  let isSendingMessage = false;

  async function sendMessage(content, file) {
    if (isSendingMessage) {
      console.log('✋ Send already in progress, ignoring duplicate call');
      return false;
    }
    if (!state.currentChannel || !state.currentUser) {
      alert('Please select a channel first.');
      return false;
    }

    isSendingMessage = true;
    if (DOM.sendMsgBtn) DOM.sendMsgBtn.disabled = true;
    let tempId = null;

    try {
      if (!state.isAdmin) {
        const stillMember = await verifyChannelMembership(state.currentChannel.id);
        if (!stillMember) {
          await expelFromChannel(state.currentChannel.id);
          return false;
        }
      }

      let fileUrl = null;

      if (file) {
        const uploadFile = await compressImageFile(file);

        if (uploadFile.size > CONFIG.UPLOAD.MAX_FILE_SIZE) {
          alert(`File exceeds ${CONFIG.UPLOAD.MAX_FILE_SIZE / (1024 * 1024)}MB limit.`);
          return false;
        }

        try {
          fileUrl = await uploadFileToR2(uploadFile, 'message');

          DOM.fileUploadStatus.textContent = `📎 ${uploadFile.name} uploaded`;
          DOM.fileUploadStatus.classList.remove('hidden');
          setTimeout(() => DOM.fileUploadStatus.classList.add('hidden'), 4000);
        } catch (e) {
          console.error('Upload error:', e);
          alert(`File upload failed: ${e.message}`);
          return false;
        }
      }

      const replyPayload = state.replyingTo
        ? {
            reply_to: state.replyingTo.id,
            reply_username: state.replyingTo.username,
            reply_content: state.replyingTo.content || (state.replyingTo.file_url ? '📎 Attached file' : '')
          }
        : {};

      const clientId = `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      const newMessage = {
        channel_id: state.currentChannel.id,
        username: state.currentUser.username,
        content: content || '',
        file_url: fileUrl,
        client_id: clientId,
        ...replyPayload,
      };

      tempId = `temp_${clientId}`;
      const lastKnownMessage = state.messages[state.messages.length - 1];
      const lastKnownTs = lastKnownMessage ? new Date(lastKnownMessage.created_at || 0).getTime() : 0;
      const optimisticTs = Math.max(Date.now(), (Number.isFinite(lastKnownTs) ? lastKnownTs : 0) + 1);
      const optimisticMessage = {
        id: tempId,
        ...newMessage,
        created_at: new Date(optimisticTs).toISOString(),
        isPending: true
      };

      mergeMessagesSafely(optimisticMessage, true);
      console.log(`✉️ Message added (optimistic, clientId: ${clientId})`);

      const { error, data } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .insert(newMessage)
        .select();

      if (error) {
        console.error('Send error:', error);
        alert('Failed to send message.');
        state.messages = state.messages.filter((m) => m.id !== tempId);
        renderMessages();
        // NOTE: if fileUrl was set above and this insert still failed, the
        // R2 object is now unreferenced — no client-side cleanup needed
        // here, the R2 Lifecycle rule (Cloudflare dashboard) auto-deletes
        // it after 7 days regardless of whether a message row exists.
        console.log('❌ Message rolled back');
        return false;
      } else if (data && data[0]) {
        const realMessage = data[0];

        const index = state.messages.findIndex((m) => m.id === tempId);
        if (index !== -1) {
          state.messages[index] = realMessage;
          delete state.messages[index].isPending;
          state.messages.sort((a, b) => new Date(a.created_at || 0) - new Date(b.created_at || 0));
          renderMessages(true);
          console.log(`✅ Message replaced: ${tempId} → ${realMessage.id}`);
        } else {
          mergeMessagesSafely(realMessage);
        }

        state.channelPreviews = await loadChannelPreviews(allChannels.map((c) => c.id));
        renderChatList(allChannels);

        if (state.currentChannel) {
          saveCachedMessages(state.currentChannel.id, state.messages);
        }
      }

      state.replyingTo = null;
      DOM.replyPreview.classList.add('hidden');
      return true;
    } catch (err) {
      console.error('Send error (network/exception):', err);
      alert('Failed to send message.');
      if (tempId) {
        state.messages = state.messages.filter((m) => m.id !== tempId);
        renderMessages();
        console.log('❌ Message rolled back (exception)');
      }
      return false;
    } finally {
      isSendingMessage = false;
      if (DOM.sendMsgBtn) DOM.sendMsgBtn.disabled = false;
    }
  }

  // ============================================================
  // 7b. PRESENCE (who's online)
  // ============================================================
  let presenceChannel = null;
  let presenceReconnectTimer = null;
  let presenceWatchdog = null;

  // FIX: root cause of "'Active now' status is not real-time" — this
  // channel used to be set up once at login and then never checked again.
  // The messages channel has a whole connectionWatchdog/inactivity/tab-focus
  // system (below) to detect a dropped socket and reconnect it; presence had
  // none of that. So the moment this specific socket dropped — phone app
  // backgrounded, laptop slept, a brief network blip, a mobile browser
  // throttling a background tab — the 'sync' event just stopped firing
  // forever. state.onlineUsers froze at whatever it was at the moment of the
  // drop (people could look permanently "Active now" or permanently
  // "Offline") and nothing brought it back except a full page reload.
  // Now: (1) a non-SUBSCRIBED status schedules a resubscribe, (2) a periodic
  // watchdog is a backstop in case that status callback is ever missed
  // (e.g. it fires while the tab is suspended and gets dropped by the
  // browser), and (3) regaining tab focus forces an immediate health check
  // instead of waiting up to 20s for the watchdog to notice.
  function setupPresence() {
    if (!state.currentUser) return;
    teardownPresence();

    presenceChannel = supabase.channel('presence:orbit', {
      config: { presence: { key: state.currentUser.username.toLowerCase() } },
    });

    presenceChannel
      .on('presence', { event: 'sync' }, () => {
        const s = presenceChannel.presenceState();
        state.onlineUsers = new Set(Object.keys(s));
        renderMembers();
        updateChatDetailSubtitle();
        updateProfileMeta();
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          if (presenceReconnectTimer) {
            clearTimeout(presenceReconnectTimer);
            presenceReconnectTimer = null;
          }
          await presenceChannel.track({ username: state.currentUser.username, online_at: new Date().toISOString() });
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn(`🩺 Presence channel unhealthy (${status}), scheduling reconnect...`);
          schedulePresenceReconnect();
        }
      });

    startPresenceWatchdog();
  }

  function schedulePresenceReconnect() {
    if (presenceReconnectTimer || !state.currentUser) return;
    presenceReconnectTimer = setTimeout(() => {
      presenceReconnectTimer = null;
      if (!state.currentUser) return;
      console.log('🔄 Reconnecting presence channel...');
      setupPresence();
    }, 3000);
  }

  function startPresenceWatchdog() {
    if (presenceWatchdog) clearInterval(presenceWatchdog);
    presenceWatchdog = setInterval(() => {
      if (!state.currentUser) return;
      const dead = !presenceChannel || presenceChannel.state === 'closed' || presenceChannel.state === 'errored';
      if (dead) {
        console.warn('🩺 Presence watchdog: connection unhealthy, reconnecting...');
        setupPresence();
      }
    }, 20000);
  }

  function stopPresenceWatchdog() {
    if (presenceWatchdog) {
      clearInterval(presenceWatchdog);
      presenceWatchdog = null;
    }
  }

  // Re-checks the presence channel the instant the tab regains focus,
  // instead of waiting for the (up to 20s) watchdog interval to catch it —
  // this is the case people actually notice, since it's the moment someone
  // is looking at the screen expecting the list to be current.
  function ensurePresenceHealthy() {
    if (!state.currentUser) return;
    const dead = !presenceChannel || presenceChannel.state === 'closed' || presenceChannel.state === 'errored';
    if (dead) {
      console.log('🔄 Presence check on refocus: connection dead, reconnecting...');
      setupPresence();
    } else {
      // Connection looks alive — re-send our own track() so our online_at
      // timestamp is fresh and we don't appear stale to others either.
      presenceChannel.track({ username: state.currentUser.username, online_at: new Date().toISOString() }).catch(() => {});
    }
  }

  function teardownPresence() {
    if (presenceReconnectTimer) {
      clearTimeout(presenceReconnectTimer);
      presenceReconnectTimer = null;
    }
    stopPresenceWatchdog();
    if (presenceChannel) {
      supabase.removeChannel(presenceChannel);
      presenceChannel = null;
    }
    state.onlineUsers = new Set();
  }

  // ============================================================
  // 8d. GROUP MEMBER MANAGEMENT
  // ============================================================
  async function loadMembers(channelId) {
    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MEMBERS)
      .select('*')
      .eq('channel_id', channelId)
      .order('username');

    if (error) {
      state.currentMembers = [];
      DOM.channelMembersList.innerHTML = '<div class="empty-note">Could not load members</div>';
      return;
    }
    
    state.currentMembers = (data || []).map(member => ({
      ...member,
      role: member.role || getRoleFromUsername(member.username)
    }));
    
    renderMembers();
    updateChatDetailSubtitle();
    updateProfileMeta();
    renderScheduleTeacherField();
  }

  // FIX: "auto select teacher when there is one teacher for scheduling
  // meeting, show option to select teacher when there are multiple
  // teachers in one group" — see the long comment on the markup in
  // index.html for the full picture. This looks at THIS group's own
  // members (state.currentMembers, populated by loadMembers() right
  // above, always for whichever channel is currently selected) rather
  // than every registered teacher account app-wide, and swaps in
  // exactly one of three UI states depending on how many of them are
  // teachers. #scheduleTeacherInput stays the one value setClassSchedule()
  // and the reset-after-submit code actually read/clear — it's just kept
  // hidden and auto-filled (single teacher) or synced from the dropdown
  // (multiple teachers) instead of being typed into directly, so no
  // other code needs to change to know which of the three states is
  // currently showing.
  function renderScheduleTeacherField() {
    if (!DOM.scheduleTeacherInput) return;
    const teachers = (state.currentMembers || []).filter((m) => m.role === 'teacher');

    if (teachers.length === 1) {
      const username = teachers[0].username;
      DOM.scheduleTeacherInput.value = username;
      DOM.scheduleTeacherInput.classList.add('hidden');
      if (DOM.scheduleTeacherSelect) DOM.scheduleTeacherSelect.classList.add('hidden');
      if (DOM.scheduleTeacherSingleLabel) {
        DOM.scheduleTeacherSingleLabel.textContent = getDisplayName(username);
        DOM.scheduleTeacherSingleLabel.classList.remove('hidden');
      }
    } else if (teachers.length > 1) {
      DOM.scheduleTeacherInput.classList.add('hidden');
      if (DOM.scheduleTeacherSingleLabel) DOM.scheduleTeacherSingleLabel.classList.add('hidden');
      if (DOM.scheduleTeacherSelect) {
        const previousValue = DOM.scheduleTeacherInput.value;
        DOM.scheduleTeacherSelect.innerHTML = teachers
          .map((t) => `<option value="${escapeHtml(t.username)}">${escapeHtml(getDisplayName(t.username))}</option>`)
          .join('');
        const stillValid = teachers.some((t) => t.username === previousValue);
        DOM.scheduleTeacherSelect.value = stillValid ? previousValue : teachers[0].username;
        DOM.scheduleTeacherSelect.classList.remove('hidden');
        DOM.scheduleTeacherInput.value = DOM.scheduleTeacherSelect.value;
      }
    } else {
      // No teacher members in this group yet — fall back to the
      // original manual-entry input so scheduling isn't blocked before
      // a teacher's been added to the group.
      if (DOM.scheduleTeacherSelect) DOM.scheduleTeacherSelect.classList.add('hidden');
      if (DOM.scheduleTeacherSingleLabel) DOM.scheduleTeacherSingleLabel.classList.add('hidden');
      DOM.scheduleTeacherInput.classList.remove('hidden');
    }
  }

  let memberLetterAnchors = {};

  const MEMBER_ROLE_ORDER = ['admin', 'teacher', 'student'];
  const MEMBER_ROLE_LABEL = { admin: 'Admins', teacher: 'Teachers', student: 'Students' };

  function renderMembers() {
    DOM.adminAddMemberRow.classList.toggle('hidden', !state.isAdmin);

    const query = (DOM.memberSearchInput.value || '').trim().toLowerCase();
    const members = [...state.currentMembers]
      .filter((m) => !query || m.username.toLowerCase().includes(query) || getDisplayName(m.username).toLowerCase().includes(query))
      .sort((a, b) => {
        const roleDiff = MEMBER_ROLE_ORDER.indexOf(a.role) - MEMBER_ROLE_ORDER.indexOf(b.role);
        if (roleDiff !== 0) return roleDiff;
        return a.username.localeCompare(b.username);
      });

    if (!members.length) {
      DOM.channelMembersList.innerHTML = `<div class="empty-note">${state.currentChannel ? 'No members yet' : 'Select a channel'}</div>`;
      DOM.alphaIndex.innerHTML = '';
      return;
    }

    let html = '';
    let lastRole = '';
    let lastLetter = '';
    let anchorIdx = 0;
    memberLetterAnchors = {};
    members.forEach((m) => {
      if (m.role !== lastRole) {
        html += `<div class="member-group-letter member-role-header">${MEMBER_ROLE_LABEL[m.role] || escapeHtml(m.role)}</div>`;
        lastRole = m.role;
        lastLetter = '';
      }
      const displayName = getDisplayName(m.username);
      const letter = displayName.charAt(0).toUpperCase();
      if (letter !== lastLetter) {
        const anchorId = `memberLetter-${anchorIdx++}`;
        html += `<div class="member-group-letter" id="${anchorId}">${letter}</div>`;
        if (!(letter in memberLetterAnchors)) memberLetterAnchors[letter] = anchorId;
        lastLetter = letter;
      }
      const online = state.onlineUsers.has(m.username.toLowerCase());
      html += `
        <div class="member-row" id="member-${m.id}">
          ${avatarHtml(m.username, 'sm')}
          <div style="flex:1; min-width:0;">
            <div class="member-name">${escapeHtml(displayName)}</div>
            <div class="member-status${online ? ' online' : ''}"><span class="dot"></span>${online ? 'Active now' : 'Offline'}</div>
          </div>
          <span class="role-chip role-${m.role}-chip member-role-chip">${escapeHtml(m.role)}</span>
          ${state.isAdmin ? `
            <button class="icon-btn member-remove-btn" style="width:26px;height:26px;" title="Remove from group" data-remove-member="${m.id}">
              <i class="fas fa-xmark" style="font-size:11px;"></i>
            </button>` : ''}
        </div>
      `;
    });
    DOM.channelMembersList.innerHTML = html;

    DOM.channelMembersList.querySelectorAll('[data-remove-member]').forEach((btn) => {
      btn.addEventListener('click', () => removeMember(btn.dataset.removeMember));
    });

    const present = new Set(members.map((m) => getDisplayName(m.username).charAt(0).toUpperCase()));
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    DOM.alphaIndex.innerHTML = alphabet.map((l) => `<span data-letter="${l}" class="${present.has(l) ? '' : 'hidden'}">${l}</span>`).join('');
    DOM.alphaIndex.querySelectorAll('span').forEach((span) => {
      span.addEventListener('click', () => {
        const anchorId = memberLetterAnchors[span.dataset.letter];
        const target = anchorId && document.getElementById(anchorId);
        if (target) target.scrollIntoView({ block: 'start', behavior: 'smooth' });
      });
    });
  }

  async function addMemberToChannel(username, role) {
    username = normalizeUsername(username);
    if (!username || !state.currentChannel) { alert('Enter a username and select a channel.'); return; }

    const registeredRoles = await getUserRoles(username);
    if (!registeredRoles || registeredRoles.length === 0) {
      alert(`No account exists for "${username}". Create it first from Settings → Add teacher or student, then add them here.`);
      return;
    }

    const { error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MEMBERS)
      .upsert(
        { 
          channel_id: state.currentChannel.id, 
          username, 
          role: role || 'student', 
          added_by: state.currentUser.username 
        },
        { onConflict: 'channel_id,username' }
      );

    if (error) { alert('Could not add member: ' + error.message); return; }

    notifyMembershipChange(username, 'membership-added', state.currentChannel.id);

    await loadMembers(state.currentChannel.id);
    loadRegisteredUsersList();
  }

  async function removeMember(memberId) {
    if (!confirm('Remove this person from the group?')) return;
    const removedMember = state.currentMembers.find((m) => String(m.id) === String(memberId));
    const { error } = await supabase.from(CONFIG.SUPABASE.TABLES.MEMBERS).delete().eq('id', memberId);
    if (error) { alert('Remove failed: ' + error.message); return; }
    if (removedMember && state.currentChannel) {
      notifyMembershipChange(removedMember.username, 'membership-removed', state.currentChannel.id);
    }
    await loadMembers(state.currentChannel.id);
    loadRegisteredUsersList();
  }

  // ============================================================
  // 8e. CLASS SCHEDULING
  // ============================================================
  let scheduleSubscription = null;

  const MAX_SESSION_DURATION_MINUTES = 8 * 60;

  let scheduleExpiryTimer = null;
  const SCHEDULE_EXPIRY_WATCHDOG_MAX_MS = 20 * 24 * 60 * 60 * 1000;

  function clearScheduleExpiryTimer() {
    if (scheduleExpiryTimer) {
      clearTimeout(scheduleExpiryTimer);
      scheduleExpiryTimer = null;
    }
  }

  async function loadSchedule(channelId) {
    const { data, error } = await supabase
      .from('class_schedule')
      .select('*')
      .eq('channel_id', channelId)
      .gte('scheduled_time', new Date(Date.now() - MAX_SESSION_DURATION_MINUTES * 60000).toISOString())
      .order('scheduled_time', { ascending: true })
      .limit(50);

    clearScheduleExpiryTimer();

    if (error) {
      state.currentSchedule = null;
      DOM.scheduleBanner.classList.add('hidden');
      updateLiveButtonState();
      return;
    }

    const now = Date.now();
    const current = (data || []).find((row) => {
      const endsAt = new Date(row.scheduled_time).getTime() + (row.duration_minutes || 45) * 60000;
      return endsAt > now;
    });

    if (state.videoActive && state.activeCallScheduleId) {
      const stillCurrent = current && String(current.id) === String(state.activeCallScheduleId);
      // FIX: root cause of "when the meeting is ended by teacher or admin
      // it should show the group chat screen instead of meeting ended
      // screen" (the delay half of it) — this used to check ONLY whether
      // the schedule row's time window (scheduled_time + duration_minutes)
      // was still in the future, never `is_live` itself. endLiveSessionForEveryone()
      // shortens duration_minutes to the elapsed time AND sets is_live:false
      // in the same update, but Math.ceil() on the elapsed minutes means
      // the shortened window can still read up to ~59 seconds in the
      // future — so `stillCurrent` stayed true and other participants
      // were left sitting in a call that had already been ended, still
      // looking "live" client-side, until the next scheduled boundary
      // timer happened to fire and finally catch the time-window expiry.
      // Checking `is_live` directly reacts the instant the realtime
      // update (subscribeToSchedule()) arrives, instead of up to a
      // minute later.
      const stillLive = stillCurrent && current.is_live !== false;
      if (!stillLive) {
        closeLiveSession('This live session has ended.');
      }
    }

    if (!current) {
      state.currentSchedule = null;
      DOM.scheduleBanner.classList.add('hidden');
      updateLiveButtonState();
      return;
    }
    state.currentSchedule = current;
    renderScheduleBanner(current);
    updateLiveButtonState();

    const startsAt = new Date(current.scheduled_time).getTime();
    const endsAt = startsAt + (current.duration_minutes || 45) * 60000;
    const msUntilStart = startsAt - now;
    const msUntilEnd = endsAt - now;
    const msUntilNextBoundary = msUntilStart > 0 ? msUntilStart : msUntilEnd;
    if (msUntilNextBoundary > 0 && msUntilNextBoundary <= SCHEDULE_EXPIRY_WATCHDOG_MAX_MS) {
      scheduleExpiryTimer = setTimeout(() => loadSchedule(channelId), msUntilNextBoundary + 500);
    }
  }

  function renderScheduleBanner(schedule) {
    const start = new Date(schedule.scheduled_time);
    const end = new Date(start.getTime() + (schedule.duration_minutes || 45) * 60000);
    const startFormatted = start.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true });
    const endFormatted = end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    DOM.scheduleBannerText.textContent = `Class with ${getDisplayName(schedule.teacher_username)} scheduled for ${startFormatted}–${endFormatted}`;
    DOM.scheduleBanner.classList.remove('hidden');
  }

  // ============================================================
  // FIX: TEACHER "JOIN LIVE SESSION" VS "START LIVE SESSION"
  // The issue was that getLiveButtonMode() wasn't properly
  // distinguishing between teachers and other users, or the
  // teacher's role wasn't being correctly loaded.
  // ============================================================
  function getLiveButtonMode() {
    const schedule = state.currentSchedule;
    if (!schedule || !state.currentUser) return 'hidden';

    const now = Date.now();
    const startsAt = new Date(schedule.scheduled_time).getTime();
    const endsAt = startsAt + (schedule.duration_minutes || 45) * 60000;
    const isWithinWindow = now >= startsAt && now < endsAt;
    if (!isWithinWindow) return 'hidden';

    const currentUsername = normalizeUsername(state.currentUser.username);
    const teacherUsername = normalizeUsername(schedule.teacher_username);
    const isConcernedTeacher = currentUsername === teacherUsername;
    const isLive = schedule.is_live === true;

    // FIX: Teachers should see 'start' if they are the scheduled teacher
    // (regardless of whether is_live is true or false - they can start it)
    if (isConcernedTeacher) {
      console.log(`🎓 Teacher ${currentUsername} is the scheduled teacher → showing 'start'`);
      return 'start';
    }

    // Admins can start a session if no one has started it yet
    if (state.isAdmin && !isLive) {
      console.log(`👑 Admin ${currentUsername} is starting the session → showing 'start'`);
      return 'start';
    }

    // Admins can join if the session is already live
    if (state.isAdmin && isLive) {
      console.log(`👑 Admin ${currentUsername} is joining an active session → showing 'join'`);
      return 'join';
    }

    // Anyone else can join if the session is live
    if (isLive) {
      console.log(`👤 ${currentUsername} is joining an active session → showing 'join'`);
      return 'join';
    }

    console.log(`🔒 ${currentUsername} has no access to this session → hidden`);
    return 'hidden';
  }

  function updateLiveButtonState() {
    if (!DOM.joinLiveBtn) return;
    const mode = getLiveButtonMode();
    const isInactive = mode === 'hidden';

    DOM.joinLiveBtn.disabled = isInactive;
    DOM.joinLiveBtn.classList.toggle('btn-live-pill-dead', isInactive);
    DOM.joinLiveBtn.setAttribute('aria-disabled', String(isInactive));

    if (DOM.liveBtnText) {
      // FIX (root cause, found via the diagnostic line): the previous
      // version only counted someone as a "starter" (-> "Start Live
      // Session") when a schedule row existed AND its teacher_username
      // matched the current user. Whenever no schedule row was currently
      // loaded for the channel (state.currentSchedule === null — e.g.
      // before the scheduled time, or when no session is scheduled at
      // all), isStarter silently defaulted to false for EVERYONE,
      // including the teacher/admin, which is exactly the "teacher sees
      // Join Live Session while idle, then it flips to Start Live Session
      // once the schedule loads/starts" bug that was reported.
      // "Join Live Session" is designed for students only, full stop —
      // it must never depend on whether a specific schedule row is loaded
      // or who it names as teacher. The only correct signal for "is this
      // person staff, not a student" is their account role, which is
      // already known the instant they're logged in via
      // state.isTeacher / state.isAdmin — independent of any schedule.
      const schedule = state.currentSchedule;
      const isStarter = !!state.isTeacher || !!state.isAdmin;
      const label = isStarter ? 'Start Live Session' : 'Join Live Session';
      console.log(`🏷️ Live button label: mode=${mode} isStarter=${isStarter} isTeacher=${!!state.isTeacher} isAdmin=${!!state.isAdmin} scheduleId=${schedule ? schedule.id : 'none'} me="${state.currentUser ? state.currentUser.username : 'none'}" -> "${label}"`);
      DOM.liveBtnText.textContent = label;
    }

    DOM.joinLiveBtn.title = isInactive
      ? (state.currentSchedule ? 'This live session hasn\'t started yet.' : 'No live session is scheduled for this group yet')
      : '';
  }

  function subscribeToSchedule(channelId) {
    if (scheduleSubscription) {
      supabase.removeChannel(scheduleSubscription);
      scheduleSubscription = null;
    }
    scheduleSubscription = supabase
      .channel(`schedule:${channelId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'class_schedule', filter: `channel_id=eq.${channelId}` }, () => {
        loadSchedule(channelId);
        loadGroupScheduleList(channelId);
      })
      .subscribe();
  }

  let groupScheduleEditingId = null;
  let groupScheduleCache = new Map();
  let groupScheduleLoading = new Set();

  async function loadGroupScheduleList(channelId) {
    if (!DOM.groupScheduleList) return;
    if (groupScheduleLoading.has(channelId)) return;
    groupScheduleLoading.add(channelId);

    const cachedRows = groupScheduleCache.get(channelId);
    if (cachedRows) {
      renderGroupScheduleRows(channelId, cachedRows);
    } else {
      DOM.groupScheduleList.innerHTML = '<div class="empty-note">Loading…</div>';
    }

    try {
      const { data, error } = await supabase
        .from('class_schedule')
        .select('*')
        .eq('channel_id', channelId)
        .gte('scheduled_time', new Date(Date.now() - MAX_SESSION_DURATION_MINUTES * 60000).toISOString())
        .order('scheduled_time', { ascending: true })
        .limit(30);

      if (!state.currentChannel || String(state.currentChannel.id) !== String(channelId)) return;

      if (error) {
        console.warn('loadGroupScheduleList failed:', error);
        if (!cachedRows) DOM.groupScheduleList.innerHTML = '<div class="empty-note">Could not load the schedule.</div>';
        return;
      }

      groupScheduleCache.set(channelId, data || []);
      renderGroupScheduleRows(channelId, data || []);
    } finally {
      groupScheduleLoading.delete(channelId);
    }
  }

  // FIX: shared by both schedule lists (the per-channel "Scheduled
  // Classes" list on the Profile page, and the admin's global "Live
  // Sessions Calendar") so "is this session still relevant to show"
  // means the same thing in both places. A row is relevant if it
  // either hasn't started yet, or is still genuinely live right now.
  // FIX: root cause of "live meetings are not being shown" — this used
  // to also require `row.is_live !== false`. A freshly-scheduled
  // session's `is_live` is never set on insert (see the schedule-
  // creation insert() above) — it just sits at the database column's
  // own default, which is `false`, not `null`. That's INDISTINGUISHABLE
  // from a session that was started and then explicitly ended early
  // (also `is_live: false`) — so the moment a scheduled-but-not-yet-
  // manually-started session's time window opened, this treated it as
  // "already ended" and hid it from both schedule lists, right when it
  // should have appeared as available to join/start. Dropping the
  // is_live check entirely and going back to a pure time-window check:
  // both places that explicitly end a session early
  // (endLiveSessionForEveryone/endScheduledSessionNow) already shorten
  // `duration_minutes` to the real elapsed time in that SAME update, so
  // `endsAt` below already reflects an early end on its own — no need
  // for is_live to catch that case too.
  function isScheduleRowRelevant(row, now) {
    const start = new Date(row.scheduled_time).getTime();
    if (start > now) return true; // scheduled in the future — always relevant
    const endsAt = start + (row.duration_minutes || 45) * 60000;
    return now < endsAt; // already started: only relevant while still within its (possibly shortened) window
  }

  function renderGroupScheduleRows(channelId, rows) {
    if (!DOM.groupScheduleList) return;
    if (!state.currentChannel || String(state.currentChannel.id) !== String(channelId)) return;

    const now = Date.now();
    const upcoming = (rows || []).filter((row) => isScheduleRowRelevant(row, now));

    if (groupScheduleEditingId && !upcoming.some((row) => String(row.id) === String(groupScheduleEditingId))) {
      groupScheduleEditingId = null;
    }

    if (!upcoming.length) {
      DOM.groupScheduleList.innerHTML = '<div class="empty-note">No live sessions scheduled yet.</div>';
      return;
    }

    DOM.groupScheduleList.innerHTML = upcoming.map((row) => groupScheduleItemHtml(row)).join('');

    if (!state.isAdmin) return;

    DOM.groupScheduleList.querySelectorAll('.gs-edit-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        groupScheduleEditingId = btn.dataset.id;
        renderGroupScheduleRows(channelId, groupScheduleCache.get(channelId) || []);
      });
    });
    DOM.groupScheduleList.querySelectorAll('.gs-edit-cancel').forEach((btn) => {
      btn.addEventListener('click', () => {
        groupScheduleEditingId = null;
        renderGroupScheduleRows(channelId, groupScheduleCache.get(channelId) || []);
      });
    });
    DOM.groupScheduleList.querySelectorAll('.gs-edit-record-input').forEach((input) => {
      input.addEventListener('change', () => {
        input.closest('.gs-edit-record').classList.toggle('is-active', input.checked);
      });
    });
    DOM.groupScheduleList.querySelectorAll('.gs-edit-save').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const row = btn.closest('.group-schedule-item');
        const ok = await updateScheduledSession(
          btn.dataset.id,
          row.querySelector('.gs-edit-date').value,
          row.querySelector('.gs-edit-start').value,
          row.querySelector('.gs-edit-duration').value,
          row.querySelector('.gs-edit-record-input').checked
        );
        if (!ok) return;
        groupScheduleEditingId = null;
        loadGroupScheduleList(channelId);
      });
    });
    DOM.groupScheduleList.querySelectorAll('.gs-delete-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const ok = await deleteScheduledSession(btn.dataset.id);
        if (ok) loadGroupScheduleList(channelId);
      });
    });
    DOM.groupScheduleList.querySelectorAll('.group-schedule-item-end-btn').forEach((btn) => {
      btn.addEventListener('click', () => endScheduledSessionNow(btn.dataset.id));
    });
  }

  function groupScheduleItemHtml(row) {
    if (state.isAdmin && groupScheduleEditingId && String(groupScheduleEditingId) === String(row.id)) {
      return groupScheduleEditRowHtml(row);
    }

    const start = new Date(row.scheduled_time);
    const durationMinutes = row.duration_minutes || 45;
    const end = new Date(start.getTime() + durationMinutes * 60000);
    // FIX: root cause of "live meetings not shown" — dropped the
    // `row.is_live !== false` check added here previously. It couldn't
    // tell a not-yet-started scheduled session (is_live sits at the
    // DB's own default of `false` until someone clicks Start) apart
    // from one that was started and explicitly ended early (also
    // is_live: false) — so a session that had simply never been
    // started yet lost its live badge, and this row is already
    // filtered to only ever be shown while isScheduleRowRelevant()
    // (see above) says it's relevant in the first place, so a pure
    // time-window check here is enough — see that function's comment
    // for the full reasoning.
    const isLiveNow = Date.now() >= start.getTime() && Date.now() < end.getTime();
    const dateLabel = start.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
    const timeLabel = `${start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })} – ${end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}`;
    // The recording icon is admin-only: teachers/students shouldn't
    // see which of their sessions will be auto-recorded, only admins
    // managing the schedule need that visibility (matches the admin-only
    // gating already on the Live Sessions Calendar screen itself, which
    // is why calendarItemHtml's copy of this icon didn't need the same
    // guard — that whole screen is admin-only).
    const isAutoRecording = state.isAdmin && !!row.auto_record_enabled;

    const adminActions = state.isAdmin ? `
      <div class="group-schedule-item-actions">
        ${isLiveNow ? `<button type="button" class="group-schedule-item-end-btn" data-id="${row.id}" title="End this live session now for everyone"><i class="fas fa-ban"></i> End now</button>` : ''}
        <button type="button" class="icon-btn gs-edit-btn" data-id="${row.id}" title="Edit"><i class="fas fa-pen"></i></button>
        <button type="button" class="icon-btn gs-delete-btn" data-id="${row.id}" title="Delete"><i class="fas fa-trash" style="color:var(--danger);"></i></button>
      </div>
    ` : '';

    return `
      <div class="group-schedule-item${isLiveNow ? ' is-live' : ''}">
        <div class="group-schedule-item-date">
          <span class="group-schedule-item-date-label">${escapeHtml(dateLabel)}${isLiveNow ? ' <span class="calendar-live-dot" title="Live now"></span>' : ''}${isAutoRecording ? ' <i class="fas fa-circle calendar-item-record-icon" title="Auto-recording enabled"></i>' : ''}</span>
          <span class="group-schedule-item-time-label">${escapeHtml(timeLabel)}</span>
        </div>
        <div class="group-schedule-item-teacher"><i class="fas fa-chalkboard-user"></i> ${escapeHtml(getDisplayName(row.teacher_username))}</div>
        ${adminActions}
      </div>
    `;
  }

  function groupScheduleEditRowHtml(row) {
    const start = new Date(row.scheduled_time);
    const pad = (n) => String(n).padStart(2, '0');
    const dateVal = `${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())}`;
    const timeVal = `${pad(start.getHours())}:${pad(start.getMinutes())}`;

    return `
      <div class="group-schedule-item is-editing">
        <div class="group-schedule-edit-fields">
          <input type="date" class="field-sm gs-edit-date" value="${dateVal}">
          <input type="time" class="field-sm gs-edit-start" value="${timeVal}">
          <input type="number" min="5" max="${MAX_SESSION_DURATION_MINUTES}" step="5" class="field-sm gs-edit-duration" value="${row.duration_minutes || 45}" title="Duration (minutes)">
          <!-- FIX: "can't see the recording on/off option in edit option of
          scheduled meeting" -- this edit row never had a way to change
          auto_record_enabled at all; it could only be set once, at
          creation time, in the Set-class-time form / per-date list
          (see renderSchedulePerDateList()). Reusing the exact same
          "schedule-per-date-record" styled checkbox here (already
          defined in styles.css, no new CSS needed) so admins can flip
          recording on/off for an existing scheduled session too. -->
          <label class="schedule-per-date-record gs-edit-record${row.auto_record_enabled ? ' is-active' : ''}" title="Record this session">
            <input type="checkbox" class="gs-edit-record-input"${row.auto_record_enabled ? ' checked' : ''}>
            <i class="fas fa-video"></i> Record
          </label>
        </div>
        <div class="group-schedule-edit-actions">
          <button type="button" class="btn-admin-sm gs-edit-save" data-id="${row.id}"><i class="fas fa-check"></i> Save</button>
          <button type="button" class="btn-admin-sm gs-edit-cancel"><i class="fas fa-xmark"></i> Cancel</button>
        </div>
      </div>
    `;
  }

  async function updateScheduledSession(id, dateStr, startTimeStr, durationMinutes, autoRecordEnabled) {
    if (!dateStr || !startTimeStr) { alert('Pick a date and start time.'); return false; }
    const duration = Math.round(Number(durationMinutes));
    if (!Number.isFinite(duration) || duration <= 0) { alert('Enter a valid duration.'); return false; }
    if (duration > MAX_SESSION_DURATION_MINUTES) {
      alert(`A single session can't be longer than ${MAX_SESSION_DURATION_MINUTES / 60} hours.`);
      return false;
    }
    const start = new Date(`${dateStr}T${startTimeStr}`);
    if (Number.isNaN(start.getTime())) { alert('That date/time couldn\'t be understood.'); return false; }

    const { error } = await supabase
      .from('class_schedule')
      .update({ scheduled_time: start.toISOString(), duration_minutes: duration, is_live: false, auto_record_enabled: !!autoRecordEnabled })
      .eq('id', id);

    if (error) { alert('Could not update the session: ' + error.message); return false; }
    return true;
  }

  async function deleteScheduledSession(id) {
    if (!confirm('Delete this scheduled session? This can\'t be undone.')) return false;
    const { error } = await supabase.from('class_schedule').delete().eq('id', id);
    if (error) { alert('Could not delete: ' + error.message); return false; }
    return true;
  }

  async function endScheduledSessionNow(id, scheduledTimeIso) {
    if (!confirm('End this live session now for everyone in the group?')) return;
    const startedAt = scheduledTimeIso ? new Date(scheduledTimeIso).getTime() : null;
    let duration = startedAt
      ? Math.max(1, Math.ceil((Date.now() - startedAt) / 60000))
      : null;

    if (duration === null) {
      const { data, error } = await supabase.from('class_schedule').select('scheduled_time').eq('id', id).maybeSingle();
      if (error || !data) { alert('Could not find that session.'); return; }
      duration = Math.max(1, Math.ceil((Date.now() - new Date(data.scheduled_time).getTime()) / 60000));
    }

    const { error } = await supabase.from('class_schedule').update({ duration_minutes: duration, is_live: false }).eq('id', id);
    if (error) { alert('Could not end the session: ' + error.message); return; }
  }

  const MAX_SCHEDULE_OCCURRENCES = 200;
  let scheduleCalendarViewMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  let scheduleSelectedDates = new Set();
  let schedulePerDateOverrides = new Map();
  let scheduleCalendarChannelId = null;

  function scheduleDateKey(d) {
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  function resetScheduleSelection() {
    scheduleSelectedDates = new Set();
    schedulePerDateOverrides = new Map();
    scheduleCalendarViewMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  }

  function renderScheduleCalendar() {
    if (!DOM.scheduleCalGrid || !DOM.scheduleCalMonthLabel) return;
    const year = scheduleCalendarViewMonth.getFullYear();
    const month = scheduleCalendarViewMonth.getMonth();
    DOM.scheduleCalMonthLabel.textContent = scheduleCalendarViewMonth.toLocaleDateString([], { month: 'long', year: 'numeric' });

    const startWeekday = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const todayKey = scheduleDateKey(new Date());
    const todayMidnight = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime();

    let cellsHtml = '';
    for (let i = 0; i < startWeekday; i++) {
      cellsHtml += '<span class="schedule-cal-cell is-empty"></span>';
    }
    for (let day = 1; day <= daysInMonth; day++) {
      const cellDate = new Date(year, month, day);
      const key = scheduleDateKey(cellDate);
      const isPast = cellDate.getTime() < todayMidnight;
      const isSelected = scheduleSelectedDates.has(key);
      const isToday = key === todayKey;
      cellsHtml += `<button type="button" class="schedule-cal-cell${isSelected ? ' is-selected' : ''}${isToday ? ' is-today' : ''}" data-date="${key}"${isPast ? ' disabled' : ''}>${day}</button>`;
    }
    DOM.scheduleCalGrid.innerHTML = cellsHtml;

    DOM.scheduleCalGrid.querySelectorAll('.schedule-cal-cell[data-date]').forEach((cell) => {
      cell.addEventListener('click', () => toggleScheduleDate(cell.dataset.date));
    });
  }

  function toggleScheduleDate(dateKey) {
    if (scheduleSelectedDates.has(dateKey)) {
      scheduleSelectedDates.delete(dateKey);
      schedulePerDateOverrides.delete(dateKey);
    } else if (scheduleSelectedDates.size < MAX_SCHEDULE_OCCURRENCES) {
      scheduleSelectedDates.add(dateKey);
    } else {
      alert(`You can schedule at most ${MAX_SCHEDULE_OCCURRENCES} dates at once.`);
      return;
    }
    renderScheduleCalendar();
    renderScheduleSelectedDates();
    renderSchedulePerDateList();
  }

  function scheduleDateLabel(dateKey) {
    return new Date(`${dateKey}T00:00:00`).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  }

  function renderScheduleSelectedDates() {
    if (!DOM.scheduleSelectedDates) return;
    if (!scheduleSelectedDates.size) {
      DOM.scheduleSelectedDates.innerHTML = '<span class="empty-note">Tap dates above to schedule a session on each.</span>';
      return;
    }
    const sorted = Array.from(scheduleSelectedDates).sort();
    DOM.scheduleSelectedDates.innerHTML = sorted.map((key) => `
      <span class="schedule-date-chip">
        ${escapeHtml(scheduleDateLabel(key))}
        <button type="button" class="schedule-date-chip-remove" data-date="${key}" aria-label="Remove ${escapeHtml(scheduleDateLabel(key))}"><i class="fas fa-xmark"></i></button>
      </span>
    `).join('');

    DOM.scheduleSelectedDates.querySelectorAll('.schedule-date-chip-remove').forEach((btn) => {
      btn.addEventListener('click', () => toggleScheduleDate(btn.dataset.date));
    });
  }

  function computeScheduleEndLabel(startTimeStr, durationMinutes) {
    if (!startTimeStr || !durationMinutes) return '—';
    const [h, m] = startTimeStr.split(':').map(Number);
    if (!Number.isFinite(h) || !Number.isFinite(m)) return '—';
    const end = new Date(2000, 0, 1, h, m + durationMinutes);
    return end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  }

  function updateScheduleEndPreview() {
    if (!DOM.scheduleEndPreview) return;
    const duration = parseInt(DOM.scheduleDurationInput.value, 10);
    DOM.scheduleEndPreview.textContent = computeScheduleEndLabel(DOM.scheduleStartTimeInput.value, duration);
  }

  function renderSchedulePerDateList() {
    if (!DOM.schedulePerDateList) return;
    const sameTime = !DOM.scheduleSameTimeCheckbox || DOM.scheduleSameTimeCheckbox.checked;
    DOM.schedulePerDateList.classList.toggle('hidden', sameTime);
    if (sameTime) return;

    if (!scheduleSelectedDates.size) {
      DOM.schedulePerDateList.innerHTML = '<div class="empty-note">Select dates on the calendar above first.</div>';
      return;
    }

    const defaultStart = DOM.scheduleStartTimeInput.value || '09:00';
    const defaultDuration = parseInt(DOM.scheduleDurationInput.value, 10) || 45;
    // FIX: seeds each new per-date row's "Record" checkbox from whatever
    // the shared "Record this session automatically" checkbox is
    // currently set to — same idea as defaultStart/defaultDuration above
    // seeding the Starts/Duration fields — so ticking the shared checkbox
    // first and THEN switching to per-date mode still records every date
    // by default; an admin only needs to touch the individual checkboxes
    // for the dates that should actually differ.
    const defaultRecord = !!(DOM.scheduleRecordCheckbox && DOM.scheduleRecordCheckbox.checked);
    const sorted = Array.from(scheduleSelectedDates).sort();

    DOM.schedulePerDateList.innerHTML = sorted.map((key) => {
      const override = schedulePerDateOverrides.get(key) || { start: defaultStart, duration: defaultDuration, record: defaultRecord };
      const isRecording = override.record !== undefined ? !!override.record : defaultRecord;
      return `
        <div class="schedule-per-date-row" data-date="${key}">
          <span class="schedule-per-date-label">${escapeHtml(scheduleDateLabel(key))}</span>
          <input type="time" class="field-sm schedule-per-date-start" data-date="${key}" value="${escapeHtml(override.start)}">
          <input type="number" min="5" max="${MAX_SESSION_DURATION_MINUTES}" step="5" class="field-sm schedule-per-date-duration" data-date="${key}" value="${override.duration}" title="Duration (minutes)">
          <div class="schedule-per-date-meta">
            <span class="schedule-per-date-end" data-date="${key}">Ends ${escapeHtml(computeScheduleEndLabel(override.start, override.duration))}</span>
            <label class="schedule-per-date-record${isRecording ? ' is-active' : ''}" title="Record this specific session">
              <input type="checkbox" class="schedule-per-date-record-input" data-date="${key}"${isRecording ? ' checked' : ''}>
              <i class="fas fa-video"></i> Record
            </label>
          </div>
        </div>
      `;
    }).join('');

    const syncRowOverride = (row, key) => {
      const startVal = row.querySelector('.schedule-per-date-start').value || defaultStart;
      const durationVal = parseInt(row.querySelector('.schedule-per-date-duration').value, 10) || defaultDuration;
      const recordVal = row.querySelector('.schedule-per-date-record-input').checked;
      schedulePerDateOverrides.set(key, { start: startVal, duration: durationVal, record: recordVal });
      row.querySelector('.schedule-per-date-end').textContent = `Ends ${computeScheduleEndLabel(startVal, durationVal)}`;
    };

    DOM.schedulePerDateList.querySelectorAll('.schedule-per-date-start, .schedule-per-date-duration').forEach((input) => {
      input.addEventListener('input', () => syncRowOverride(input.closest('.schedule-per-date-row'), input.dataset.date));
    });
    DOM.schedulePerDateList.querySelectorAll('.schedule-per-date-record-input').forEach((input) => {
      input.addEventListener('change', () => {
        const row = input.closest('.schedule-per-date-row');
        syncRowOverride(row, input.dataset.date);
        row.querySelector('.schedule-per-date-record').classList.toggle('is-active', input.checked);
      });
    });
  }

  async function setClassSchedule(teacherUsername, occurrences) {
    if (!state.currentChannel) { alert('Select a channel first.'); return false; }
    teacherUsername = normalizeUsername(teacherUsername);
    if (!teacherUsername) { alert('Enter a teacher username.'); return false; }
    if (!occurrences || !occurrences.length) { alert('Tap at least one date on the calendar.'); return false; }

    const registeredRole = state.roleCache[teacherUsername.toLowerCase()];
    if (registeredRole !== CONFIG.AUTH.ROLES.TEACHER) {
      alert(`"${teacherUsername}" isn't a registered teacher account. Create it first from Settings → Add teacher or student.`);
      return false;
    }

    // FIX: "add record this session option for individual session
    // instead of whole group" — auto_record_enabled (the actual column
    // below) was always stored PER ROW already; what wasn't per-row was
    // where this value came FROM. It used to be read once from the
    // shared "Record this session automatically" checkbox and stamped
    // onto every row in the whole batch, so scheduling e.g. 5 dates with
    // it checked recorded all 5 with no way to record just one of them.
    // Whether to record is now decided per occurrence (occ.record — see
    // renderSchedulePerDateList() and the DOM.setScheduleBtn click
    // handler, which sets it from the shared checkbox in "same time for
    // every date" mode, or from each date's own checkbox in
    // #schedulePerDateList otherwise).
    //
    // REMOVED: this form used to also collect a per-batch retention
    // value (recording_retention_days, later recording_retention_minutes)
    // and write it onto every row here. Deletion is now handled uniformly
    // by an R2 Object Lifecycle Rule on the bucket instead, so there's
    // nothing for this form to collect or write anymore.
    const rows = [];
    for (const occ of occurrences) {
      if (!occ.start) { alert(`Enter a start time for ${scheduleDateLabel(occ.dateKey)}.`); return false; }
      const duration = Math.round(Number(occ.duration));
      if (!Number.isFinite(duration) || duration <= 0) {
        alert(`Enter a valid duration for ${scheduleDateLabel(occ.dateKey)}.`);
        return false;
      }
      if (duration > MAX_SESSION_DURATION_MINUTES) {
        alert(`A single session can't be longer than ${MAX_SESSION_DURATION_MINUTES / 60} hours (${scheduleDateLabel(occ.dateKey)}).`);
        return false;
      }
      const start = new Date(`${occ.dateKey}T${occ.start}`);
      if (Number.isNaN(start.getTime())) {
        alert(`That date/time couldn't be understood for ${scheduleDateLabel(occ.dateKey)}.`);
        return false;
      }
      rows.push({
        channel_id: state.currentChannel.id,
        teacher_username: teacherUsername,
        scheduled_time: start.toISOString(),
        duration_minutes: duration,
        set_by: state.currentUser.username,
        auto_record_enabled: !!occ.record,
      });
    }

    const { error } = await supabase.from('class_schedule').insert(rows);

    if (error) { alert('Could not set schedule: ' + error.message); return false; }
    alert(
      rows.length === 1
        ? `✅ Class time set for ${teacherUsername}`
        : `✅ ${rows.length} sessions scheduled for ${teacherUsername}.`
    );
    await loadSchedule(state.currentChannel.id);
    return true;
  }

  // ============================================================
  // 8f. ADMIN — ALL-GROUPS LIVE SESSIONS CALENDAR
  // ============================================================
  let calendarSubscription = null;
  let calendarHasData = false;
  let calendarLoadInFlight = false;

  async function loadAllSchedules() {
    if (calendarLoadInFlight) return;
    calendarLoadInFlight = true;

    if (DOM.calendarList && !calendarHasData) {
      DOM.calendarList.innerHTML = '<div class="empty-note">Loading schedule…</div>';
    }

    try {
      const { data, error } = await supabase
        .from('class_schedule')
        .select('*')
        .gte('scheduled_time', new Date(Date.now() - 60 * 60 * 1000).toISOString())
        .order('scheduled_time', { ascending: true });

      if (error) {
        console.warn('loadAllSchedules failed:', error);
        if (DOM.calendarList && !calendarHasData) {
          DOM.calendarList.innerHTML = '<div class="empty-note">Could not load the schedule.</div>';
        }
        return;
      }
      calendarHasData = true;
      renderCalendarList(data || []);
    } finally {
      calendarLoadInFlight = false;
    }
  }

  function renderCalendarList(rows) {
    if (!DOM.calendarList) return;

    // FIX: root cause of "ended meeting still shown in Live Sessions
    // Calendar" — this function used to render every row the query
    // returned, with no filtering at all, so a session that had
    // genuinely finished (whether its scheduled window fully elapsed,
    // or it was explicitly/automatically ended early via is_live:
    // false) stayed listed — just without the live badge — until the
    // 1-hour-ago query cutoff eventually excluded it. The per-channel
    // "Scheduled Classes" list on the Profile page already filtered
    // this correctly (see renderGroupScheduleRows); this brings the
    // admin's global calendar in line with the same isScheduleRowRelevant
    // check, so a finished session disappears from both places at the
    // same moment instead of only losing its "live" styling here.
    const now = Date.now();
    rows = (rows || []).filter((row) => isScheduleRowRelevant(row, now));

    if (!rows.length) {
      DOM.calendarList.innerHTML = '<div class="empty-note">No live sessions scheduled in any group yet.</div>';
      return;
    }

    const channelNameById = new Map(allChannels.map((c) => [String(c.id), c.name]));

    const dayOrder = [];
    const dayGroups = new Map();
    rows.forEach((row) => {
      const dateKey = new Date(row.scheduled_time).toDateString();
      if (!dayGroups.has(dateKey)) {
        dayGroups.set(dateKey, []);
        dayOrder.push(dateKey);
      }
      dayGroups.get(dateKey).push(row);
    });

    const todayKey = new Date().toDateString();
    const tomorrowKey = new Date(Date.now() + 24 * 60 * 60 * 1000).toDateString();

    DOM.calendarList.innerHTML = dayOrder.map((dateKey) => {
      const dayRows = dayGroups.get(dateKey);
      let dayLabel;
      if (dateKey === todayKey) dayLabel = 'Today';
      else if (dateKey === tomorrowKey) dayLabel = 'Tomorrow';
      else dayLabel = new Date(dayRows[0].scheduled_time).toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });

      return `
        <div class="calendar-day-group">
          <div class="calendar-day-label">${escapeHtml(dayLabel)}</div>
          ${dayRows.map((row) => calendarItemHtml(row, channelNameById)).join('')}
        </div>
      `;
    }).join('');

    DOM.calendarList.querySelectorAll('.calendar-item-link').forEach((el) => {
      el.addEventListener('click', () => {
        const channel = allChannels.find((c) => String(c.id) === el.dataset.channelId);
        if (!channel) { alert('That group no longer exists.'); return; }
        selectChannel(channel);
        goToScreen('profile');
      });
    });
    DOM.calendarList.querySelectorAll('.calendar-item-delete').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const ok = await deleteScheduledSession(btn.dataset.id);
        if (ok) loadAllSchedules();
      });
    });
    DOM.calendarList.querySelectorAll('.calendar-item-end').forEach((btn) => {
      btn.addEventListener('click', () => endScheduledSessionNow(btn.dataset.id));
    });
  }

  function calendarItemHtml(row, channelNameById) {
    const start = new Date(row.scheduled_time);
    const durationMinutes = row.duration_minutes || 45;
    const end = new Date(start.getTime() + durationMinutes * 60000);
    const startLabel = start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    const endLabel = end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    const groupName = channelNameById.get(String(row.channel_id)) || 'Unknown group';
    // FIX: root cause of "live meetings not shown" — the `row.is_live
    // !== false` check added here previously couldn't tell a
    // not-yet-started scheduled session (is_live sits at the
    // database's own default of `false` until someone actually clicks
    // Start) apart from one that was started and then explicitly ended
    // early (also is_live: false) — so a session simply waiting to be
    // started lost its live badge the moment its window opened. This
    // row is already filtered to only ever render while
    // isScheduleRowRelevant() (above) says it's relevant, and that
    // function no longer relies on is_live either — see its comment —
    // so a plain time-window check here is correct and sufficient.
    const isLiveNow = Date.now() >= start.getTime() && Date.now() < end.getTime();
    // FIX: root cause of "recording icon for auto-recording-enabled
    // sessions is not shown" — `auto_record_enabled` is a real column on
    // class_schedule (set from the per-date schedule editor, see
    // schedule-per-date-record above) but this function — the one that
    // actually renders each row in the admin's Live Sessions Calendar —
    // never read it or rendered anything for it. Added a small red
    // "recording" dot with a tooltip so admins can tell at a glance
    // which sessions on this list will auto-record.
    const isAutoRecording = !!row.auto_record_enabled;

    return `
      <div class="calendar-item${isLiveNow ? ' is-live' : ''}">
        <button type="button" class="calendar-item-link" data-channel-id="${escapeHtml(String(row.channel_id))}">
          <div class="calendar-item-time">
            <span class="calendar-item-time-start">${startLabel}</span>
            <span class="calendar-item-time-end">${endLabel}</span>
          </div>
          <div class="calendar-item-text">
            <div class="calendar-item-group">${escapeHtml(groupName)}</div>
            <div class="calendar-item-teacher"><i class="fas fa-chalkboard-user"></i> ${escapeHtml(getDisplayName(row.teacher_username))}</div>
          </div>
          <div class="calendar-item-duration">${isLiveNow ? '<span class="calendar-live-dot" title="Live now"></span>' : ''}${isAutoRecording ? '<i class="fas fa-circle calendar-item-record-icon" title="Auto-recording enabled"></i>' : ''}${durationMinutes}m</div>
        </button>
        <div class="calendar-item-admin-actions">
          ${isLiveNow ? `<button type="button" class="icon-btn calendar-item-end" data-id="${row.id}" title="End this live session now for everyone"><i class="fas fa-ban" style="color:var(--danger);"></i></button>` : ''}
          <button type="button" class="icon-btn calendar-item-delete" data-id="${row.id}" title="Delete"><i class="fas fa-trash" style="color:var(--danger);"></i></button>
        </div>
      </div>
    `;
  }

  let calendarLiveRefreshInterval = null;

  function subscribeToAllSchedules() {
    if (calendarSubscription) {
      supabase.removeChannel(calendarSubscription);
      calendarSubscription = null;
    }
    calendarSubscription = supabase
      .channel('schedule:all')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'class_schedule' }, () => loadAllSchedules())
      .subscribe();

    if (calendarLiveRefreshInterval) clearInterval(calendarLiveRefreshInterval);
    calendarLiveRefreshInterval = setInterval(() => loadAllSchedules(), 30000);
  }

  function unsubscribeFromAllSchedules() {
    if (calendarSubscription) {
      supabase.removeChannel(calendarSubscription);
      calendarSubscription = null;
    }
    if (calendarLiveRefreshInterval) {
      clearInterval(calendarLiveRefreshInterval);
      calendarLiveRefreshInterval = null;
    }
  }

  // ============================================================
  // 8a. CHANNEL DESCRIPTION
  // ============================================================
  function loadChannelDescription(channelId) {
    if (!channelId || !state.currentChannel || state.currentChannel.id !== channelId) return;

    const fallback = `Group workspace for ${state.currentChannel?.name || 'this group'}. Share updates, chat with the group, and join live sessions together.`;
    const desc = state.currentChannel.description || fallback;
    // FIX: was `.textContent = desc`, which showed the raw *bold*/_italic_
    // markers literally instead of rendering them — now that the admin
    // description editor has a formatting toolbar (#descFormatToolbar),
    // this needs to render those markers for every viewer, not just echo
    // the plain saved string. renderRichBlocks() escapes the text itself
    // (via linkifyText()'s internal escapeHtml()) before turning markers
    // into real tags, so this stays safe against HTML injection.
    // FIX: root cause of "left/right alignment not working, everything
    // shows centered" — this used to only set an explicit style.textAlign
    // for 'center'/'right' and CLEAR it (style.textAlign = '') for 'left',
    // trusting the browser's own left-by-default behavior. But
    // .profile-card-desc sits inside .profile-card, which sets its own
    // text-align: center (for the card's name/meta above it) — and
    // text-align is an inherited CSS property, so clearing the inline
    // override on 'left' let that ancestor's center win instead of
    // browser-default left. renderRichBlocks() now sets an explicit
    // text-align on each rendered line itself (alignment is per-line, not
    // once for the whole field — see the "RICH TEXT EDITOR" section
    // above), so there's no longer a single container-level style to set.
    DOM.profileChannelDesc.innerHTML = renderRichBlocks(desc);
    populateRichEditor(DOM.channelDescInput, state.currentChannel.description || '');

    // FIX: root cause of "the group description editable box appears
    // always to admin" — this used to toggle #adminDescEdit (the whole
    // toolbar + editor + Save button) straight off state.isAdmin, so it
    // sat open for every admin on every visit to this screen instead of
    // only when they actually wanted to make a change. Now only the
    // pencil "Edit description" button is admin-gated here; the edit
    // panel itself always starts closed (also closing it back down if it
    // happened to be left open from a previous channel/visit) and is
    // opened only by that button's click handler below.
    DOM.channelDescEditBtn.classList.toggle('hidden', !state.isAdmin);
    DOM.adminDescEdit.classList.add('hidden');
  }

  async function updateChannelDescription(channelId, description) {
    if (!channelId) { alert('Select a channel first.'); return; }
    if (!description) { alert('Enter a description.'); return; }

    const { error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.CHANNELS)
      .update({ description: description })
      .eq('id', channelId);

    if (error) { alert('Could not update description: ' + error.message); return; }

    if (state.currentChannel && state.currentChannel.id === channelId) {
      state.currentChannel.description = description;
    }
    loadChannelDescription(channelId);
    alert('Description updated successfully!');
  }

  // ============================================================
  // 13. PROFILE & SHARED MEDIA SCREEN
  // ============================================================
  function updateProfileMeta() {
    if (!state.currentChannel) return;
    const total = state.currentMembers.length;
    const online = state.currentMembers.filter((m) => state.onlineUsers.has((m.username || '').toLowerCase())).length;
    DOM.profileChannelMeta.textContent = total ? `${total} member${total === 1 ? '' : 's'} · ${online} online` : '';
  }

  // FIX: root cause of "can't see the unloaded media of group in shared
  // media section" — renderSharedPhotos()/renderSharedVideos() filtered
  // state.messages, but state.messages is NOT the channel's full history:
  // loadMessages()/loadOlderMessages() page it in 50 rows at a time (see
  // MESSAGES_PER_PAGE), so at any moment state.messages only holds
  // whichever page(s) of chat the person has scrolled through. Any photo
  // or video sent in a message older than what's currently scrolled into
  // view simply wasn't in that array yet — Shared Media looked empty or
  // incomplete for exactly that media, even though it was never deleted
  // and isn't expired. It only ever "worked" by accident, when someone
  // happened to have scrolled far enough back for it to already be
  // loaded. This queries the DB directly for the channel's media instead,
  // completely independent of chat scroll position/pagination.
  async function loadSharedMedia(channelId) {
    if (!channelId) return;
    try {
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MESSAGES)
        .select('id, file_url, created_at')
        .eq('channel_id', channelId)
        .not('file_url', 'is', null)
        .is('deleted_at', null)
        .order('created_at', { ascending: true })
        .limit(500);

      if (error) {
        console.warn('Failed to load shared media:', error);
        return;
      }

      state.sharedMediaChannelId = channelId;
      state.sharedPhotoMessages = (data || []).filter((m) => isImageFile(m.file_url) && !isMessageMediaExpired(m));
      state.sharedVideoMessages = (data || []).filter((m) => isVideoFile(m.file_url) && !isMessageMediaExpired(m));

      // Only repaint if the person is still looking at this same
      // channel's profile screen — this fetch is async and the person may
      // have already navigated elsewhere by the time it resolves.
      if (state.currentChannel && state.currentChannel.id === channelId) {
        renderSharedPhotos();
        renderSharedVideos();
      }
    } catch (e) {
      console.warn('Error loading shared media:', e);
    }
  }

  function updateProfileScreen() {
    if (!state.currentChannel) return;
    DOM.profileChannelName.textContent = state.currentChannel.name;
    loadChannelDescription(state.currentChannel.id);
    updateProfileMeta();
    loadGroupScheduleList(state.currentChannel.id);

    if (DOM.scheduleCalGrid && scheduleCalendarChannelId !== state.currentChannel.id) {
      scheduleCalendarChannelId = state.currentChannel.id;
      resetScheduleSelection();
      renderScheduleCalendar();
      renderScheduleSelectedDates();
      renderSchedulePerDateList();
    }

    // Render immediately from whatever's already cached for this channel
    // (instant, no flash of "No shared photos yet" while the fetch below
    // is in flight if we've already loaded this channel's media before),
    // then kick off a fresh load to catch anything new or, on first visit
    // to this channel, populate the cache for the first time.
    renderSharedPhotos();
    renderSharedVideos();
    loadSharedMedia(state.currentChannel.id);
  }

  // FIX: this grid is a fixed 5-column layout (.shared-media-grid,
  // styles.css, shared by both the photos and videos grids), but the
  // collapsed/"Show Less" preview cap here was still the old pre-5-column
  // number (6) left over from before that grid became a fixed row size —
  // 6 items in a 5-column grid wraps to a second row for just the 6th
  // tile. One shared constant (below) now drives both grids' preview
  // caps, so they can't drift out of sync with the grid's actual column
  // count again.
  const SHARED_MEDIA_ROW_PREVIEW_COUNT = 5;

  // FIX: "make separate folder in share media one for images and one for
  // video" — was one mixed grid/filter (isImageFile() || isVideoFile());
  // now two fully independent grids/preview caps/"See All" states, each
  // with its own dataset.showAll flag on its own grid element.
  function renderSharedPhotos() {
    const photos = state.sharedPhotoMessages;
    if (!photos.length) {
      DOM.sharedPhotosGrid.innerHTML = '<div class="empty-note">No shared photos yet</div>';
      DOM.profileSeeAllPhotos.classList.add('hidden');
      state.sharedMediaUrls = [];
      return;
    }
    const showAll = DOM.sharedPhotosGrid.dataset.showAll === 'true';
    const shown = showAll ? photos : photos.slice(-SHARED_MEDIA_ROW_PREVIEW_COUNT);
    state.sharedMediaUrls = shown.map((m) => m.file_url);
    DOM.sharedPhotosGrid.innerHTML = shown.map((m, i) => `<img class="shared-media-tile" src="${escapeHtml(m.file_url)}" data-media-url="${escapeHtml(m.file_url)}" data-media-id="${escapeHtml(String(m.id))}" data-media-index="${i}" alt="Shared photo" loading="lazy" style="cursor:pointer;">`).join('');
    DOM.profileSeeAllPhotos.classList.toggle('hidden', photos.length <= SHARED_MEDIA_ROW_PREVIEW_COUNT);
    // FIX: root cause of "the See All link works only for expansion not
    // for contraction" — the link's label never changed off "See All", so
    // there was no visible affordance to collapse back down (its click
    // handler below only ever set showAll to 'true', never back to
    // 'false', for the same reason: nothing here ever told it a collapse
    // was even possible). Swapping the label whenever this actually
    // renders the expanded state gives the click handler something
    // meaningful to toggle.
    DOM.profileSeeAllPhotos.textContent = showAll ? 'Show Less' : 'See All';

    // FIX: root cause of "media deleted from Cloudflare R2 isn't removed
    // from the Shared Media panel" — this grid renders straight off
    // state.sharedPhotoMessages, which loadSharedMedia() only filters by
    // the MESSAGE row (deleted_at IS NULL) and by age
    // (isMessageMediaExpired(), the 168h retention window). Neither of
    // those actually checks whether the R2 OBJECT itself still exists.
    // The R2 Lifecycle rule (or someone manually deleting the object from
    // the R2/Storage dashboard) removes the file without touching the
    // message row or its created_at at all, so this tile kept pointing at
    // a 404 forever — a permanently broken image icon that nothing ever
    // cleared. The chat bubble already solves this exact problem via
    // attachMediaFailureHandler() (a real 'error' load-failure listener,
    // independent of age/deleted_at) — wiring the same signal in here: on
    // an actual failed load, drop that message from
    // state.sharedPhotoMessages and re-render, so a photo that's really
    // gone from R2 disappears from Shared Photos instead of sitting there
    // broken.
    DOM.sharedPhotosGrid.querySelectorAll('img.shared-media-tile').forEach((img) => {
      img.addEventListener('error', () => {
        const id = img.dataset.mediaId;
        state.sharedPhotoMessages = state.sharedPhotoMessages.filter((m) => String(m.id) !== id);
        renderSharedPhotos();
      }, { once: true });
    });
  }

  function renderSharedVideos() {
    const videos = state.sharedVideoMessages;
    if (!videos.length) {
      DOM.sharedVideosGrid.innerHTML = '<div class="empty-note">No shared videos yet</div>';
      DOM.profileSeeAllVideos.classList.add('hidden');
      return;
    }
    const showAll = DOM.sharedVideosGrid.dataset.showAll === 'true';
    const shown = showAll ? videos : videos.slice(-SHARED_MEDIA_ROW_PREVIEW_COUNT);
    DOM.sharedVideosGrid.innerHTML = shown.map((m) => `
      <div class="shared-media-tile shared-media-video-tile" data-media-url="${escapeHtml(m.file_url)}" data-media-id="${escapeHtml(String(m.id))}" style="cursor:pointer;">
        <video src="${escapeHtml(m.file_url)}" preload="metadata" muted playsinline></video>
        <span class="shared-media-play-badge" aria-hidden="true"><i class="fas fa-play"></i></span>
      </div>
    `).join('');
    DOM.profileSeeAllVideos.classList.toggle('hidden', videos.length <= SHARED_MEDIA_ROW_PREVIEW_COUNT);
    // FIX: see the matching FIX comment in renderSharedPhotos() above —
    // same root cause, same fix, just for the videos grid/link pair.
    DOM.profileSeeAllVideos.textContent = showAll ? 'Show Less' : 'See All';

    // FIX: see the matching FIX comment in renderSharedPhotos() above —
    // same root cause (a file removed from R2 early, out-of-band, never
    // clears the message row/created_at that this grid renders from), same
    // fix, just for videos. The <video> element fires its own 'error'
    // event when its src 404s, exactly like <img> does, so the same
    // load-failure-driven prune works here.
    DOM.sharedVideosGrid.querySelectorAll('.shared-media-video-tile').forEach((tile) => {
      const videoEl = tile.querySelector('video');
      if (!videoEl) return;
      videoEl.addEventListener('error', () => {
        const id = tile.dataset.mediaId;
        state.sharedVideoMessages = state.sharedVideoMessages.filter((m) => String(m.id) !== id);
        renderSharedVideos();
      }, { once: true });
    });
  }

  // ============================================================
  // 10. STATUS UPDATES
  // ============================================================
  async function loadStatuses() {
    const nowIso = new Date().toISOString();
    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.STATUSES)
      .select('*')
      .or(`expires_at.is.null,expires_at.gt.${nowIso}`)
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      state.statuses = [{ id: '1', content: 'Welcome to Nous Complex Orbit!', username: 'admin', created_at: Date.now() }];
    } else {
      state.statuses = data || [];
    }
    await loadStatusViews(state.statuses.map((s) => s.id));
    subscribeToStatusViews();
    subscribeToStatuses();
    startStatusExpiryWatcher();
    renderStatuses();
    updateStatusNavBadge();
  }

  function updateStatusNavBadge() {
    if (!DOM.navUpdatesBadge || !state.currentUser) return;
    const me = state.currentUser.username;
    const hasUnseen = state.statuses.some((st) => {
      if (normalizeUsername(st.username) === me) return false;
      const viewers = state.statusViews.get(st.id) || [];
      return !viewers.some((v) => v.username === me);
    });
    DOM.navUpdatesBadge.classList.toggle('hidden', !hasUnseen);
  }

  // ============================================================
  // 10b. UPDATE (STATUS) READ RECEIPTS — "seen by"
  // ============================================================
  async function loadStatusViews(statusIds) {
    state.statusViews = new Map();
    if (!statusIds || !statusIds.length) return;

    const { data, error } = await supabase
      .from('status_views')
      .select('status_id, username, viewed_at')
      .in('status_id', statusIds);

    if (error) {
      console.warn('Failed to load status views (create a `status_views` table with SELECT/INSERT policies if missing):', error);
      return;
    }
    (data || []).forEach((row) => {
      const list = state.statusViews.get(row.status_id) || [];
      list.push({ username: row.username, viewed_at: row.viewed_at });
      state.statusViews.set(row.status_id, list);
    });
  }

  function teardownStatusViewsSubscription() {
    if (!state.statusViewsSubscription) return;
    supabase.removeChannel(state.statusViewsSubscription);
    state.statusViewsSubscription = null;
  }

  function subscribeToStatusViews() {
    teardownStatusViewsSubscription();
    state.statusViewsSubscription = supabase
      .channel('status_views:all')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'status_views',
      }, (payload) => {
        const row = payload.new;
        const list = state.statusViews.get(row.status_id) || [];
        if (!list.some((r) => r.username === row.username)) {
          list.push({ username: row.username, viewed_at: row.viewed_at });
          state.statusViews.set(row.status_id, list);
          renderStatuses();
        }
      })
      .subscribe();
  }

  // FIX: root cause of "status doesn't appear and hide in real-time" —
  // loadStatuses() only ran once at login/session-restore (plus after this
  // device's own post/delete), with no realtime subscription on the
  // `statuses` table itself. So a status someone else just posted never
  // showed up in the Updates tray until this device happened to reload the
  // whole app, and a status that expired while the tray was sitting open
  // never disappeared either — state.statuses was only ever re-filtered by
  // expires_at at the moment of that one-time fetch. Two pieces fix this:
  // this postgres_changes subscription (statuses appear/update/delete live,
  // mirroring subscribeToStatusViews() above) and the expiry watcher below
  // it (statuses that simply age past expires_at while nobody touched the
  // table also get swept away on a short timer, not just on the next
  // insert/delete from someone else).
  function teardownStatusesSubscription() {
    if (!state.statusesSubscription) return;
    supabase.removeChannel(state.statusesSubscription);
    state.statusesSubscription = null;
  }

  function isStatusExpired(row, nowMs) {
    return !!(row.expires_at && new Date(row.expires_at).getTime() <= nowMs);
  }

  function subscribeToStatuses() {
    teardownStatusesSubscription();
    state.statusesSubscription = supabase
      .channel('statuses:all')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: CONFIG.SUPABASE.TABLES.STATUSES,
      }, (payload) => {
        const nowMs = Date.now();
        if (payload.eventType === 'INSERT') {
          const row = payload.new;
          if (isStatusExpired(row, nowMs)) return; // clock-skew edge case — arrived already expired
          if (state.statuses.some((s) => s.id === row.id)) return;
          state.statuses = [row, ...state.statuses]
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
            .slice(0, 10);
        } else if (payload.eventType === 'UPDATE') {
          const row = payload.new;
          state.statuses = isStatusExpired(row, nowMs)
            ? state.statuses.filter((s) => s.id !== row.id)
            : state.statuses.map((s) => (s.id === row.id ? row : s));
        } else if (payload.eventType === 'DELETE') {
          const oldId = payload.old?.id;
          if (!oldId) return;
          state.statuses = state.statuses.filter((s) => s.id !== oldId);
        } else {
          return;
        }
        renderStatuses();
        updateStatusNavBadge();
      })
      .subscribe();
  }

  // 30s is plenty granular against the shortest expiry option (1h) and
  // matches the existing startMediaExpiryWatcher() pattern used to solve
  // the identical "nothing re-evaluates a timestamp once time has actually
  // passed" problem for expired message media.
  const STATUS_EXPIRY_WATCH_INTERVAL = 30 * 1000;
  let statusExpiryWatcherTimer = null;

  function startStatusExpiryWatcher() {
    stopStatusExpiryWatcher();
    statusExpiryWatcherTimer = setInterval(() => {
      if (!state.statuses.length) return;
      const nowMs = Date.now();
      const before = state.statuses.length;
      state.statuses = state.statuses.filter((s) => !isStatusExpired(s, nowMs));
      if (state.statuses.length !== before) {
        renderStatuses();
        updateStatusNavBadge();
      }
    }, STATUS_EXPIRY_WATCH_INTERVAL);
  }

  function stopStatusExpiryWatcher() {
    if (statusExpiryWatcherTimer) {
      clearInterval(statusExpiryWatcherTimer);
      statusExpiryWatcherTimer = null;
    }
  }

  async function recordStatusView(status) {
    if (!status || !state.currentUser) return;
    if (normalizeUsername(status.username) === state.currentUser.username) return;

    const row = { status_id: status.id, username: state.currentUser.username, viewed_at: new Date().toISOString() };
    const { error } = await supabase
      .from('status_views')
      .upsert(row, { onConflict: 'status_id,username', ignoreDuplicates: true });

    if (error) {
      console.warn('Failed to record status view (create a `status_views` table with an INSERT policy if missing):', error);
      return;
    }

    const list = state.statusViews.get(status.id) || [];
    if (!list.some((r) => r.username === row.username)) {
      list.push({ username: row.username, viewed_at: row.viewed_at });
      state.statusViews.set(status.id, list);
      if (state.isAdmin) renderStatuses();
      updateStatusNavBadge();
    }
  }

  function openStatusInfoModal(status) {
    if (!status) return;
    const views = (state.statusViews.get(status.id) || [])
      .slice()
      .sort((a, b) => new Date(a.viewed_at) - new Date(b.viewed_at));
    const seenUsernames = new Set(views.map((v) => v.username));

    const posterKey = normalizeUsername(status.username);
    const allOtherUsers = Object.keys(state.roleCache)
      .filter((u) => u !== posterKey)
      .sort((a, b) => getDisplayName(a).localeCompare(getDisplayName(b)));
    const notSeen = allOtherUsers.filter((u) => !seenUsernames.has(u));

    const rowHtml = (username, timeHtml) => `
      <div class="msg-info-row">
        ${avatarHtml(username, 'sm')}
        <span class="msg-info-name">${escapeHtml(getDisplayName(username))}</span>
        ${timeHtml}
      </div>
    `;

    const seenRows = views.length
      ? views.map((v) => rowHtml(v.username, `<span class="msg-info-time">${escapeHtml(formatFullDate(v.viewed_at))}</span>`)).join('')
      : `<div class="empty-note">No one yet</div>`;

    const notSeenRows = notSeen.length
      ? notSeen.map((u) => rowHtml(u, `<span class="msg-info-time msg-info-notdelivered">Not seen</span>`)).join('')
      : `<div class="empty-note">Everyone has seen this</div>`;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card">
        <div class="modal-title"><i class="fas fa-eye"></i> Seen by</div>
        <div class="msg-info-section-label">Seen (${views.length})</div>
        <div class="msg-info-list">${seenRows}</div>
        <div class="msg-info-section-label">Not seen yet (${notSeen.length})</div>
        <div class="msg-info-list">${notSeenRows}</div>
        <button class="btn-secondary msg-info-close" style="width:100%; margin-top:14px;">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('.msg-info-close').addEventListener('click', close);
  }

  function renderStatuses() {
    exitStatusSelection();
    DOM.statusTray.innerHTML = '';

    if (!state.statuses.length) {
      DOM.statusTray.innerHTML = '<div class="empty-note">No updates yet</div>';
    } else {
      state.statuses.forEach((st) => {
        const item = document.createElement('div');
        item.className = 'update-row';
        item.dataset.id = st.id;
        const displayName = getDisplayName(st.username);
        // FIX: truncate() used to run on the raw st.content, so a status
        // whose first line carries a [[align:center]] directive (see
        // applyEditorAlign() in app.js) showed that literal marker text at
        // the front of its list-row preview. stripAlignPrefix() removes it
        // before truncating; the *bold*/_italic_/~strike~ inline markers
        // still show as raw characters here — this is only a truncated
        // plain-text snippet, not the full rich render showStatusModal()
        // does.
        const statusPreviewText = stripAlignPrefix(st.content);
        const statusPreviewLinkUrl = statusPreviewText ? firstUrlIn(statusPreviewText) : null;
        // FIX: root cause of "asterisks still shown for bold text on the
        // status screen" — this is the Updates LIST row preview, a
        // different render path from the full-screen viewer (showStatusModal()
        // → renderRichBlocks(), which already handled markers correctly).
        // This one used to run straight through escapeHtml(truncate(...))
        // with no applyInlineFormatting() step at all, so *bold*/_italic_/
        // ~strike~/```mono``` markers always showed as literal characters
        // here even though the full viewer rendered them correctly.
        // truncate() still runs on the raw text first (unchanged) — cutting
        // a marker pair in half at the truncation boundary just leaves a
        // stray, harmless asterisk/underscore in the preview, same
        // trade-off every truncated-markdown preview (Slack, GitHub, etc.)
        // makes.
        const statusPreviewHtml = applyInlineFormatting(escapeHtml(truncate(statusPreviewText, 46)));
        const preview = statusPreviewText
          ? (statusPreviewLinkUrl
              ? `<a href="${escapeHtml(statusPreviewLinkUrl)}" rel="noopener" class="msg-link">${statusPreviewHtml}</a>`
              : statusPreviewHtml)
          : (st.media_url ? '<i class="fas fa-camera"></i> Photo/video' : '');
        const seenCount = (state.statusViews.get(st.id) || []).length;
        const seenBadge = state.isAdmin
          ? `<span class="update-row-seen"><i class="fas fa-eye"></i> ${seenCount}</span>`
          : '';
        item.innerHTML = `
          ${avatarHtml(st.username)}
          <div class="update-row-body">
            <div class="update-row-name">${escapeHtml(displayName)}</div>
            <div class="update-row-preview">${preview}</div>
          </div>
          <div class="update-row-time">
            ${formatTimeAgo(st.created_at)}
            ${seenBadge}
          </div>
        `;
        if (state.isAdmin) {
          item.addEventListener('touchstart', () => startStatusLongPress(item, st), { passive: true });
          ['touchend', 'touchmove', 'touchcancel'].forEach((evt) => {
            item.addEventListener(evt, clearStatusLongPressTimer);
          });
          item.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            selectStatusForActions(item, st);
          });
        }
        item.addEventListener('pointerup', (e) => {
          if (e.button === 2) return;
          if (statusLongPressFired) { statusLongPressFired = false; return; }
          if (e.target.closest('a.msg-link')) return;
          e.preventDefault();
          showStatusModal(st);
        });
        item.addEventListener('click', (e) => {
          const link = e.target.closest('a.msg-link');
          if (!link) return;
          e.preventDefault();
          e.stopPropagation();
          openExternalLink(link.getAttribute('href'));
        });
        DOM.statusTray.appendChild(item);
      });
    }

    const shouldShow = state.isAdmin && CONFIG.FEATURES.ENABLE_STATUS_UPDATES;
    DOM.statusAddBtn.classList.toggle('hidden', !shouldShow);
    if (DOM.postStatusFab) DOM.postStatusFab.classList.add('hidden');
  }

  async function deleteStatus(statusId) {
    if (!confirm('Delete this status update?')) return;
    const { error } = await supabase.from(CONFIG.SUPABASE.TABLES.STATUSES).delete().eq('id', statusId);
    if (error) { alert('Delete failed: ' + error.message); return; }
    await loadStatuses();
  }

  let statusLongPressTimer = null;
  let statusLongPressFired = false;
  let selectedStatus = null;

  function clearStatusLongPressTimer() {
    if (statusLongPressTimer) { clearTimeout(statusLongPressTimer); statusLongPressTimer = null; }
  }

  function startStatusLongPress(row, st) {
    clearStatusLongPressTimer();
    statusLongPressTimer = setTimeout(() => {
      statusLongPressFired = true;
      selectStatusForActions(row, st);
    }, 500);
  }

  function selectStatusForActions(row, st) {
    exitStatusSelection();
    selectedStatus = st;
    row.classList.add('active');

    if (DOM.updatesScreenHeader) DOM.updatesScreenHeader.classList.add('hidden');
    if (DOM.statusSelectHeader) DOM.statusSelectHeader.classList.remove('hidden');
    if (DOM.statusSelectCount) DOM.statusSelectCount.textContent = getDisplayName(st.username);
  }

  function exitStatusSelection() {
    if (!selectedStatus) return;
    selectedStatus = null;

    if (DOM.statusSelectHeader) DOM.statusSelectHeader.classList.add('hidden');
    if (DOM.updatesScreenHeader) DOM.updatesScreenHeader.classList.remove('hidden');
    DOM.statusTray.querySelectorAll('.update-row.active').forEach((r) => r.classList.remove('active'));
  }

  if (DOM.statusSelectCloseBtn) DOM.statusSelectCloseBtn.addEventListener('click', exitStatusSelection);

  if (DOM.statusSelectInfoBtn) {
    DOM.statusSelectInfoBtn.addEventListener('click', () => {
      const st = selectedStatus;
      exitStatusSelection();
      if (st) openStatusInfoModal(st);
    });
  }

  if (DOM.statusSelectDeleteBtn) {
    DOM.statusSelectDeleteBtn.addEventListener('click', () => {
      const st = selectedStatus;
      exitStatusSelection();
      if (st) deleteStatus(st.id);
    });
  }

  // NOTE: no longer called — see the NOTE on generateStoragePath() above;
  // postStatus() now uses uploadFileToR2() instead. Left in place, unused.
  function generateStatusStoragePath(username, filename) {
    const ext = (filename.split('.').pop() || 'dat').toLowerCase();
    const rand = Math.random().toString(36).slice(2, 8);
    return `status/${username}/${Date.now()}-${rand}.${ext}`;
  }

  const STATUS_EXPIRY_MS = {
    '1h': 60 * 60 * 1000,
    '6h': 6 * 60 * 60 * 1000,
    '24h': 24 * 60 * 60 * 1000,
    '3d': 3 * 24 * 60 * 60 * 1000,
    '7d': 7 * 24 * 60 * 60 * 1000,
    never: null,
  };

  async function postStatus({ content, file, expiryKey }) {
    if (!state.currentUser) return;

    let mediaUrl = null;
    if (file) {
      const uploadFile = await compressImageFile(file);

      if (uploadFile.size > CONFIG.UPLOAD.MAX_FILE_SIZE) {
        alert(`File exceeds ${CONFIG.UPLOAD.MAX_FILE_SIZE / (1024 * 1024)}MB limit.`);
        return;
      }
      try {
        mediaUrl = await uploadFileToR2(uploadFile, 'status');
      } catch (e) {
        console.error('Status media upload error:', e);
        alert(`Media upload failed: ${e.message || 'unknown error — check console for details.'}`);
        return;
      }
    }

    const ms = STATUS_EXPIRY_MS[expiryKey];
    const expiresAt = ms ? new Date(Date.now() + ms).toISOString() : null;

    const { error } = await supabase.from(CONFIG.SUPABASE.TABLES.STATUSES).insert({
      username: state.currentUser.username,
      content: content || '',
      media_url: mediaUrl,
      expires_at: expiresAt,
      created_at: new Date().toISOString(),
    });
    if (error) {
      console.error('Status error:', error);
      alert('Failed to post status: ' + error.message);
      // NOTE: same as sendMessage() — no client-side cleanup needed here,
      // the R2 Lifecycle rule handles unreferenced objects automatically.
      return;
    }
    await loadStatuses();
  }

  function openStatusComposer() {
    if (!CONFIG.FEATURES.ENABLE_STATUS_UPDATES) { alert('Status updates are disabled.'); return; }

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-card">
        <h3 class="modal-title"><i class="fas fa-bullhorn"></i> Post an update</h3>
        <div id="statusFormatToolbar" class="format-toolbar" role="toolbar" aria-label="Text formatting">
          <button type="button" class="format-toolbar-btn" data-format="bold" title="Bold" aria-label="Bold"><i class="fas fa-bold"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="italic" title="Italic" aria-label="Italic"><i class="fas fa-italic"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="strike" title="Strikethrough" aria-label="Strikethrough"><i class="fas fa-strikethrough"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="mono" title="Monospace" aria-label="Monospace"><i class="fas fa-code"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="linebreak" title="Insert line break" aria-label="Insert line break"><i class="fas fa-paragraph"></i></button>
          <span class="format-toolbar-divider" aria-hidden="true"></span>
          <button type="button" class="format-toolbar-btn" data-format="align-left" title="Align left" aria-label="Align left"><i class="fas fa-align-left"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="align-center" title="Align center" aria-label="Align center"><i class="fas fa-align-center"></i></button>
          <button type="button" class="format-toolbar-btn" data-format="align-right" title="Align right" aria-label="Align right"><i class="fas fa-align-right"></i></button>
        </div>
        <div id="statusComposeText" class="field rich-editor" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Status text" data-placeholder="Write something... (Enter for a new line)" style="margin-bottom:10px;"></div>

        <label class="section-label" style="display:block; margin-bottom:6px;">Photo or video (optional)</label>
        <input id="statusComposeFile" type="file" accept="image/*,video/*" class="field" style="margin-bottom:4px;">
        <div id="statusComposeFileName" class="modal-body" style="margin:2px 0 10px; font-size:12.5px;"></div>

        <label class="section-label" style="display:block; margin-bottom:6px;">Expires</label>
        <select id="statusComposeExpiry" class="field" style="margin-bottom:16px;">
          <option value="1h">In 1 hour</option>
          <option value="6h">In 6 hours</option>
          <option value="24h" selected>In 24 hours</option>
          <option value="3d">In 3 days</option>
          <option value="7d">In 7 days</option>
          <option value="never">Never</option>
        </select>

        <div style="display:flex; gap:10px;">
          <button id="statusComposeCancel" class="btn btn-ghost" style="flex:1;">Cancel</button>
          <button id="statusComposePost" class="btn btn-primary" style="flex:1;"><i class="fas fa-paper-plane"></i> Post</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const textEl = modal.querySelector('#statusComposeText');
    const fileEl = modal.querySelector('#statusComposeFile');
    const fileNameEl = modal.querySelector('#statusComposeFileName');
    const expiryEl = modal.querySelector('#statusComposeExpiry');

    initFormatToolbar(modal.querySelector('#statusFormatToolbar'), textEl);

    fileEl.addEventListener('change', () => {
      fileNameEl.textContent = fileEl.files[0] ? `📎 ${fileEl.files[0].name}` : '';
    });

    const close = () => modal.remove();
    modal.querySelector('#statusComposeCancel').addEventListener('click', close);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

    modal.querySelector('#statusComposePost').addEventListener('click', async () => {
      const content = editorToMarkerValue(textEl).trim();
      const file = fileEl.files[0] || null;
      if (!content && !file) { alert('Add some text or a photo/video first.'); return; }

      const postBtn = modal.querySelector('#statusComposePost');
      postBtn.disabled = true;
      postBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Posting...';

      await postStatus({ content, file, expiryKey: expiryEl.value });
      close();
    });
  }

  let statusProgressValue = 0;
  let statusPaused = false;
  let statusMediaLoading = false;
  let statusMediaLoadingSafetyTimer = null;
  let currentStatusVideoEl = null;

  function showStatusModal(status) {
    suppressStatusOpenClicksUntil = Date.now() + 80;

    recordStatusView(status);

    setAvatarEl(DOM.statusViewerAvatar, status.username, 'sm status-viewer-avatar');
    DOM.statusModalTitle.textContent = getDisplayName(status.username);
    DOM.statusModalTime.textContent = formatFullDate(status.created_at);
    // FIX: was linkifyText() alone — didn't render the *bold*/_italic_/
    // ~strike~/```mono``` markers the status-composer toolbar
    // (#statusFormatToolbar) produces, so a formatted update showed its
    // raw markup instead of styled text. renderRichBlocks() = linkifyText()
    // + applyInlineFormatting(), per line.
    // FIX: same root cause as loadChannelDescription() — .status-viewer-body p
    // has its own default text-align: center, and clearing the inline
    // style for 'left' let that class default win instead of showing left.
    // renderRichBlocks() now sets an explicit text-align per rendered line
    // itself (alignment is per-line — see the "RICH TEXT EDITOR" section
    // above), so there's no single container-level style to set anymore.
    DOM.statusModalContent.innerHTML = renderRichBlocks(status.content || '');

    if (DOM.statusLinkPreview) {
      const statusLinkUrl = firstUrlIn(status.content);
      if (statusLinkUrl) {
        DOM.statusLinkPreview.innerHTML = '';
        hydrateLinkPreview(DOM.statusLinkPreview, statusLinkUrl, false);
      } else {
        DOM.statusLinkPreview.classList.add('hidden');
        DOM.statusLinkPreview.innerHTML = '';
      }
    }

    statusMediaLoading = !!status.media_url;
    if (statusMediaLoadingSafetyTimer) { clearTimeout(statusMediaLoadingSafetyTimer); statusMediaLoadingSafetyTimer = null; }
    currentStatusVideoEl = null;

    const removeMediaSpinner = () => {
      const spinnerEl = DOM.statusModalMedia.querySelector('.status-media-spinner');
      if (spinnerEl) spinnerEl.remove();
    };
    const markMediaReady = () => { statusMediaLoading = false; removeMediaSpinner(); };
    const markMediaBroken = () => {
      statusMediaLoading = false;
      DOM.statusModalMedia.innerHTML = '<div class="status-media-broken"><i class="fas fa-image"></i><span>Couldn\'t load this media</span></div>';
    };

    if (status.media_url && isVideoFile(status.media_url)) {
      DOM.statusModalMedia.innerHTML = `<video src="${escapeHtml(status.media_url)}" autoplay playsinline></video>`;
      const videoEl = DOM.statusModalMedia.querySelector('video');
      videoEl.muted = false;
      videoEl.volume = 1;
      videoEl.addEventListener('loadeddata', markMediaReady, { once: true });
      videoEl.addEventListener('error', markMediaBroken, { once: true });
      const statusVideoPlayPromise = videoEl.play();
      if (statusVideoPlayPromise && typeof statusVideoPlayPromise.catch === 'function') {
        statusVideoPlayPromise.catch(() => {
          videoEl.muted = true;
          videoEl.play().catch(() => {});
        });
      }
      DOM.statusModalMedia.insertAdjacentHTML('beforeend', '<div class="status-media-spinner" aria-hidden="true"></div>');

      currentStatusVideoEl = videoEl;
      videoEl.addEventListener('timeupdate', () => {
        if (videoEl.duration) {
          DOM.statusProgress.style.width = Math.min((videoEl.currentTime / videoEl.duration) * 100, 100) + '%';
        }
      });
      videoEl.addEventListener('ended', closeStatusViewer);
    } else if (status.media_url) {
      DOM.statusModalMedia.innerHTML = `<img src="${escapeHtml(status.media_url)}" alt="Status media">`;
      const imgEl = DOM.statusModalMedia.querySelector('img');
      if (imgEl.complete && imgEl.naturalWidth > 0) {
        markMediaReady();
      } else {
        imgEl.addEventListener('load', markMediaReady, { once: true });
        imgEl.addEventListener('error', markMediaBroken, { once: true });
        DOM.statusModalMedia.insertAdjacentHTML('beforeend', '<div class="status-media-spinner" aria-hidden="true"></div>');
      }
    } else {
      DOM.statusModalMedia.innerHTML = '';
    }
    if (statusMediaLoading) {
      statusMediaLoadingSafetyTimer = setTimeout(() => { statusMediaLoading = false; removeMediaSpinner(); }, 8000);
    }

    if (DOM.statusViewerBody) {
      DOM.statusViewerBody.classList.toggle('has-media', !!status.media_url);
    }

    DOM.statusProgress.style.width = '0%';
    DOM.statusModal.classList.remove('hidden');

    statusProgressValue = 0;
    statusPaused = false;
    updateStatusPauseIcon();
    if (state.progressInterval) clearInterval(state.progressInterval);

    if (!currentStatusVideoEl) {
      state.progressInterval = setInterval(() => {
        if (statusPaused || statusMediaLoading) return;
        statusProgressValue += 1.2;
        if (statusProgressValue >= 100) {
          clearInterval(state.progressInterval);
          state.progressInterval = null;
          DOM.statusModal.classList.add('hidden');
        }
        DOM.statusProgress.style.width = Math.min(statusProgressValue, 100) + '%';
      }, 50);
    }
  }

  function toggleStatusPause() {
    statusPaused = !statusPaused;
    if (currentStatusVideoEl) {
      if (statusPaused) {
        currentStatusVideoEl.pause();
      } else {
        currentStatusVideoEl.play().catch(() => {});
      }
    }
    updateStatusPauseIcon();
  }

  function updateStatusPauseIcon() {
    if (!DOM.statusPauseBtn) return;
    DOM.statusPauseBtn.innerHTML = statusPaused ? '<i class="fas fa-play"></i>' : '<i class="fas fa-pause"></i>';
    DOM.statusPauseBtn.title = statusPaused ? 'Resume' : 'Pause';
  }

  function closeStatusViewer() {
    DOM.statusModal.classList.add('hidden');
    if (state.progressInterval) { clearInterval(state.progressInterval); state.progressInterval = null; }
    if (statusMediaLoadingSafetyTimer) { clearTimeout(statusMediaLoadingSafetyTimer); statusMediaLoadingSafetyTimer = null; }
    statusMediaLoading = false;
    statusPaused = false;
    if (currentStatusVideoEl) {
      currentStatusVideoEl.pause();
      currentStatusVideoEl = null;
    }
    DOM.statusModalMedia.innerHTML = '';
    if (state.currentScreen && history.replaceState) {
      history.replaceState({ orbitScreen: state.currentScreen }, '', '#' + state.currentScreen);
    }
  }

  // ============================================================
  // 11. VIDEO / PLUGNMEET
  // ============================================================
  async function getLiveJoinUrl() {
    const { data, error } = await supabase.functions.invoke(CONFIG.PLUGNMEET.EDGE_FUNCTION, {
      body: {
        schedule_id: state.currentSchedule ? state.currentSchedule.id : null,
        channel_id: state.currentChannel ? state.currentChannel.id : null,
      },
    });
    if (error || !data?.join_url) {
      const serverMessage = data?.error || error?.message || 'Unknown error';
      throw new Error(serverMessage);
    }
    return data.join_url;
  }

  let liveSessionAutoCloseTimer = null;

  function clearLiveSessionAutoCloseTimer() {
    if (liveSessionAutoCloseTimer) {
      clearTimeout(liveSessionAutoCloseTimer);
      liveSessionAutoCloseTimer = null;
    }
  }

  // FIX: root cause of "user can't see the buttons for minimizing/
  // maximizing in live meeting so they can text in group when needed" —
  // this is the piece that never existed. Minimizing only ever meant
  // closeLiveSession() below, which sets videoIframe.src = '' and tears
  // the call down completely — there was no way to shrink #videoContainer
  // out of the way while keeping the meeting connected. This toggles the
  // .video-panel-minimized class (styles.css positions/resizes the panel
  // into a small corner pip instead of covering the whole screen) without
  // touching videoIframe.src or state.videoActive at all, so the call
  // keeps running in the background and #chatContainer/.composer
  // underneath become reachable again. Wired to #minimizeVideoBtn below.
  function setVideoMinimized(minimized) {
    state.videoMinimized = !!minimized;
    DOM.videoContainer.classList.toggle('video-panel-minimized', state.videoMinimized);
    if (DOM.minimizeVideoBtn) {
      DOM.minimizeVideoBtn.innerHTML = state.videoMinimized
        ? '<i class="fas fa-expand"></i>'
        : '<i class="fas fa-compress"></i>';
      DOM.minimizeVideoBtn.title = state.videoMinimized
        ? 'Expand call'
        : 'Minimize call (keep chatting)';
    }
    if (!state.videoMinimized) {
      // FIX: going back to full screen (or the call just isn't minimized
      // yet) — drop any inline left/top/width/height a previous drag or
      // resize left behind (see applyPipRect() below). Those are set via
      // .style, which beats every stylesheet rule including the base
      // .video-panel's `inset: 0`, so without this the panel would stay
      // wherever it was last dragged/sized instead of actually filling
      // the screen again. Re-minimizing after this always starts back at
      // the default corner spot/size from .video-panel-minimized in
      // styles.css, not wherever it was left.
      clearPipInlineRect();
      cancelPipGesture();
    }
  }

  // ============================================================
  // 11a. VIDEO PIP DRAG + RESIZE (minimized call window)
  // ============================================================
  // FIX: root cause of "why is the minimized meeting not movable and
  // resizable" — minimizing (setVideoMinimized() above) only ever gave
  // the pip ONE fixed spot and ONE fixed size, driven entirely by the
  // .video-panel-minimized CSS rule (top:78px/right:14px, 176x136) —
  // nothing here ever listened for a pointer gesture on it. The pip is
  // still positioned/sized by that CSS rule by default; dragging or
  // resizing just layers inline left/top/width/height on top of it
  // (cleared again in setVideoMinimized() above whenever the call leaves
  // the minimized state), clamped to stay inside this chat screen and
  // above a sane minimum size so the toolbar buttons stay tappable.
  const PIP_MIN_WIDTH = 140;
  const PIP_MIN_HEIGHT = 110;
  const PIP_EDGE_MARGIN = 8;

  // FIX: root cause of "why can't I see the meeting in full screen on
  // laptop" made #videoContainer `position: fixed` instead of `absolute`
  // (see the matching comment on .video-panel in styles.css), so its
  // `left`/`top` are now relative to the actual browser viewport, not to
  // #screenChatDetail. clampPipRect()/pipContainerOffset() below used to
  // work in "offset from the chat panel's top-left" coordinates, which
  // would place the pip in the wrong spot entirely under `fixed`
  // positioning (that offset would be reused as a viewport coordinate).
  // Both now work directly in viewport-absolute coordinates —
  // getBoundingClientRect() already returns those — while still using
  // #screenChatDetail's rect as the box the pip is kept within, so it
  // stays confined to the chat pane (not free to drift over the sidebar
  // or chat list) even though the panel itself now escapes that pane
  // for true full-screen mode.
  function clampPipRect(left, top, width, height) {
    const bounds = DOM.screenChatDetail
      ? DOM.screenChatDetail.getBoundingClientRect()
      : { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
    const maxWidth = Math.max(PIP_MIN_WIDTH, bounds.width - PIP_EDGE_MARGIN * 2);
    const maxHeight = Math.max(PIP_MIN_HEIGHT, bounds.height - PIP_EDGE_MARGIN * 2);
    width = Math.max(PIP_MIN_WIDTH, Math.min(width, maxWidth));
    height = Math.max(PIP_MIN_HEIGHT, Math.min(height, maxHeight));
    const minLeft = bounds.left + PIP_EDGE_MARGIN;
    const maxLeft = bounds.left + bounds.width - width - PIP_EDGE_MARGIN;
    const minTop = bounds.top + PIP_EDGE_MARGIN;
    const maxTop = bounds.top + bounds.height - height - PIP_EDGE_MARGIN;
    left = Math.max(minLeft, Math.min(left, maxLeft));
    top = Math.max(minTop, Math.min(top, maxTop));
    return { left, top, width, height };
  }

  function applyPipRect(rect) {
    DOM.videoContainer.style.left = rect.left + 'px';
    DOM.videoContainer.style.top = rect.top + 'px';
    DOM.videoContainer.style.right = 'auto';
    DOM.videoContainer.style.bottom = 'auto';
    DOM.videoContainer.style.width = rect.width + 'px';
    DOM.videoContainer.style.height = rect.height + 'px';
  }

  function clearPipInlineRect() {
    ['left', 'top', 'right', 'bottom', 'width', 'height'].forEach((prop) => {
      DOM.videoContainer.style[prop] = '';
    });
  }

  function pipContainerOffset() {
    // Viewport-absolute, to match #videoContainer's `position: fixed` —
    // see the FIX comment on clampPipRect() above.
    const rect = DOM.videoContainer.getBoundingClientRect();
    return { left: rect.left, top: rect.top, width: rect.width, height: rect.height };
  }

  let pipDrag = null;
  let pipResize = null;

  function cancelPipGesture() {
    DOM.videoContainer.classList.remove('video-panel-no-anim');
    pipDrag = null;
    pipResize = null;
  }

  function beginPipDrag(e) {
    if (!state.videoMinimized || pipResize) return;
    if (e.target.closest('button')) return; // let minimize/end/close buttons take their own tap
    const offset = pipContainerOffset();
    pipDrag = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      startLeft: offset.left,
      startTop: offset.top,
    };
    DOM.videoContainer.classList.add('video-panel-no-anim');
    try { DOM.videoToolbar.setPointerCapture(e.pointerId); } catch (err) { /* unsupported — drag still works via move/up on this element */ }
    e.preventDefault();
  }

  function onPipDragMove(e) {
    if (!pipDrag || e.pointerId !== pipDrag.pointerId) return;
    const dx = e.clientX - pipDrag.startX;
    const dy = e.clientY - pipDrag.startY;
    const current = pipContainerOffset();
    const rect = clampPipRect(pipDrag.startLeft + dx, pipDrag.startTop + dy, current.width, current.height);
    applyPipRect(rect);
  }

  function endPipDrag(e) {
    if (!pipDrag || e.pointerId !== pipDrag.pointerId) return;
    try { DOM.videoToolbar.releasePointerCapture(e.pointerId); } catch (err) { /* already released */ }
    pipDrag = null;
    if (!pipResize) DOM.videoContainer.classList.remove('video-panel-no-anim');
  }

  function beginPipResize(e) {
    if (!state.videoMinimized || pipDrag) return;
    const offset = pipContainerOffset();
    pipResize = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      startWidth: offset.width,
      startHeight: offset.height,
      left: offset.left,
      top: offset.top,
    };
    DOM.videoContainer.classList.add('video-panel-no-anim');
    try { DOM.videoResizeHandle.setPointerCapture(e.pointerId); } catch (err) { /* unsupported — resize still works via move/up on this element */ }
    e.preventDefault();
    e.stopPropagation();
  }

  function onPipResizeMove(e) {
    if (!pipResize || e.pointerId !== pipResize.pointerId) return;
    const dx = e.clientX - pipResize.startX;
    const dy = e.clientY - pipResize.startY;
    const rect = clampPipRect(pipResize.left, pipResize.top, pipResize.startWidth + dx, pipResize.startHeight + dy);
    applyPipRect(rect);
  }

  function endPipResize(e) {
    if (!pipResize || e.pointerId !== pipResize.pointerId) return;
    try { DOM.videoResizeHandle.releasePointerCapture(e.pointerId); } catch (err) { /* already released */ }
    pipResize = null;
    if (!pipDrag) DOM.videoContainer.classList.remove('video-panel-no-anim');
  }

  function closeLiveSession(message) {
    const wasActive = state.videoActive;
    // Needed for the attendance report's "staying duration" — see the
    // write-back at the end of this function.
    const attendanceRowId = state.activeAttendanceRowId;
    const attendanceJoinedAt = state.activeAttendanceJoinedAt;
    const attendanceScheduleDurationMinutes = state.activeAttendanceScheduleDurationMinutes;
    clearLiveSessionAutoCloseTimer();
    DOM.videoContainer.classList.add('hidden');
    DOM.videoIframe.src = '';
    state.videoActive = false;
    state.activeCallScheduleId = null;
    state.activeCallIsHost = false;
    state.activeAttendanceRowId = null;
    state.activeAttendanceJoinedAt = null;
    state.activeAttendanceScheduleDurationMinutes = null;
    setVideoMinimized(false);

    // Attendance duration write-back — see joinLiveClass() where
    // state.activeAttendanceRowId/activeAttendanceJoinedAt are set at
    // join time. Capped at the session's own scheduled duration so a
    // stray reconnect loop (several join/close cycles inside one
    // session) can't inflate a single session's staying time past
    // 100% of its own length — see computeAttendanceReport() for how
    // this feeds into the report.
    if (attendanceRowId) {
      const elapsedMinutes = attendanceJoinedAt ? Math.max(0, Math.round((Date.now() - attendanceJoinedAt) / 60000)) : null;
      const cappedMinutes = elapsedMinutes == null
        ? null
        : (attendanceScheduleDurationMinutes ? Math.min(elapsedMinutes, attendanceScheduleDurationMinutes) : elapsedMinutes);
      supabase
        .from(CONFIG.SUPABASE.TABLES.ATTENDANCE)
        .update({ leave_time: new Date().toISOString(), duration_minutes: cappedMinutes })
        .eq('id', attendanceRowId)
        .then(({ error }) => {
          if (error) console.warn('Could not record attendance duration:', error);
        });
    }

    // FIX: root cause of "instead of disappearing the ended meetings it
    // disappeared live meetings as well" (twice over) — this function
    // used to try to infer, from HOW it was called, whether the
    // meeting had genuinely ended and silently flip is_live:false in
    // the DB when it guessed yes. Every signal available for that
    // guess turned out ambiguous: PlugNmeet's own "session ended"
    // redirect (handleVideoIframeLoad) fires a few seconds after ANY
    // disconnect — including a host just stepping out via PlugNmeet's
    // own leave button meaning to rejoin — not only a genuine, final
    // end (see the long comment on PLUGNMEET_SESSION_ENDED_MARKER
    // below); and the scheduled-time-elapsed auto-close timer doesn't
    // need a DB write at all, since isScheduleRowRelevant() already
    // stops treating a row as live the moment its own time window
    // passes, DB flag or not. Every attempt to auto-detect "really
    // ended" from a disconnect ended up misfiring on a still-live
    // class. So this function no longer touches class_schedule at
    // all — it purely tears down the LOCAL call view, for whoever
    // triggered it, exactly as it did before any of this. The actual,
    // reliable fix for "a finished class keeps showing as live until
    // its full scheduled window elapses" is the endLiveSessionBtn
    // change in joinLiveClass() below: the host now gets an explicit,
    // deliberate "End for Everyone" control (previously admin-only)
    // to mark their own class over the moment they're actually done —
    // a real user decision instead of a guess from ambiguous signals.
    if (DOM.endLiveSessionBtn) DOM.endLiveSessionBtn.classList.add('hidden');
    if (DOM.returnToChatBtn) DOM.returnToChatBtn.classList.add('hidden');
    // FIX: root cause of "when the meeting is ended by teacher or admin it
    // should show the group chat screen instead of meeting ended screen"
    // (the other half of it) — hiding #videoContainer above already
    // reveals the group chat screen underneath immediately, but this used
    // to follow it with `alert(message)` — a native, page-blocking modal
    // that has to be dismissed before the now-visible chat screen can be
    // touched at all. That's what actually read as a "meeting ended
    // screen": not the chat failing to appear, but a dialog sitting in
    // front of it. showToast() (used elsewhere for the same kind of
    // transient notice — see jumpToMessage()) shows the same message as a
    // small, non-blocking banner that fades on its own, so landing back
    // on the chat is immediate and the notice doesn't gate it.
    if (message && wasActive) showToast(message);
  }

  // ============================================================
  // 11b. PLUGNMEET SESSION-ENDED DETECTION
  // ============================================================
  // FIX: root cause of "by pressing the plugnmeet red button [...] when it
  // shows the meeting has ended it should return into group instead of
  // being sticky on the meeting ended screen" — leaving now happens
  // through PlugNmeet's OWN leave/end control, inside its iframe (see the
  // removal of #closeVideoBtn above). That's a cross-origin page we have
  // no DOM access to at all, so the app previously had no way to know
  // that happened — #videoContainer just stayed open, full-screen, over
  // whatever PlugNmeet renders once you disconnect (its own "the session
  // has ended" placeholder), with nothing to bring the chat back.
  //
  // PlugNmeet's own client does navigate itself away after a disconnect —
  // confirmed by reading its source (mynaparrot/plugNmeet-client,
  // ConnectNats.ts): a few seconds after ANY disconnect (room ended, kicked,
  // or the participant just clicking PlugNmeet's own leave button), it runs
  // `window.location.href = meta.logoutUrl` — but only if a `logout_url`
  // was set in the room's metadata when the room was created. That happens
  // in the `plugnmeet-token` Supabase Edge Function (per the comment in
  // config.js), which isn't one of the files this app ships client-side,
  // so it has to be set there, not here. Add `logout_url` alongside the
  // existing `room_features`/ROOM_SETTINGS metadata sent to PlugNmeet's
  // Create Room API, pointing at a URL on THIS app's own origin containing
  // the PLUGNMEET_SESSION_ENDED_MARKER below — e.g.
  // `${window.location.origin}${window.location.pathname}?liveSessionEnded=1`.
  // (Docs: https://www.plugnmeet.org/docs/api/room/create — `metadata.logout_url`,
  // "URL to redirect users after the meeting or session ends.")
  //
  // Once that's set server-side, this is what actually detects it
  // happened: #videoIframe navigating itself to `logout_url` is a real
  // top-level navigation of the iframe's own window, which fires a normal
  // `load` event we CAN see from the parent page — we just can't read
  // WHERE it navigated to while it's still on PlugNmeet's own origin
  // (meet.nouscomplex.com), since reading a cross-origin iframe's
  // location throws. The moment it redirects to our OWN origin, that read
  // stops throwing — which is itself the signal: any successful read means
  // PlugNmeet just sent us home, so close the overlay and let the group
  // chat underneath show through, same as any other end-of-call path.
  //
  // FIX: root cause of "screen is still at [PlugNmeet's own 'Disconnected /
  // The meeting has ended'] page when the meeting is ended by any teacher
  // or admin" — even with logout_url configured correctly, this can still
  // happen, and it's not a bug in this app. Confirmed by reading PlugNmeet's
  // client source further: it actually has TWO separate disconnect
  // handlers. A graceful one (NATS "SESSION_ENDED" broadcast — e.g.
  // someone pressing PlugNmeet's own leave/end control) runs
  // ConnectNats.ts's endSession(), which shows the "Disconnected" screen
  // AND schedules the logout_url redirect 3s later. But a raw one (the
  // underlying LiveKit connection just dropping — reason ROOM_DELETED,
  // SERVER_SHUTDOWN, STATE_MISMATCH, etc. — see ConnectLivekit.ts's
  // onDisconnected) shows the exact same "Disconnected" screen text but has
  // NO redirect logic at all — that code path never reads logout_url,
  // so nothing sends the iframe anywhere and it just sits there. Which of
  // the two happens depends on things outside this app (how the session
  // actually ends server-side, network conditions, the PlugNmeet server's
  // own version), so this app can't guarantee logout_url always fires —
  // #returnToChatBtn (see its comment in index.html) is the guaranteed
  // fallback for exactly that gap.
  const PLUGNMEET_SESSION_ENDED_MARKER = 'liveSessionEnded';

  function handleVideoIframeLoad() {
    if (!state.videoActive) return; // already closed on our side — e.g. the src='' from closeLiveSession() itself firing 'load'
    let href;
    try {
      href = DOM.videoIframe.contentWindow && DOM.videoIframe.contentWindow.location.href;
    } catch (e) {
      return; // still cross-origin on the PlugNmeet room itself — normal, call is still going
    }
    if (href && href.includes(PLUGNMEET_SESSION_ENDED_MARKER)) {
      closeLiveSession('This live session has ended.');
    }
  }

  async function endLiveSessionForEveryone() {
    if (!state.activeCallScheduleId) { closeLiveSession(); return; }
    if (!confirm('End this live session now for everyone in the group?')) return;

    const startedAt = state.currentSchedule && String(state.currentSchedule.id) === String(state.activeCallScheduleId)
      ? new Date(state.currentSchedule.scheduled_time).getTime()
      : Date.now();
    const elapsedMinutes = Math.max(1, Math.ceil((Date.now() - startedAt) / 60000));

    const { error } = await supabase
      .from('class_schedule')
      .update({ duration_minutes: elapsedMinutes, is_live: false })
      .eq('id', state.activeCallScheduleId);

    if (error) { alert('Could not end the session: ' + error.message); return; }
    closeLiveSession('You ended this live session for everyone.');
  }

  async function joinLiveClass() {
    if (!state.currentUser || !state.currentChannel) { alert('Please select a channel first.'); return; }

    const mode = getLiveButtonMode();
    if (mode === 'hidden') { return; }

    if (mode === 'start' && state.currentSchedule && !state.currentSchedule.is_live) {
      const { error: liveError } = await supabase
        .from('class_schedule')
        .update({ is_live: true })
        .eq('id', state.currentSchedule.id);
      if (liveError) {
        console.warn('Could not mark session live:', liveError);
      } else {
        state.currentSchedule.is_live = true;
      }
    }

    if (CONFIG.FEATURES.ENABLE_ATTENDANCE_LOGGING) {
      try {
        // FIX: needed for the attendance report (computeAttendanceReport())
        // to tie an attendance row to a SPECIFIC scheduled session
        // (schedule_id) instead of just a channel — without it there's no
        // way to tell "attended session A" from "attended session B" in
        // the same group, only "joined this channel at some point". The
        // .select().single() gets the new row's id back so
        // closeLiveSession() can later fill in leave_time/duration_minutes
        // on this exact row once we know how long the call lasted.
        const { data: attendanceRow, error: attendanceError } = await supabase
          .from(CONFIG.SUPABASE.TABLES.ATTENDANCE)
          .insert({
            student_name: state.currentUser.username,
            channel_id: state.currentChannel.id,
            schedule_id: state.currentSchedule ? state.currentSchedule.id : null,
            join_time: new Date().toISOString(),
            status: 'Present',
          })
          .select()
          .single();
        if (attendanceError) {
          console.warn('Attendance log skipped:', attendanceError);
        } else if (attendanceRow) {
          state.activeAttendanceRowId = attendanceRow.id;
          state.activeAttendanceJoinedAt = Date.now();
          state.activeAttendanceScheduleDurationMinutes = state.currentSchedule ? (state.currentSchedule.duration_minutes || 45) : null;
        }
      } catch (e) {
        console.warn('Attendance log skipped:', e);
      }
    }

    // FIX: root cause of "browser asks for camera/mic permission when no
    // meeting is open" — requestMediaPermissions() used to run once at
    // login (completeLogin()), for every user on every sign-in/session
    // restore, regardless of whether they ever opened a live session.
    // Requesting it here instead means the browser's permission prompt
    // (and the friendly "permissions blocked" modal on denial) only ever
    // appears at the moment someone actually clicks Start/Join Live
    // Session, matching what a user would expect.
    await requestMediaPermissions();

    let liveUrl;
    DOM.joinLiveBtn.disabled = true;
    try {
      liveUrl = await getLiveJoinUrl();
    } catch (e) {
      console.error('Could not get PlugNmeet join URL:', e);
      alert('Could not start the video call: ' + e.message);
      updateLiveButtonState();
      return;
    }

    DOM.videoContainer.classList.remove('hidden');
    setVideoMinimized(false);
    // FIX: tag the join URL with nc_role=admin for admins so the header
    // controls injected into PlugNmeet's own UI (see
    // NOUS_COMPLEX_PLUGNMEET_HEADER_BRIDGE above and
    // NOUS_COMPLEX_HEADER_CONTROLS in PlugNmeet's client/dist/index.html on
    // the Oracle server) know whether to draw the admin-only "End for
    // Everyone" button. Wrapped in try/catch since liveUrl is server-
    // provided — if it's ever not a valid absolute URL, fall back to
    // joining unmodified rather than breaking the call.
    try {
      const u = new URL(liveUrl);
      if (state.isAdmin) u.searchParams.set('nc_role', 'admin');
      liveUrl = u.toString();
    } catch (e) {
      console.warn('Could not append nc_role to join URL:', e);
    }
    DOM.videoIframe.src = liveUrl;
    state.videoActive = true;
    state.activeCallScheduleId = state.currentSchedule ? state.currentSchedule.id : null;
    // Needed so closeLiveSession() and the endLiveSessionBtn visibility
    // check just below can tell whether the person whose call this is
    // the one who STARTED it (the scheduled teacher, or an admin
    // starting a fresh session) versus someone who merely joined an
    // already-live session. mode is only 'start' for the former (see
    // getLiveButtonMode()).
    state.activeCallIsHost = (mode === 'start');
    updateLiveButtonState();
    if (DOM.endLiveSessionBtn) {
      // FIX: root cause of "a finished class keeps showing as live in
      // both schedule lists until its full scheduled window elapses"
      // — this button (the only reliable, DELIBERATE way to mark a
      // session over early — see closeLiveSession()'s comment on why
      // trying to auto-detect this from disconnect signals kept
      // misfiring on still-live classes) used to be admin-only "by
      // design", so a teacher who started and then finished their own
      // class had no way to end it early at all — it could only ever
      // show as live for its entire originally-scheduled duration.
      // Now the HOST of this specific call — the scheduled teacher who
      // started it, same as an admin who started it — gets it too, so
      // whoever is actually running the class can mark it done the
      // moment it really is.
      DOM.endLiveSessionBtn.classList.toggle('hidden', !(state.activeCallIsHost && state.activeCallScheduleId));
    }
    // FIX: root cause of getting stuck on PlugNmeet's own "meeting has
    // ended" screen — unlike #endLiveSessionBtn, this isn't admin-only or
    // tied to a schedule: anyone in a call can end up looking at that
    // screen, so everyone gets the recovery button. See its comment in
    // index.html and the click handler below.
    if (DOM.returnToChatBtn) DOM.returnToChatBtn.classList.remove('hidden');

    clearLiveSessionAutoCloseTimer();
    if (state.currentSchedule) {
      const endsAt = new Date(state.currentSchedule.scheduled_time).getTime() + (state.currentSchedule.duration_minutes || 45) * 60000;
      const msRemaining = endsAt - Date.now();
      if (msRemaining <= 0) {
        closeLiveSession('⏰ This session\'s scheduled time is already up.');
      } else {
        liveSessionAutoCloseTimer = setTimeout(() => {
          closeLiveSession('⏰ This session\'s scheduled time is up — the call has been closed.');
        }, msRemaining);
      }
    }
  }

  // ============================================================
  // 12. ADMIN FUNCTIONS
  // ============================================================

  async function exportAttendance() {
    const { data, error } = await supabase.from(CONFIG.SUPABASE.TABLES.ATTENDANCE).select('*');
    if (error) { alert('No attendance data found.'); return; }

    let csv = 'Student,Channel,Join Time,Status\n';
    data.forEach(r => csv += `${r.student_name},${r.channel_id},${r.join_time},${r.status}\n`);

    const blob = new Blob([csv], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'attendance_log.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // ============================================================
  // 12b. ATTENDANCE REPORT
  // "Fetch auto attendance of students in group... with from-date to
  // to-date individual and group wise summary and detailed report
  // with pdf download option. Start calculation of days and
  // attendance from joining date."
  //
  // Requires two columns that don't exist on the original schema —
  // this app has no direct database access of its own, so these need
  // to be added once, by hand, in the Supabase SQL editor:
  //
  //   alter table attendance
  //     add column if not exists schedule_id bigint references class_schedule(id) on delete set null,
  //     add column if not exists leave_time timestamptz,
  //     add column if not exists duration_minutes integer;
  //   alter table members
  //     add column if not exists created_at timestamptz not null default now();
  //
  // Without schedule_id there's no way to tell WHICH scheduled session
  // an attendance row belongs to (only which channel); without
  // duration_minutes there's no "staying duration" to report at all;
  // without members.created_at there's no join date to start counting
  // from. See joinLiveClass()/closeLiveSession() above for where
  // schedule_id/duration_minutes get written now that the columns
  // exist. If members.created_at already existed with real historical
  // join dates, this migration is a no-op for it; if it didn't,
  // existing members backfill to "now" (their true join date isn't
  // recoverable after the fact) — only going forward is this accurate
  // for members added before running the migration.
  // ============================================================

  let lastAttendanceReport = null;

  // dayKey() (above) isn't zero-padded ("2026-9-5"), which
  // <input type="date"> silently rejects — it requires strict
  // "YYYY-MM-DD". This is that format, used for both setting the date
  // inputs' default values and building the PDF filename below.
  function toDateInputValue(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  function populateAttendanceGroupSelect() {
    if (!DOM.attendanceGroupSelect) return;
    const previousValue = DOM.attendanceGroupSelect.value;
    const options = ['<option value="">Select a group…</option>']
      .concat(allChannels.map((ch) => `<option value="${escapeHtml(String(ch.id))}">${escapeHtml(ch.name)}</option>`));
    DOM.attendanceGroupSelect.innerHTML = options.join('');
    if (previousValue && allChannels.some((ch) => String(ch.id) === previousValue)) {
      DOM.attendanceGroupSelect.value = previousValue;
    }
  }

  async function populateAttendanceStudentSelect(channelId) {
    if (!DOM.attendanceStudentSelect) return;
    if (!channelId) {
      DOM.attendanceStudentSelect.innerHTML = '<option value="">Select a group first…</option>';
      return;
    }
    DOM.attendanceStudentSelect.innerHTML = '<option value="">Loading students…</option>';
    const { data, error } = await supabase
      .from(CONFIG.SUPABASE.TABLES.MEMBERS)
      .select('username')
      .eq('channel_id', channelId)
      .eq('role', 'student')
      .order('username');
    if (error) {
      DOM.attendanceStudentSelect.innerHTML = '<option value="">Could not load students</option>';
      return;
    }
    if (!data || !data.length) {
      DOM.attendanceStudentSelect.innerHTML = '<option value="">No students in this group</option>';
      return;
    }
    DOM.attendanceStudentSelect.innerHTML = data
      .map((m) => `<option value="${escapeHtml(m.username)}">${escapeHtml(getDisplayName(m.username))}</option>`)
      .join('');
  }

  function initAttendanceReportScreen() {
    populateAttendanceGroupSelect();
    if (DOM.attendanceReportTypeSelect) DOM.attendanceReportTypeSelect.value = 'group';
    if (DOM.attendanceStudentFieldWrap) DOM.attendanceStudentFieldWrap.classList.add('hidden');
    // Default range: the current calendar month to date — matches the
    // "Fetch Month Days from current calendar month" example.
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    if (DOM.attendanceFromDateInput && !DOM.attendanceFromDateInput.value) {
      DOM.attendanceFromDateInput.value = toDateInputValue(monthStart);
    }
    if (DOM.attendanceToDateInput && !DOM.attendanceToDateInput.value) {
      DOM.attendanceToDateInput.value = toDateInputValue(now);
    }
    if (DOM.attendanceReportResults) DOM.attendanceReportResults.classList.add('hidden');
    if (DOM.attendanceReportEmpty) DOM.attendanceReportEmpty.classList.remove('hidden');
    lastAttendanceReport = null;
  }

  function formatMinutesLabel(minutes) {
    const m = Math.round(minutes || 0);
    return `${m} min (${(m / 60).toFixed(1)}h)`;
  }

  function formatPct(pct) {
    return pct == null ? '—' : `${pct.toFixed(1)}%`;
  }

  // Computes the report for either the whole group (studentUsername
  // omitted) or a single student. fromDate/toDate are Date objects at
  // local midnight for their respective days; toDate is treated as
  // inclusive of its whole day.
  async function computeAttendanceReport(channelId, studentUsername, fromDate, toDate) {
    const channel = allChannels.find((ch) => String(ch.id) === String(channelId));
    const toDateExclusive = new Date(toDate.getTime() + 24 * 60 * 60 * 1000);
    const calendarDaysInRange = Math.round((toDateExclusive.getTime() - fromDate.getTime()) / (24 * 60 * 60 * 1000));

    const { data: scheduleRows, error: scheduleError } = await supabase
      .from('class_schedule')
      .select('id, scheduled_time, duration_minutes')
      .eq('channel_id', channelId)
      .gte('scheduled_time', fromDate.toISOString())
      .lt('scheduled_time', toDateExclusive.toISOString())
      .order('scheduled_time', { ascending: true });
    if (scheduleError) throw scheduleError;

    let membersQuery = supabase
      .from(CONFIG.SUPABASE.TABLES.MEMBERS)
      .select('username, role, created_at')
      .eq('channel_id', channelId)
      .eq('role', 'student');
    if (studentUsername) membersQuery = membersQuery.eq('username', studentUsername);
    const { data: memberRows, error: memberError } = await membersQuery.order('username');
    if (memberError) throw memberError;

    let attendanceQuery = supabase
      .from(CONFIG.SUPABASE.TABLES.ATTENDANCE)
      .select('student_name, schedule_id, join_time, duration_minutes')
      .eq('channel_id', channelId)
      .gte('join_time', fromDate.toISOString())
      .lt('join_time', toDateExclusive.toISOString());
    if (studentUsername) attendanceQuery = attendanceQuery.eq('student_name', studentUsername);
    const { data: attendanceRows, error: attendanceError } = await attendanceQuery;
    if (attendanceError) throw attendanceError;

    // FIX: "when the session was scheduled by admin but the teacher
    // didn't start the session why it is calculating the student's
    // absent instead of showing missed session" — a class_schedule row
    // existing only means a session was PLANNED; nothing before this
    // point checked whether the teacher/admin ever actually started
    // it. A student obviously can't attend a class that never
    // happened, so counting every un-started session as an "absence"
    // was unfairly counting against them for something entirely
    // outside their control. This is a SEPARATE, unfiltered-by-student
    // query (attendanceRows above is filtered to just this student in
    // individual mode, which can't tell us this) — joinLiveClass()
    // writes an attendance row for WHOEVER joins, including the host
    // (teacher/admin) who starts it, so "does any attendance row at
    // all exist for this schedule_id" is a reliable signal that the
    // session actually went live, regardless of whether this
    // particular student showed up.
    const { data: anyAttendanceRows, error: anyAttendanceError } = await supabase
      .from(CONFIG.SUPABASE.TABLES.ATTENDANCE)
      .select('schedule_id')
      .eq('channel_id', channelId)
      .gte('join_time', fromDate.toISOString())
      .lt('join_time', toDateExclusive.toISOString())
      .not('schedule_id', 'is', null);
    if (anyAttendanceError) throw anyAttendanceError;
    const startedScheduleIds = new Set((anyAttendanceRows || []).map((r) => r.schedule_id));

    // attendanceByKey: "username|scheduleId" -> array of attendance rows
    // (usually one, but a student who reconnected mid-session leaves
    // more than one row for the same session).
    const attendanceByKey = new Map();
    (attendanceRows || []).forEach((row) => {
      if (row.schedule_id == null) return; // pre-migration row with no session link — can't be matched to a specific session
      const key = `${row.student_name}|${row.schedule_id}`;
      if (!attendanceByKey.has(key)) attendanceByKey.set(key, []);
      attendanceByKey.get(key).push(row);
    });

    const students = (memberRows || []).map((member) => {
      const joinedAt = member.created_at ? new Date(member.created_at) : null;
      const effectiveFrom = joinedAt && joinedAt.getTime() > fromDate.getTime() ? joinedAt : fromDate;
      const relevantSessions = (scheduleRows || []).filter((s) => new Date(s.scheduled_time).getTime() >= effectiveFrom.getTime());

      let attendedSessions = 0;
      let missedSessions = 0;
      let heldScheduledMinutes = 0;
      let attendedMinutes = 0;
      const sessions = relevantSessions.map((s) => {
        const durationMinutes = s.duration_minutes || 45;
        const wasHeld = startedScheduleIds.has(s.id);
        if (!wasHeld) {
          missedSessions++;
          return { date: s.scheduled_time, scheduledMinutes: durationMinutes, wasHeld: false, attended: false, minutesStayed: 0 };
        }
        heldScheduledMinutes += durationMinutes;
        const rows = attendanceByKey.get(`${member.username}|${s.id}`) || [];
        const attended = rows.length > 0;
        // Sum durations across any reconnects for this session, capped
        // at the session's own length (see closeLiveSession()'s own
        // per-row cap — this is a second, belt-and-suspenders cap
        // across MULTIPLE rows for the same session).
        // FIX: a row reaching this point already has schedule_id set
        // (rows without it — pre-migration data — are filtered out
        // above), so a null duration_minutes here can only mean THIS
        // particular join was never cleanly closed (dropped
        // connection, crashed tab, killed app — closeLiveSession()
        // never got to write leave_time/duration_minutes for it), not
        // old untracked data. Crediting that with the full scheduled
        // class length (the previous fallback) silently rewarded an
        // unknown/likely-brief connection with the maximum possible
        // credit — e.g. two 1-minute joins in a 5-minute class, one of
        // which dropped without closing, summed to 1 + 5 = 6 (capped
        // to 5, the whole class) instead of the ~1 actually recorded.
        // An unknown duration now counts as 0 additional minutes
        // instead — honest about what we don't know — while the
        // session still correctly counts as attended, since the row's
        // existence proves they joined at least once.
        const minutesStayed = attended
          ? Math.min(durationMinutes, rows.reduce((sum, r) => sum + (r.duration_minutes != null ? r.duration_minutes : 0), 0))
          : 0;
        if (attended) {
          attendedSessions++;
          attendedMinutes += minutesStayed;
        }
        return { date: s.scheduled_time, scheduledMinutes: durationMinutes, wasHeld: true, attended, minutesStayed };
      });

      const scheduledSessions = relevantSessions.length;
      const heldSessions = scheduledSessions - missedSessions;
      // Absent now only counts sessions that were ACTUALLY HELD but
      // this student didn't join — a session the teacher never started
      // is counted separately as "missed", not held against the
      // student as an absence, and is excluded from both the
      // attendance % and staying % denominators below.
      const absentSessions = heldSessions - attendedSessions;
      return {
        username: member.username,
        displayName: getDisplayName(member.username),
        joinedAt,
        clippedByJoinDate: !!(joinedAt && joinedAt.getTime() > fromDate.getTime()),
        scheduledSessions,
        missedSessions,
        heldSessions,
        attendedSessions,
        absentSessions,
        attendancePct: heldSessions ? (attendedSessions / heldSessions) * 100 : null,
        scheduledMinutes: heldScheduledMinutes,
        attendedMinutes,
        stayingPct: heldScheduledMinutes ? (attendedMinutes / heldScheduledMinutes) * 100 : null,
        sessions,
      };
    });

    const groupTotals = students.reduce((acc, s) => {
      acc.scheduledSessions += s.scheduledSessions;
      acc.missedSessions += s.missedSessions;
      acc.heldSessions += s.heldSessions;
      acc.attendedSessions += s.attendedSessions;
      acc.absentSessions += s.absentSessions;
      acc.scheduledMinutes += s.scheduledMinutes;
      acc.attendedMinutes += s.attendedMinutes;
      return acc;
    }, { scheduledSessions: 0, missedSessions: 0, heldSessions: 0, attendedSessions: 0, absentSessions: 0, scheduledMinutes: 0, attendedMinutes: 0 });
    groupTotals.attendancePct = groupTotals.heldSessions ? (groupTotals.attendedSessions / groupTotals.heldSessions) * 100 : null;
    groupTotals.stayingPct = groupTotals.scheduledMinutes ? (groupTotals.attendedMinutes / groupTotals.scheduledMinutes) * 100 : null;

    return {
      mode: studentUsername ? 'individual' : 'group',
      channelId,
      channelName: channel ? channel.name : 'Unknown group',
      fromDate,
      toDate,
      calendarDaysInRange,
      sessionsScheduledInRange: (scheduleRows || []).length,
      students,
      groupTotals,
    };
  }

  function attendanceStatCardHtml(label, value) {
    return `<div class="attendance-stat-card"><div class="attendance-stat-label">${escapeHtml(label)}</div><div class="attendance-stat-value">${escapeHtml(value)}</div></div>`;
  }

  function renderAttendanceReport(report) {
    lastAttendanceReport = report;
    if (!DOM.attendanceReportResults || !DOM.attendanceReportSummary || !DOM.attendanceReportTable) return;

    let summaryCards = [
      attendanceStatCardHtml('Calendar days in range', String(report.calendarDaysInRange)),
      attendanceStatCardHtml('Sessions scheduled in range', String(report.sessionsScheduledInRange)),
    ];

    let tableHtml;
    if (report.mode === 'individual') {
      const s = report.students[0];
      if (!s) {
        tableHtml = '<tbody><tr><td>This student is not a member of this group.</td></tr></tbody>';
      } else {
        summaryCards = summaryCards.concat([
          attendanceStatCardHtml('Scheduled sessions (since joining)', String(s.scheduledSessions)),
          attendanceStatCardHtml('Not held by teacher', String(s.missedSessions)),
          attendanceStatCardHtml('Attended', String(s.attendedSessions)),
          attendanceStatCardHtml('Absent', String(s.absentSessions)),
          attendanceStatCardHtml('Attendance %', formatPct(s.attendancePct)),
          attendanceStatCardHtml('Total scheduled duration', formatMinutesLabel(s.scheduledMinutes)),
          attendanceStatCardHtml('Total stayed', formatMinutesLabel(s.attendedMinutes)),
          attendanceStatCardHtml('Staying %', formatPct(s.stayingPct)),
        ]);
        tableHtml = `
          <thead><tr><th>Date</th><th>Scheduled</th><th>Status</th><th>Stayed</th></tr></thead>
          <tbody>
            ${s.sessions.map((sess) => `
              <tr>
                <td>${escapeHtml(new Date(sess.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }))}</td>
                <td>${sess.scheduledMinutes} min</td>
                <td>${!sess.wasHeld
                  ? '<span style="color:var(--ink-faint);font-weight:700;">Not held by teacher</span>'
                  : (sess.attended ? '<span style="color:var(--success);font-weight:700;">Present</span>' : '<span style="color:var(--danger);font-weight:700;">Absent</span>')}</td>
                <td>${sess.attended ? `${sess.minutesStayed} min` : '—'}</td>
              </tr>
            `).join('') || '<tr><td colspan="4">No sessions scheduled in this range since this student joined.</td></tr>'}
          </tbody>
        `;
      }
    } else {
      const t = report.groupTotals;
      summaryCards = summaryCards.concat([
        attendanceStatCardHtml('Students', String(report.students.length)),
        attendanceStatCardHtml('Sessions not held by teacher', String(t.missedSessions)),
        attendanceStatCardHtml('Group attendance %', formatPct(t.attendancePct)),
        attendanceStatCardHtml('Group staying %', formatPct(t.stayingPct)),
      ]);
      tableHtml = `
        <thead><tr><th>Student</th><th>Scheduled</th><th>Not held</th><th>Attended</th><th>Absent</th><th>Attendance %</th><th>Scheduled</th><th>Stayed</th><th>Staying %</th></tr></thead>
        <tbody>
          ${report.students.map((s) => `
            <tr>
              <td>${escapeHtml(s.displayName)}${s.clippedByJoinDate ? ' <span title="Counted from their join date, not the start of the range" style="color:var(--ink-faint);">*</span>' : ''}</td>
              <td>${s.scheduledSessions}</td>
              <td>${s.missedSessions}</td>
              <td>${s.attendedSessions}</td>
              <td>${s.absentSessions}</td>
              <td>${formatPct(s.attendancePct)}</td>
              <td>${formatMinutesLabel(s.scheduledMinutes)}</td>
              <td>${formatMinutesLabel(s.attendedMinutes)}</td>
              <td>${formatPct(s.stayingPct)}</td>
            </tr>
          `).join('') || '<tr><td colspan="9">No students in this group.</td></tr>'}
        </tbody>
      `;
    }

    DOM.attendanceReportSummary.innerHTML = summaryCards.join('');
    DOM.attendanceReportTable.innerHTML = tableHtml;
    if (DOM.attendanceReportEmpty) DOM.attendanceReportEmpty.classList.add('hidden');
    DOM.attendanceReportResults.classList.remove('hidden');
  }

  // ---------------------------------------------------------------------
  // PDF palette — mirrors the in-app Attendance Report screen exactly
  // (see .attendance-stat-card / .attendance-report-table in styles.css)
  // so the downloaded PDF looks like a continuation of that screen
  // rather than a differently-styled document: a plain white page,
  // a single navy brand accent used sparingly (logo + a thin rule),
  // and status/values picked out with the same ink/gray/green/red
  // tones the on-screen table already uses. No heavy color fills —
  // the goal is "professional, simple, delicate", not a slide deck.
  const PDF_INK = [20, 22, 43];        // --ink
  const PDF_INK_SOFT = [110, 115, 133]; // --ink-soft
  const PDF_INK_FAINT = [162, 166, 184]; // --ink-faint
  const PDF_BORDER = [235, 235, 237];   // --border
  const PDF_SUNKEN = [237, 237, 237];   // --surface-sunken
  const PDF_ACCENT = [14, 27, 117];     // --accent
  const PDF_SUCCESS = [34, 197, 94];    // --success
  const PDF_DANGER = [226, 76, 67];     // --danger

  function drawStatCards(doc, pageWidth, startY, cards) {
    const margin = 14;
    const gap = 4;
    // Cards used to hard-cap at 6 per row. Individual reports now carry
    // up to 10 cards (see generateAttendancePdf), so instead of letting
    // a 10-card set squeeze into one cramped row, split anything past 6
    // cards into two even rows — e.g. 10 cards -> 5 + 5 — same spirit
    // as the on-screen grid, which wraps automatically.
    const rows = cards.length > 6 ? 2 : 1;
    const cols = Math.ceil(cards.length / rows) || 1;
    const cardWidth = (pageWidth - margin * 2 - gap * (cols - 1)) / cols;
    const cardHeight = 24;
    // More columns per row = less width per card, so labels/values
    // shrink a touch to keep everything on one line and inside the
    // card's border rather than overflowing it.
    const labelFontSize = cols >= 6 ? 5.8 : cols === 5 ? 6.1 : 6.4;
    const baseValueFontSize = cols >= 6 ? 12 : cols === 5 ? 12.8 : 13.5;

    // Shrinks fontSize (down to a floor) until `text` fits in maxWidth,
    // so long values like "16 min (0.3h)" never spill past the card's
    // right edge even in a narrow 5–6-column row.
    function fitValueFontSize(text, maxWidth, startSize) {
      let size = startSize;
      doc.setFont('helvetica', 'bold');
      while (size > 8.5) {
        doc.setFontSize(size);
        if (doc.getTextWidth(String(text)) <= maxWidth) break;
        size -= 0.5;
      }
      return size;
    }

    let x = margin;
    let y = startY;
    cards.forEach((card, i) => {
      if (i > 0 && i % cols === 0) { x = margin; y += cardHeight + gap; }
      // Every card shares the same quiet white/bordered treatment as
      // .attendance-stat-card — no separate "accent" fill for the
      // percentage cards, so the whole row reads as one calm set.
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(...PDF_BORDER);
      doc.setLineWidth(0.3);
      doc.roundedRect(x, y, cardWidth, cardHeight, 2.5, 2.5, 'FD');

      // Label — bold, uppercase, gray, wraps onto a second line if the
      // card is narrow (e.g. "Scheduled sessions (since joining)").
      doc.setTextColor(...PDF_INK_FAINT);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(labelFontSize);
      if (doc.setCharSpace) doc.setCharSpace(0.2);
      doc.text(card.label.toUpperCase(), x + 4, y + 6, { maxWidth: cardWidth - 8 });
      if (doc.setCharSpace) doc.setCharSpace(0);

      // Value — bold, dark, anchored near the card's bottom edge so it
      // never collides with a label that wrapped to two lines above it.
      const valueSize = fitValueFontSize(card.value, cardWidth - 8, baseValueFontSize);
      doc.setTextColor(...PDF_INK);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(valueSize);
      doc.text(String(card.value), x + 4, y + cardHeight - 5);
      x += cardWidth + gap;
    });
    return startY + rows * cardHeight + (rows - 1) * gap + 10;
  }

  // Draws one line of "Label: value    Label: value ..." pairs with the
  // label bold/dark and the value normal-weight — the same emphasis
  // pattern as the app's own labelled fields — instead of one flat run
  // of gray text, so "Date Range", "Class", "Student" etc. stand out.
  function drawMetaRow(doc, x, y, fontSize, pairs) {
    let cursorX = x;
    pairs.forEach((pair, i) => {
      doc.setFontSize(fontSize);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...PDF_INK);
      const labelText = `${pair.label}: `;
      doc.text(labelText, cursorX, y);
      cursorX += doc.getTextWidth(labelText);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(...PDF_INK_SOFT);
      const valueText = String(pair.value) + (i < pairs.length - 1 ? '     ' : '');
      doc.text(valueText, cursorX, y);
      cursorX += doc.getTextWidth(valueText);
    });
  }

  function generateAttendancePdf(report) {
    if (!window.jspdf || !window.jspdf.jsPDF) {
      alert('PDF library failed to load — check your connection and try again.');
      return;
    }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    const now = new Date();
    const generatedOn = `${now.getDate()} ${now.toLocaleString('en-US', { month: 'short' })} ${now.getFullYear()} at ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const rangeLabel = `${toDateInputValue(report.fromDate)} to ${toDateInputValue(report.toDate)}`;
    const studentLabel = report.mode === 'individual' && report.students[0] ? report.students[0].displayName : 'All Students';
    const reportTypeLabel = report.mode === 'individual' ? 'Individual Student Detail' : 'Summary By Student';

    // --- Header: plain white, no filled band. A single bold word in
    // the brand navy carries all the "branding" this needs; "Attendance
    // Report" is bold too (still soft gray) for more presence, and one
    // thin rule separates it from the page body — the same quiet
    // language as the app's own header, just with a bit more weight. ---
    doc.setTextColor(...PDF_ACCENT);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('Nous Complex', 14, 15);
    doc.setTextColor(...PDF_INK_SOFT);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Attendance Report', 14, 21.5);
    doc.setTextColor(...PDF_INK_FAINT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    const genLabel = `Generated on ${generatedOn}`;
    doc.text(genLabel, pageWidth - 14 - doc.getTextWidth(genLabel), 12);
    doc.setDrawColor(...PDF_BORDER);
    doc.setLineWidth(0.5);
    doc.line(14, 26, pageWidth - 14, 26);

    // --- Meta info: bold labels, normal-weight values ("Class" instead
    // of "Group" throughout the report). ---
    drawMetaRow(doc, 14, 34, 9, [
      { label: 'Date Range', value: rangeLabel },
      { label: 'Class', value: report.channelName },
      { label: 'Student', value: studentLabel },
      { label: 'Total Students', value: report.students.length },
    ]);
    drawMetaRow(doc, 14, 40, 9, [
      { label: 'Report Type', value: reportTypeLabel },
    ]);

    let cursorY = 50;
    let cards, head, body, sectionTitle, statusColIndex = -1, scheduledColIndex = -1;

    if (report.mode === 'individual') {
      const s = report.students[0];
      sectionTitle = 'Session Detail';
      if (!s) {
        cards = [];
        head = [['Notice']];
        body = [['This student is not a member of this class.']];
      } else {
        // Full set of fields from the on-screen individual report —
        // nothing left out.
        cards = [
          { label: 'Calendar days in range', value: report.calendarDaysInRange },
          { label: 'Sessions scheduled in range', value: report.sessionsScheduledInRange },
          { label: 'Scheduled sessions (since joining)', value: s.scheduledSessions },
          { label: 'Not held by teacher', value: s.missedSessions },
          { label: 'Attended', value: s.attendedSessions },
          { label: 'Absent', value: s.absentSessions },
          { label: 'Attendance %', value: formatPct(s.attendancePct) },
          { label: 'Total scheduled duration', value: formatMinutesLabel(s.scheduledMinutes) },
          { label: 'Total stayed', value: formatMinutesLabel(s.attendedMinutes) },
          { label: 'Staying %', value: formatPct(s.stayingPct) },
        ];
        head = [['#', 'Date', 'Scheduled', 'Status', 'Stayed']];
        scheduledColIndex = 2;
        statusColIndex = 3;
        body = s.sessions.map((sess, i) => [
          String(i + 1),
          new Date(sess.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }),
          `${sess.scheduledMinutes} min`,
          !sess.wasHeld ? 'Not Held' : (sess.attended ? 'Present' : 'Absent'),
          sess.attended ? `${sess.minutesStayed} min` : '—',
        ]);
      }
    } else {
      const t = report.groupTotals;
      sectionTitle = 'Student Summary';
      // Full set of fields from the on-screen class summary — nothing
      // left out, and "Group" renamed to "Class" to match the rest of
      // the report.
      cards = [
        { label: 'Calendar days in range', value: report.calendarDaysInRange },
        { label: 'Sessions scheduled in range', value: report.sessionsScheduledInRange },
        { label: 'Students', value: report.students.length },
        { label: 'Sessions not held by teacher', value: t.missedSessions },
        { label: 'Class attendance %', value: formatPct(t.attendancePct) },
        { label: 'Class staying %', value: formatPct(t.stayingPct) },
      ];
      head = [['#', 'Student', 'Scheduled', 'Not Held', 'Attended', 'Absent', 'Attendance %', 'Scheduled', 'Stayed', 'Staying %']];
      body = report.students.map((s, i) => [
        String(i + 1),
        s.displayName + (s.clippedByJoinDate ? ' *' : ''),
        String(s.scheduledSessions),
        String(s.missedSessions),
        String(s.attendedSessions),
        String(s.absentSessions),
        formatPct(s.attendancePct),
        formatMinutesLabel(s.scheduledMinutes),
        formatMinutesLabel(s.attendedMinutes),
        formatPct(s.stayingPct),
      ]);
    }

    if (cards.length) {
      cursorY = drawStatCards(doc, pageWidth, cursorY, cards);
    }

    doc.setTextColor(...PDF_INK);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(sectionTitle, 14, cursorY);
    doc.setDrawColor(...PDF_ACCENT);
    doc.setLineWidth(0.6);
    doc.line(14, cursorY + 2, 14 + doc.getTextWidth(sectionTitle) + 4, cursorY + 2);
    cursorY += 8;

    doc.autoTable({
      head: [head[0].map((h) => String(h).toUpperCase())],
      body,
      startY: cursorY,
      margin: { top: 20, bottom: 18 },
      styles: { fontSize: 8, cellPadding: 3, textColor: PDF_INK, lineColor: PDF_BORDER, lineWidth: 0.2 },
      headStyles: { fillColor: PDF_SUNKEN, textColor: PDF_INK, fontStyle: 'bold', fontSize: 7, halign: 'left' },
      // No zebra shading — flat white rows with a hairline between them,
      // same as .attendance-report-table on screen. Row text stays bold
      // for a bit more presence in the body, matching the meta/header.
      alternateRowStyles: { fillColor: [255, 255, 255] },
      bodyStyles: { fontStyle: 'bold' },
      // # column width scales with how many digits the row count
      // actually needs (1 -> "9", 2 -> "10"-"99", ...) and gets its own
      // tighter padding, so double/triple-digit rows (10, 11, 12...)
      // get the same breathing room as single digits instead of being
      // squeezed/wrapped to fit a width sized for one character.
      columnStyles: head[0].length > 1 ? {
        0: {
          halign: 'center',
          cellWidth: 6 + String(body.length).length * 3.2,
          cellPadding: { top: 3, bottom: 3, left: 1, right: 1 },
          textColor: PDF_INK_FAINT,
          fontStyle: 'bold',
        },
      } : {},
      theme: 'grid',
      // Color-code the same three states the on-screen table uses
      // (Present / Absent / Not held), plus a soft accent tint on the
      // Scheduled column, so the PDF table reads exactly like the
      // in-app one instead of a flat gray grid.
      didParseCell: (data) => {
        // The "#" header cell inherits column 0's styles (including the
        // light gray textColor meant for the body numbers), which can
        // pull its alignment/color away from the other bold, centered
        // header cells. Force it explicitly so "#" always sits centered
        // and reads with the same weight as the rest of the header row.
        if (data.section === 'head' && data.column.index === 0) {
          data.cell.styles.halign = 'center';
          data.cell.styles.textColor = PDF_INK;
          data.cell.styles.fontStyle = 'bold';
          return;
        }
        if (data.section !== 'body') return;
        if (data.column.index === statusColIndex) {
          const val = data.cell.raw;
          if (val === 'Present') { data.cell.styles.textColor = PDF_SUCCESS; data.cell.styles.fontStyle = 'bold'; }
          else if (val === 'Absent') { data.cell.styles.textColor = PDF_DANGER; data.cell.styles.fontStyle = 'bold'; }
          else if (val === 'Not Held') { data.cell.styles.textColor = PDF_INK_FAINT; data.cell.styles.fontStyle = 'bold'; }
        } else if (data.column.index === scheduledColIndex) {
          data.cell.styles.textColor = PDF_ACCENT;
        }
      },
      didDrawPage: (data) => {
        // Slim, borderless repeating header on continuation pages
        // (page 1 already has the full header drawn above).
        if (data.pageNumber > 1) {
          doc.setTextColor(...PDF_INK_SOFT);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(9.5);
          doc.text('Nous Complex — Attendance Report (continued)', 14, 10);
          doc.setDrawColor(...PDF_BORDER);
          doc.setLineWidth(0.4);
          doc.line(14, 13, pageWidth - 14, 13);
        }
        // Footer, every page.
        const footerY = pageHeight - 12;
        doc.setDrawColor(...PDF_BORDER);
        doc.setLineWidth(0.2);
        doc.line(14, footerY - 4, pageWidth - 14, footerY - 4);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(...PDF_INK_FAINT);
        doc.text('Report generated from Nous Complex Attendance Portal', 14, footerY);
        const copyrightLabel = `© ${now.getFullYear()} Nous Complex • All Rights Reserved`;
        doc.text(copyrightLabel, pageWidth - 14 - doc.getTextWidth(copyrightLabel), footerY);
        const pageLabel = `Page ${data.pageNumber}`;
        doc.text(pageLabel, pageWidth / 2 - doc.getTextWidth(pageLabel) / 2, footerY);
      },
    });

    if (report.mode === 'group' && report.students.some((s) => s.clippedByJoinDate)) {
      const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY + 6 : cursorY + 6;
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(...PDF_INK_FAINT);
      doc.text('* Counted from their join date, not the start of the selected range.', 14, finalY);
    }

    const namePart = report.mode === 'individual' && report.students[0] ? report.students[0].username : report.channelName.replace(/[^a-z0-9]+/gi, '-');
    doc.save(`attendance-${namePart}-${toDateInputValue(report.fromDate)}-to-${toDateInputValue(report.toDate)}.pdf`);
  }

  async function requestMediaPermissions() {
    // FIX: root cause of "mic/camera permission indicator stays on after
    // the live meeting ends" — this call only exists to trigger the
    // browser's permission prompt (and catch a denial) BEFORE joining;
    // the actual audio/video for the call itself is handled entirely
    // inside the PlugNmeet iframe, which has its own separate
    // getUserMedia stream. Previously the stream opened here was never
    // stopped — it was requested, then the whole MediaStream object was
    // discarded with no reference kept to it anywhere. A browser/OS only
    // turns off the camera/mic recording indicator when a stream's
    // tracks are explicitly stopped (or the page/tab is closed); simply
    // dropping the JS reference does not do that. So this leaked stream
    // stayed live on the MAIN app page for the rest of the session,
    // completely independent of closeLiveSession()'s `videoIframe.src =
    // ''` teardown (that only tears down PlugNmeet's OWN stream inside
    // the iframe) — which is exactly why the indicator kept showing
    // "intact"/active even after the meeting was closed. Stopping every
    // track right after the permission check resolves keeps the
    // prompt/denial behavior identical but releases the devices
    // immediately instead of holding them for the rest of the app
    // session.
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      console.log('Media permissions granted.');
    } catch (e) {
      const modal = document.createElement('div');
      modal.className = 'modal-overlay';
      modal.innerHTML = `
        <div class="modal-card">
          <h3 class="modal-title"><i class="fas fa-triangle-exclamation" style="color:var(--role-admin); font-size:14px;"></i> Permissions required</h3>
          <p class="modal-body">Camera and microphone access are blocked. Allow permissions in your browser settings, then reload the page.</p>
          <button onclick="this.closest('.modal-overlay').remove()" class="btn btn-ghost btn-block">Got it</button>
        </div>
      `;
      document.body.appendChild(modal);
    } finally {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    }
  }

  // ============================================================
  // 7c. ADMIN: USER MANAGEMENT
  // ============================================================

  async function loadRegisteredUsersList() {
    if (!DOM.registeredUsersListView || !state.isAdmin) return;

    if (registeredUsersListLoading) return;
    registeredUsersListLoading = true;

    if (registeredUsersListHasData) {
      renderRegisteredUsersList();
    } else {
      DOM.registeredUsersListView.innerHTML = '<div class="empty-note">Loading users…</div>';
    }

    try {
      await loadRoleCache();

      const [membersRes, channelsRes] = await Promise.all([
        supabase.from(CONFIG.SUPABASE.TABLES.MEMBERS).select('username, channel_id, role'),
        supabase.from(CONFIG.SUPABASE.TABLES.CHANNELS).select('id, name').order('name'),
      ]);

      if (membersRes.error || channelsRes.error) {
        console.warn('Could not load user assignments:', membersRes.error || channelsRes.error);
        if (!registeredUsersListHasData) {
          DOM.registeredUsersListView.innerHTML = '<div class="empty-note">Could not load users</div>';
        }
        return;
      }

      allGroupsCache = channelsRes.data || [];
      const channelNameById = new Map(allGroupsCache.map((c) => [String(c.id), c.name]));

      const memberships = new Map();
      (membersRes.data || []).forEach((m) => {
        const key = (m.username || '').toLowerCase();
        if (!key) return;
        const entry = {
          channelId: String(m.channel_id),
          channelName: channelNameById.get(String(m.channel_id)) || 'Unknown session',
          role: m.role || 'student',
        };
        if (!memberships.has(key)) memberships.set(key, []);
        memberships.get(key).push(entry);
      });

      registeredUserMemberships = memberships;
      registeredUsersListHasData = true;
      renderRegisteredUsersList();
    } finally {
      registeredUsersListLoading = false;
    }
  }

  function renderRegisteredUsersList() {
    if (!DOM.registeredUsersListView) return;

    const query = ((DOM.manageUserSearch && DOM.manageUserSearch.value) || '').trim().toLowerCase();
    const usernames = Object.keys(state.roleCache)
      .filter((u) => !query || u.includes(query))
      .sort();

    if (!usernames.length) {
      DOM.registeredUsersListView.innerHTML = `<div class="empty-note">${query ? 'No matching users' : 'No registered users'}</div>`;
      return;
    }

    const unassigned = [];
    const assigned = [];
    usernames.forEach((u) => {
      const memberships = registeredUserMemberships.get(u) || [];
      (memberships.length ? assigned : unassigned).push(u);
    });

    const renderRow = (username) => {
      const memberships = registeredUserMemberships.get(username) || [];
      const groupsLabel = memberships.length
        ? escapeHtml(memberships.map((m) => m.channelName).join(', '))
        : 'No groups yet';
      const role = state.roleCache[username];
      const displayName = getDisplayName(username);
      return `
        <div class="registered-user-row" data-username="${escapeHtml(username)}">
          ${avatarHtml(username, 'sm')}
          <div class="registered-user-info">
            <div class="registered-user-name">${escapeHtml(displayName)} <span class="member-display-name">(${escapeHtml(username)})</span></div>
            <div class="registered-user-groups${memberships.length ? '' : ' unassigned'}">${groupsLabel}</div>
          </div>
          <span class="role-chip role-${roleKey(username)}-chip member-role-chip">${escapeHtml(role || 'student')}</span>
          <button class="icon-btn registered-user-manage-btn" data-manage-groups="${escapeHtml(username)}" title="Manage groups" aria-label="Manage groups">
            <i class="fas fa-layer-group"></i>
          </button>
        </div>
      `;
    };

    const section = (label, iconClass, users, labelClass) => {
      if (!users.length) return '';
      return `
        <div class="registered-user-section">
          <div class="registered-user-section-label${labelClass ? ' ' + labelClass : ''}">
            <i class="fas ${iconClass}"></i> ${label} <span class="registered-user-count">(${users.length})</span>
          </div>
          <div class="registered-user-rows">${users.map(renderRow).join('')}</div>
        </div>
      `;
    };

    DOM.registeredUsersListView.innerHTML =
      section('Unassigned', 'fa-triangle-exclamation', unassigned, 'unassigned-label') +
      section('Assigned', 'fa-users', assigned, '');

    DOM.registeredUsersListView.querySelectorAll('.registered-user-row').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('[data-manage-groups]')) return;
        const username = row.dataset.username;
        DOM.manageUserSearch.value = username;
        loadUserForEdit(username);
      });
    });

    DOM.registeredUsersListView.querySelectorAll('[data-manage-groups]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openGroupAssignmentModal(btn.dataset.manageGroups);
      });
    });
  }

  async function openGroupAssignmentModal(username) {
    username = normalizeUsername(username);
    if (!username || !state.isAdmin) return;

    if (!allGroupsCache.length) {
      const { data, error } = await supabase
        .from(CONFIG.SUPABASE.TABLES.CHANNELS)
        .select('id, name')
        .order('name');
      if (!error) allGroupsCache = data || [];
    }

    if (!allGroupsCache.length) {
      alert('No groups/sessions exist yet — create one first from Settings → Create New Session.');
      return;
    }

    const existingMemberships = registeredUserMemberships.get(username) || [];
    const membershipByChannel = new Map(existingMemberships.map((m) => [m.channelId, m]));
    const defaultRole = getRoleFromUsername(username) === CONFIG.AUTH.ROLES.TEACHER ? 'teacher' : 'student';

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-card group-assign-modal">
        <h3 class="modal-title"><i class="fas fa-layer-group" style="color:var(--role-admin); font-size:14px;"></i> Groups for ${escapeHtml(getDisplayName(username))}</h3>
        <p class="modal-body" style="margin:8px 0 12px;">Check every session this user belongs to, and set their role in each one.</p>
        <div class="group-assign-list">
          ${allGroupsCache.map((ch) => {
            const existing = membershipByChannel.get(String(ch.id));
            const checked = !!existing;
            const role = existing ? existing.role : defaultRole;
            return `
              <label class="group-assign-row">
                <input type="checkbox" class="group-assign-check" data-channel-id="${escapeHtml(String(ch.id))}" ${checked ? 'checked' : ''}>
                <span class="group-assign-name">${escapeHtml(ch.name)}</span>
                <select class="field-sm group-assign-role" data-channel-id="${escapeHtml(String(ch.id))}">
                  <option value="student" ${role === 'student' ? 'selected' : ''}>Student</option>
                  <option value="teacher" ${role === 'teacher' ? 'selected' : ''}>Teacher</option>
                </select>
              </label>
            `;
          }).join('')}
        </div>
        <div style="display:flex; gap:8px; margin-top:16px;">
          <button id="groupAssignCancelBtn" class="btn-secondary" style="flex:1;">Cancel</button>
          <button id="groupAssignSaveBtn" class="btn-primary" style="flex:1;">Save</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const close = () => modal.remove();
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    modal.querySelector('#groupAssignCancelBtn').addEventListener('click', close);

    modal.querySelector('#groupAssignSaveBtn').addEventListener('click', async () => {
      const saveBtn = modal.querySelector('#groupAssignSaveBtn');
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving…';

      const toUpsert = [];
      const toRemoveChannelIds = [];

      modal.querySelectorAll('.group-assign-check').forEach((checkbox) => {
        const channelId = checkbox.dataset.channelId;
        const roleSelect = modal.querySelector(`.group-assign-role[data-channel-id="${CSS.escape(channelId)}"]`);
        if (checkbox.checked) {
          toUpsert.push({
            channel_id: channelId,
            username,
            role: roleSelect ? roleSelect.value : defaultRole,
            added_by: state.currentUser.username,
          });
        } else if (membershipByChannel.has(channelId)) {
          toRemoveChannelIds.push(channelId);
        }
      });

      try {
        if (toUpsert.length) {
          const { error: upsertError } = await supabase
            .from(CONFIG.SUPABASE.TABLES.MEMBERS)
            .upsert(toUpsert, { onConflict: 'channel_id,username' });
          if (upsertError) throw upsertError;
        }
        if (toRemoveChannelIds.length) {
          const { error: deleteError } = await supabase
            .from(CONFIG.SUPABASE.TABLES.MEMBERS)
            .delete()
            .eq('username', username)
            .in('channel_id', toRemoveChannelIds);
          if (deleteError) throw deleteError;
        }

        close();
        if (state.currentChannel) await loadMembers(state.currentChannel.id);
        await loadRegisteredUsersList();
      } catch (e) {
        console.error('Group assignment error:', e);
        alert('Could not save group assignments: ' + (e.message || e));
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save';
      }
    });
  }

  function showUserEditForm() {
    if (DOM.registeredUsersListWrap) DOM.registeredUsersListWrap.classList.add('hidden');
    DOM.userEditForm.style.display = 'flex';
  }

  function closeUserEditForm() {
    DOM.userEditForm.style.display = 'none';
    DOM.editUsername.value = '';
    DOM.editDisplayName.value = '';
    DOM.editNewUsername.value = '';
    DOM.editPassword.value = '';
    if (DOM.registeredUsersListWrap) DOM.registeredUsersListWrap.classList.remove('hidden');
  }

  async function loadUserForEdit(username) {
    username = normalizeUsername(username);
    if (!username) { alert('Enter a username to search for.'); return; }

    const { data: roleData, error: roleError } = await supabase
      .from('user_roles')
      .select('username, role, display_name')
      .eq('username', username)
      .maybeSingle();

    if (roleError || !roleData) {
      alert(`User "${username}" not found.`);
      closeUserEditForm();
      return;
    }

    DOM.editUsername.value = roleData.username;
    DOM.editDisplayName.value = roleData.display_name || roleData.username;
    DOM.editNewUsername.value = roleData.username;
    DOM.editRole.value = roleData.role;
    DOM.editPassword.value = '';
    showUserEditForm();
  }

  async function callAdminUpdateUserFunction(targetUsername, { newEmail, newPassword } = {}) {
    if (!newEmail && !newPassword) return { error: null };
    const { data, error } = await supabase.functions.invoke('admin-update-user', {
      body: {
        targetUsername,
        newEmail: newEmail || undefined,
        newPassword: newPassword || undefined,
      },
    });
    if (error) return { error };
    if (data && data.error) return { error: new Error(data.error) };
    return { error: null };
  }

  async function updateUserAccount(username, newUsername, newDisplayName, newRole, newPassword) {
    username = normalizeUsername(username);
    newUsername = normalizeUsername(newUsername);
    
    if (!username) { alert('Current username is required.'); return; }
    
    try {
      if (newUsername && newUsername !== username) {
        const { error: roleError, count } = await supabase
          .from('user_roles')
          .update({
            username: newUsername,
            role: newRole,
            display_name: newDisplayName || newUsername
          }, { count: 'exact' })
          .eq('username', username);

        if (roleError) {
          if (roleError.code === '23505' || /duplicate key/i.test(roleError.message || '')) {
            throw new Error(`Username "${newUsername}" is already taken by another user.`);
          }
          throw roleError;
        }
        if (count === 0) {
          throw new Error(`User "${username}" not found (already renamed or deleted?).`);
        }
        
        const { error: authError } = await callAdminUpdateUserFunction(username, {
          newEmail: generateEmail(newUsername),
        });
        if (authError) throw authError;
        
        await supabase.from(CONFIG.SUPABASE.TABLES.MEMBERS)
          .update({ username: newUsername })
          .eq('username', username);
        
        await supabase.from(CONFIG.SUPABASE.TABLES.MESSAGES)
          .update({ username: newUsername })
          .eq('username', username);
        
        await supabase.from(CONFIG.SUPABASE.TABLES.STATUSES)
          .update({ username: newUsername })
          .eq('username', username);
        
        await supabase.from('class_schedule')
          .update({ teacher_username: newUsername })
          .eq('teacher_username', username);
        
        delete state.roleCache[username];
        delete state.displayNameCache[username];
        state.roleCache[newUsername] = newRole;
        state.displayNameCache[newUsername] = newDisplayName || newUsername;

        if (newPassword && newPassword.length > 0) {
          const { error: passError } = await callAdminUpdateUserFunction(newUsername, { newPassword });
          if (passError) throw passError;
        }
      } else {
        const { error: roleError } = await supabase
          .from('user_roles')
          .update({ 
            role: newRole,
            display_name: newDisplayName || username
          })
          .eq('username', username);
        if (roleError) throw roleError;
        state.roleCache[username] = newRole;
        state.displayNameCache[username] = newDisplayName || username;

        if (newPassword && newPassword.length > 0) {
          const { error: passError } = await callAdminUpdateUserFunction(username, { newPassword });
          if (passError) throw passError;
        }
      }
      
      alert('User updated successfully!');
      closeUserEditForm();
      DOM.manageUserSearch.value = '';
      populateRegisteredUsersDatalist();
      await loadRoleCache();
      await loadRegisteredUsersList();

    } catch (e) {
      console.error('Update user error:', e);
      alert('Could not update user: ' + (e.message || e));
    }
  }

  async function callAdminDeleteUserFunction(targetUsername, removeData) {
    const { data, error } = await supabase.rpc('admin_delete_user', {
      target_username: targetUsername,
      remove_data: removeData,
    });
    if (error) return { error };
    return { error: null, data };
  }

  function openDeleteUserChoiceModal(username) {
    return new Promise((resolve) => {
      const modal = document.createElement('div');
      modal.className = 'modal-overlay';
      modal.innerHTML = `
        <div class="modal-card">
          <h3 class="modal-title"><i class="fas fa-trash" style="color:var(--danger);"></i> Delete "${escapeHtml(username)}"</h3>
          <p class="modal-body" style="margin-bottom:16px;">
            This removes their login and role permanently. Choose what happens to the messages, statuses, and schedule entries they created:
          </p>
          <div style="display:flex; flex-direction:column; gap:10px;">
            <button id="deleteUserKeepDataBtn" class="btn-secondary" style="width:100%;">
              Delete user only — keep their messages
            </button>
            <button id="deleteUserWipeDataBtn" class="btn-danger" style="width:100%;">
              Delete user and all their chat data
            </button>
            <button id="deleteUserCancelBtn" class="btn-secondary" style="width:100%;">
              Cancel
            </button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      const cleanup = (result) => { modal.remove(); resolve(result); };
      modal.querySelector('#deleteUserKeepDataBtn').addEventListener('click', () => cleanup(false));
      modal.querySelector('#deleteUserWipeDataBtn').addEventListener('click', () => cleanup(true));
      modal.querySelector('#deleteUserCancelBtn').addEventListener('click', () => cleanup(null));
      modal.addEventListener('click', (e) => { if (e.target === modal) cleanup(null); });
    });
  }

  async function deleteUserAccount(username) {
    username = normalizeUsername(username);
    if (!username) { alert('No user selected.'); return; }

    const removeData = await openDeleteUserChoiceModal(username);
    if (removeData === null) return;

    try {
      const { error: authError } = await callAdminDeleteUserFunction(username, removeData);
      if (authError) throw authError;
      
      delete state.roleCache[username];
      delete state.displayNameCache[username];
      alert(removeData ? 'User and their data deleted successfully!' : 'User deleted — their messages were kept.');
      closeUserEditForm();
      DOM.manageUserSearch.value = '';
      populateRegisteredUsersDatalist();
      await loadRoleCache();
      await loadRegisteredUsersList();

    } catch (e) {
      console.error('Delete user error:', e);
      alert('Could not delete user: ' + (e.message || e));
    }
  }

  // ============================================================
  // 5g. INACTIVITY DISCONNECTION MANAGEMENT
  // ============================================================
  function setupInactivityManager() {
    cleanupInactivityManager();

    function resetInactivityTimer() {
      if (state.inactivityTimer) {
        clearTimeout(state.inactivityTimer);
        state.inactivityTimer = null;
      }
      
      const needsReconnect = state.isTabFocused && state.currentChannel && (
        !state.messagesSubscription ||
        state.messagesSubscription.state === 'closed' ||
        state.messagesSubscription.state === 'errored'
      );
      if (needsReconnect) {
        console.log("🔄 User active! Reconnecting...");
        subscribeToMessages(state.currentChannel.id);
      }

      state.inactivityTimer = setTimeout(() => {
        if (state.messagesSubscription && state.isTabFocused) {
          console.log("⏰ 5 min idle. Disconnecting to save resources.");
          teardownMessagesSubscription();
          state.isChannelActive = false;
          console.log("💤 Channel disconnected. Will reconnect when active.");
        }
      }, state.INACTIVITY_TIMEOUT);
    }

    resetInactivityTimer();

    const activityEvents = ['mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach(event => {
      window.addEventListener(event, resetInactivityTimer);
    });

    state.connectionWatchdog = setInterval(() => {
      if (!state.currentChannel) return;

      const sub = state.messagesSubscription;
      const isDead = !sub || sub.state === 'closed' || sub.state === 'errored';

      if (isDead && !reconnectTimer) {
        console.log('🩺 Watchdog: connection unhealthy, reconnecting...', sub ? sub.state : 'no subscription');
        subscribeToMessages(state.currentChannel.id);
      }
    }, 20000);

    state._inactivityCleanup = function() {
      if (state.inactivityTimer) {
        clearTimeout(state.inactivityTimer);
        state.inactivityTimer = null;
      }
      if (state.connectionWatchdog) {
        clearInterval(state.connectionWatchdog);
        state.connectionWatchdog = null;
      }
      activityEvents.forEach(event => {
        window.removeEventListener(event, resetInactivityTimer);
      });
    };

    console.log('⏱️ Inactivity manager initialized');
  }

  function cleanupInactivityManager() {
    if (state._inactivityCleanup) {
      state._inactivityCleanup();
      state._inactivityCleanup = null;
    }
    if (state.inactivityTimer) {
      clearTimeout(state.inactivityTimer);
      state.inactivityTimer = null;
    }
    console.log('⏱️ Inactivity manager cleaned up');
  }

  // ============================================================
  // 5h. TAB FOCUS MANAGER
  // ============================================================
  function setupTabFocusManager() {
    cleanupTabFocusManager();

    if (state.currentChannel) {
      state.tabChannel = supabase.channel(`tab-focus-${state.currentChannel.id}`);
      state.tabChannel.subscribe();
    }

    const handleVisibilityChange = async () => {
      if (document.hidden) {
        console.log("🔴 Tab hidden. Keeping message connection alive for background notifications.");
        state.isTabFocused = false;

        if (state.tabChannel) {
          await supabase.removeChannel(state.tabChannel);
          state.tabChannel = null;
        }
      } else {
        console.log("🟢 Tab focused again! Reconnecting...");
        state.isTabFocused = true;

        // FIX: see the FIX comment above setupPresence() — this is the
        // "regaining tab focus forces an immediate health check" half of
        // that fix. Without this, a presence socket that died while the
        // tab was backgrounded wouldn't recover until the (up to 20s)
        // watchdog interval happened to notice.
        ensurePresenceHealthy();

        if (!state.tabChannel && state.currentChannel) {
          state.tabChannel = supabase.channel(`tab-focus-${state.currentChannel.id}`);
          state.tabChannel.subscribe();
        }
        
        if (!state.messagesSubscription && state.currentChannel) {
          subscribeToMessages(state.currentChannel.id);
        }

        if (state.currentUser) {
          subscribeToChannelListUpdates();
          subscribeToMyMembershipBroadcast();
          try {
            state.channelPreviews = await loadChannelPreviews(allChannels.map((c) => c.id));
            renderChatList(allChannels);
          } catch (e) {
            console.warn('Failed to refresh chat list previews on refocus:', e);
          }
        }

        if (state.currentChannel && !state.isRefreshing) {
          state.isRefreshing = true;
          console.log("📥 Catching up on messages missed while tab was inactive...");
          try {
            const reopenedChannel = state.currentChannel;
            if (!state.isAdmin) {
              const stillMember = await verifyChannelMembership(reopenedChannel.id);
              if (!stillMember) {
                await expelFromChannel(reopenedChannel.id);
                return;
              }
            }

            await fetchFreshHistory(state.currentChannel.id);
            console.log("✅ Catch-up complete!");

            if (isChatDetailVisible(state.currentChannel.id)) {
              clearUnreadBadgeForChannel(state.currentChannel.id);
              await queueMarkSeen(state.currentChannel.id);
            }
          } catch (e) {
            console.warn('Catch-up failed:', e);
          } finally {
            state.isRefreshing = false;
          }
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    state._tabFocusCleanup = function() {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (state.tabChannel) {
        supabase.removeChannel(state.tabChannel);
        state.tabChannel = null;
      }
    };

    console.log('📋 Tab focus manager initialized');
  }

  function cleanupTabFocusManager() {
    if (state._tabFocusCleanup) {
      state._tabFocusCleanup();
      state._tabFocusCleanup = null;
    }
    if (state.tabChannel) {
      supabase.removeChannel(state.tabChannel);
      state.tabChannel = null;
    }
    console.log('📋 Tab focus manager cleaned up');
  }

  // ============================================================
  // SELECT CHANNEL
  // ============================================================
  async function selectChannel(channel, { markSeenNow = true, userInitiated = true } = {}) {
    if (typeof exitMessageSelection === 'function') exitMessageSelection();
    chatNeedsInitialPaint = true;
    if (state.currentChannel && state.currentChannel.id !== channel.id) {
      clearTypingIndicator(state.currentChannel.id);
    }
    state.currentChannel = channel;
    // FIX: reset pagination state when switching channels so the "Load
    // older" button doesn't linger from the previous channel and
    // loadOlderMessages() uses the right cursor.
    state.hasOlderMessages = false;
    state.oldestLoadedTimestamp = null;
    if (DOM.loadOlderBtn && DOM.loadOlderBtn.isConnected) {
      DOM.loadOlderBtn.remove();
    }
    DOM.loadOlderBtn = null;
    // FIX: see isChatDetailVisible() above. Only a genuine user click/tap
    // (openChannel(), a calendar item link, creating a channel, etc. — all
    // of which call selectChannel() with the default userInitiated: true)
    // should count as "the user opened this chat" for read-receipt
    // purposes. renderChannels()'s silent fallback-to-first-channel on
    // load passes userInitiated: false specifically so it doesn't.
    state.channelExplicitlyOpened = userInitiated;
    updateChatEmptyState();
    highlightActiveChatRow();
    // FIX: the composer sits behind the ".chat-welcome" placeholder until
    // updateChatEmptyState() above reveals it, so this is the first point
    // where measuring #messageInput's height is actually meaningful —
    // see the offsetParent guard in autoGrowMessageInput() for why the
    // startup call alone wasn't enough.
    autoGrowMessageInput();

    const cachedMessages = getCachedMessages(channel.id);
    state.messages = cachedMessages || [];
    renderMessages(true);
    if (cachedMessages) {
      console.log(`⚡ Instant load: ${cachedMessages.length} messages from cache`);
    }

    const messagesReady = loadMessages(channel.id).then(() => subscribeToMessages(channel.id));
    const membersReady = loadMembers(channel.id);
    const readsReady = loadMessageReads(channel.id).then(() => subscribeToMessageReads(channel.id));
    const scheduleReady = loadSchedule(channel.id).then(() => subscribeToSchedule(channel.id));

    await Promise.all([messagesReady, membersReady, readsReady, scheduleReady]);

    updateChatDetailHeader();
    updateProfileScreen();

    if (markSeenNow) {
      clearUnreadBadgeForChannel(channel.id);
      queueMarkSeen(channel.id);
    } else {
      refreshUnreadBadges();
    }

    setupInactivityManager();
    setupTabFocusManager();
  }

  // FIX: "make the selection unselected when we click on empty space of
  // sessions panel" — there used to be no way to go from "a channel is
  // selected" back to the neutral state short of picking a different
  // channel. This is selectChannel()'s teardown counterpart: it undoes
  // everything selectChannel() sets up (subscriptions, typing indicator,
  // schedule watch) and clears state.currentChannel, then reuses
  // updateChatEmptyState()/highlightActiveChatRow() — the same two calls
  // selectChannel() itself uses to reflect selection — to flip the UI
  // back to the "Select a session" welcome screen (desktop) and drop the
  // active highlight from the list row. Wired up below on #channelList's
  // own background click (see EVENT BINDINGS).
  function deselectChannel() {
    if (!state.currentChannel) return;
    if (typeof exitMessageSelection === 'function') exitMessageSelection();
    clearTypingIndicator(state.currentChannel.id);
    teardownMessagesSubscription();
    teardownReadsSubscription();
    if (scheduleSubscription) {
      supabase.removeChannel(scheduleSubscription);
      scheduleSubscription = null;
    }
    clearScheduleExpiryTimer();

    state.currentChannel = null;
    state.channelExplicitlyOpened = false;
    state.messages = [];
    state.currentMembers = [];
    state.currentSchedule = null;
    // FIX: clear the shared-media cache along with everything else on
    // deselect — otherwise the next channel opened briefly shows this
    // channel's photos/videos until its own loadSharedMedia() resolves.
    state.sharedPhotoMessages = [];
    state.sharedVideoMessages = [];
    state.sharedMediaChannelId = null;
    // FIX: clear pagination state on deselect so it doesn't carry over
    // if the same channel is re-opened.
    state.hasOlderMessages = false;
    state.oldestLoadedTimestamp = null;
    if (DOM.loadOlderBtn && DOM.loadOlderBtn.isConnected) {
      DOM.loadOlderBtn.remove();
    }
    DOM.loadOlderBtn = null;

    updateChatEmptyState();
    highlightActiveChatRow();
    updateLiveButtonState();
  }

  function updateChatDetailHeader() {
    if (!state.currentChannel) return;
    DOM.chatDetailName.textContent = state.currentChannel.name;
    updateChatDetailSubtitle();
  }

  function updateChatDetailSubtitle() {
    if (!state.currentChannel) return;
    if (getTypingUsernames(state.currentChannel.id).length > 0) return;
    if (DOM.chatDetailSub) DOM.chatDetailSub.classList.remove('typing-active');
    const total = state.currentMembers.length;
    const online = state.currentMembers.filter((m) => state.onlineUsers.has((m.username || '').toLowerCase())).length;
    DOM.chatDetailSub.textContent = total ? `${total} member${total === 1 ? '' : 's'} · ${online} online` : '';
  }

  // ============================================================
  // 14. LOGIN FLOW
  // ============================================================
  async function completeLogin(username, user) {
    console.log('🔐 Completing login for:', username);

    hideAppLoading();
    DOM.authCard.classList.add('hidden');
    DOM.dashboard.classList.remove('hidden');

    screenHistory = [];
    goToScreen('chats');

    // FIX: Ensure role cache is loaded BEFORE setting user state
    // This is critical for teachers to be properly detected
    await loadRoleCache();
    
    const role = getRoleFromUsername(username);
    const key = roleKey(username);
    const displayName = getDisplayName(username);

    state.currentUser = { id: user.id, username: username, email: user.email, role: role };
    state.isAdmin = role === CONFIG.AUTH.ROLES.ADMIN;
    state.isTeacher = role === CONFIG.AUTH.ROLES.TEACHER || state.isAdmin;

    console.log(`👤 User role: ${role}, isTeacher: ${state.isTeacher}, isAdmin: ${state.isAdmin}`);

    try {
      const { data: ownRoleRow, error: ownRoleError } = await supabase
        .from('user_roles')
        .select('id')
        .eq('username', username)
        .maybeSingle();
      state.myUserRoleId = ownRoleError ? null : (ownRoleRow ? ownRoleRow.id : null);
    } catch (e) {
      console.warn('Could not capture own user_roles id:', e);
      state.myUserRoleId = null;
    }

    DOM.userBadge.textContent = displayName;
    DOM.userBadge.className = `role-chip role-${key}-chip`;

    setAvatarEl(DOM.settingsAvatar, username, 'lg');
    DOM.settingsName.textContent = displayName;
    DOM.settingsEmail.textContent = user.email || generateEmail(username);
    DOM.settingsDisplayName.textContent = `Username: ${username}`;

    DOM.adminSettingsCard.classList.toggle('hidden', !(state.isAdmin && CONFIG.FEATURES.ENABLE_ADMIN_CONSOLE));
    if (DOM.viewCalendarBtn) DOM.viewCalendarBtn.classList.toggle('hidden', !state.isAdmin);
    if (DOM.viewAttendanceReportBtn) DOM.viewAttendanceReportBtn.classList.toggle('hidden', !state.isAdmin);
    DOM.adminProfileSchedule.classList.toggle('hidden', !state.isAdmin);

    if (state.isAdmin && CONFIG.FEATURES.ENABLE_ADMIN_CONSOLE) {
      loadRegisteredUsersList();
    }

    setupPresence();
    startSessionWatchdog();
    // FIX: root cause of "browser asks for camera/mic permission when no
    // meeting is open" — this used to run unconditionally on every login
    // and every session restore, so the permission prompt fired the
    // instant someone signed in, whether or not they ever opened a live
    // session that visit. Moved to joinLiveClass() (see the FIX comment
    // there), which only runs when a user actually clicks Start/Join Live
    // Session — that's the point permissions should be requested.
    await renderChannels();
    subscribeToChannelListUpdates();
    subscribeToMyMembershipBroadcast();
    startChannelPreviewPolling();
    startMembershipPolling();
    startMediaExpiryWatcher();
    await refreshUnreadBadges();
    await loadStatuses();
    
    try {
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          console.log('✅ Notification permission granted');
        }
      }
    } catch (e) {
      console.warn('Notification permission request failed:', e);
    }

    syncNotificationToggleState();

    console.log('✅ Login complete!');
  }

  async function handleLogin() {
    const username = normalizeUsername(DOM.usernameInput.value);
    const password = DOM.passwordInput.value;

    if (!username || !password) {
      showError('Enter both your Orbit ID and Password.');
      return;
    }
    hideError();

    try {
      const user = await loginWithUsername(username, password);
      DOM.passwordInput.value = '';
      await completeLogin(username, user);
    } catch (e) {
      DOM.passwordInput.value = '';
      showError(e.message || 'Login error. Please try again.');
    }
  }

  async function restoreSession() {
    try {
      console.log('🔄 Checking for existing session...');
      const { data: { session } } = await supabase.auth.getSession();
      if (!session || !session.user || !session.user.email) {
        console.log('No active session found');
        return;
      }

      const suffix = CONFIG.AUTH.EMAIL_SUFFIX;
      if (!session.user.email.endsWith(suffix)) {
        console.log('Session email does not match expected suffix');
        return;
      }

      const username = normalizeUsername(session.user.email.slice(0, -suffix.length));
      console.log('🔄 Restoring session for:', username);
      await completeLogin(username, session.user);
    } catch (e) {
      console.warn('Session restore skipped:', e);
    } finally {
      hideAppLoading();
      if (DOM.dashboard.classList.contains('hidden')) {
        DOM.authCard.classList.remove('hidden');
      }
    }
  }

  const SESSION_CHECK_INTERVAL = 60000;
  const SESSION_CHECK_FAILURE_THRESHOLD = 3;
  let sessionCheckFailures = 0;

  function startSessionWatchdog() {
    stopSessionWatchdog();
    sessionCheckFailures = 0;
    state.sessionWatchdog = setInterval(async () => {
      if (!state.currentUser) return;

      if (document.hidden || (typeof navigator !== 'undefined' && navigator.onLine === false)) {
        console.log('⏭️ Session watchdog: tab hidden or offline, skipping this check.');
        return;
      }

      try {
        const { data, error } = await supabase.auth.getUser();
        if (error || !data || !data.user) {
          sessionCheckFailures += 1;
          console.warn(`🩺 Session watchdog: check failed (${sessionCheckFailures}/${SESSION_CHECK_FAILURE_THRESHOLD}).`, error);

          if (sessionCheckFailures < SESSION_CHECK_FAILURE_THRESHOLD) return;

          const { error: refreshError } = await supabase.auth.refreshSession();
          if (refreshError) {
            console.warn('🚫 Session watchdog: refresh also failed, account/session is really gone — signing out.', refreshError);
            await forceSignOut('Your account is no longer available. You have been signed out.');
          } else {
            console.log('✅ Session watchdog: refresh succeeded — session was just stale, staying signed in.');
            sessionCheckFailures = 0;
          }
        } else {
          sessionCheckFailures = 0;
        }
      } catch (e) {
        console.warn('Session watchdog check failed (network):', e);
      }
    }, SESSION_CHECK_INTERVAL);
  }

  function stopSessionWatchdog() {
    if (state.sessionWatchdog) {
      clearInterval(state.sessionWatchdog);
      state.sessionWatchdog = null;
    }
  }

  async function performSignOutCleanup() {
    try {
      await supabase.auth.signOut({ scope: 'local' });
    } catch (e) {
      console.warn('Sign out error:', e);
    }

    stopSessionWatchdog();
    teardownMessagesSubscription();
    teardownReadsSubscription();
    teardownStatusViewsSubscription();
    teardownStatusesSubscription();
    stopStatusExpiryWatcher();
    unsubscribeFromChannelListUpdates();
    unsubscribeFromMyMembershipBroadcast();
    unsubscribeAllChannelBadges();
    stopChannelPreviewPolling();
    stopMembershipPolling();
    stopMediaExpiryWatcher();
    if (scheduleSubscription) {
      supabase.removeChannel(scheduleSubscription);
      scheduleSubscription = null;
    }
    clearScheduleExpiryTimer();
    unsubscribeFromAllSchedules();
    teardownPresence();
    cleanupInactivityManager();
    cleanupTabFocusManager();

    state.currentUser = null;
    state.currentChannel = null;
    state.currentMembers = [];
    state.isAdmin = false;
    state.isTeacher = false;
    state.messages = [];
    state.statuses = [];
    state.replyingTo = null;
    state.isChannelActive = false;
    state.isTabFocused = true;
    state.currentSchedule = null;
    state.sharedPhotoMessages = [];
    state.sharedVideoMessages = [];
    state.sharedMediaChannelId = null;
    updateLiveButtonState();

    allChannels = [];
    state.unreadByChannel = {};
    state.channelPreviews = {};
    state.messageReads = new Map();
    state.statusViews = new Map();
    state.myMemberships = new Map();
    state.myUserRoleId = null;
    DOM.navChatsBadge.textContent = '0';
    DOM.navChatsBadge.classList.add('hidden');
    if (DOM.navUpdatesBadge) DOM.navUpdatesBadge.classList.add('hidden');

    try {
      const keys = Object.keys(localStorage);
      keys.forEach(key => {
        if (key.startsWith('cached_chat_history_')) {
          localStorage.removeItem(key);
        }
      });
      console.log('🗑️ Cleared cached messages on logout');
    } catch (e) {
      console.warn('Failed to clear cache:', e);
    }

    DOM.dashboard.classList.add('hidden');
    closeLiveSession();
    DOM.authCard.classList.remove('hidden');
    DOM.usernameInput.value = '';
    DOM.passwordInput.value = '';
    hideError();
    
    screenHistory = [];
  }

  async function handleSignOut() {
    if (!confirm('Sign out?')) return;
    await performSignOutCleanup();
  }

  async function forceSignOut(message) {
    if (!state.currentUser) return;
    await performSignOutCleanup();
    if (message) alert(message);
  }

  // ============================================================
  // 7a. ADMIN: CREATE TEACHER / STUDENT ACCOUNT
  // ============================================================
  async function createUserAccount(username, displayName, role, password) {
    username = normalizeUsername(username);
    if (!username) { alert('Enter a username.'); return; }
    if (!password) { alert('Enter or generate a password.'); return; }

    const email = generateEmail(username);

    try {
      const { data: signUpData, error: signUpError } = await adminAuthClient.auth.signUp({ email, password });
      await adminAuthClient.auth.signOut();

      const isAlreadyRegistered =
        signUpError && /already registered|already exists/i.test(signUpError.message || '');

      if (signUpError && !isAlreadyRegistered) throw signUpError;

      const { error: roleError } = await supabase
        .from('user_roles')
        .upsert({ 
          username, 
          role, 
          display_name: displayName || username 
        }, { onConflict: 'username' });
      if (roleError) throw roleError;

      const key = username.toLowerCase();
      state.roleCache[key] = role;
      state.displayNameCache[key] = displayName || username;
      populateRegisteredUsersDatalist();
      renderRegisteredUsersList();
      DOM.newUserUsername.value = '';
      DOM.newUserDisplayName.value = '';
      DOM.newUserPassword.value = '';
      DOM.newUserRole.value = 'student';

      if (isAlreadyRegistered) {
        alert(
          `"${username}" already had an account.\n\n` +
          `Role set to ${role}, but the password shown here was NOT applied.`
        );
      } else if (signUpData && !signUpData.session) {
        alert(
          `Account created for "${username}" (${role}).\n\n` +
          `Turn off "Confirm email" in Supabase → Authentication → Sign In / Providers → Email.`
        );
      } else {
        alert(`Account created for "${username}" (${role}).\n\nPassword: ${password}`);
      }
    } catch (e) {
      console.error('Create user error:', e);
      alert('Could not create account: ' + (e.message || e));
    }
  }

  // ============================================================
  // 5c. PUSH NOTIFICATIONS
  // ============================================================
  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
  }

  async function syncVapidSubscriptionOnLogin(username) {
    try {
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        console.warn('Push notifications not supported on this browser/device.');
        return { ok: false, reason: 'not_supported' };
      }

      if (!CONFIG.PUSH || !CONFIG.PUSH.VAPID_PUBLIC_KEY) {
        console.warn('No VAPID public key configured — push sync skipped.');
        return { ok: false, reason: 'not_configured' };
      }

      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError || !userData?.user) {
        console.warn('Could not get user UUID:', userError);
        return { ok: false, reason: 'no_auth_user', detail: userError?.message };
      }
      
      const userUuid = userData.user.id;
      console.log(`🔑 Using user UUID: ${userUuid}`);

      let registration;
      try {
        registration = await navigator.serviceWorker.ready;
      } catch (swErr) {
        console.error('Service worker never became ready:', swErr);
        return { ok: false, reason: 'sw_not_ready', detail: swErr?.message };
      }

      let subscription = await registration.pushManager.getSubscription();

      if (!subscription) {
        try {
          subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(CONFIG.PUSH.VAPID_PUBLIC_KEY)
          });
        } catch (subErr) {
          console.error('pushManager.subscribe() failed:', subErr);
          return { ok: false, reason: 'push_subscribe_failed', detail: subErr?.message };
        }
      }

      if (!subscription) {
        console.warn('Could not create push subscription');
        return { ok: false, reason: 'push_subscribe_failed' };
      }

      const subscriptionJson = subscription.toJSON();
      
      const { error } = await supabase
        .from('user_device_tokens')
        .upsert({
          user_id: userUuid,
          subscription_data: subscriptionJson,
          endpoint: subscriptionJson.endpoint,
          p256dh: subscriptionJson.keys?.p256dh,
          auth: subscriptionJson.keys?.auth,
          username: username,
          updated_at: new Date().toISOString()
        }, { onConflict: 'user_id' });

      if (error) {
        console.error('Failed to save push subscription to Supabase:', error);
        return { ok: false, reason: 'db_error', detail: error.message };
      }

      console.log("✅ VAPID Push Subscription safely stored in Supabase.");
      return { ok: true };

    } catch (err) {
      console.error("Failed to sync push configurations:", err);
      return { ok: false, reason: 'error', detail: err?.message };
    }
  }

  async function subscribeToPush() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.warn('Push notifications not supported on this browser/device.');
      return { ok: false, reason: 'not_supported' };
    }
    if (!CONFIG.PUSH || !CONFIG.PUSH.VAPID_PUBLIC_KEY) {
      console.warn('No VAPID public key configured — push notifications disabled.');
      return { ok: false, reason: 'not_configured' };
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        console.warn('Notification permission not granted.');
        return { ok: false, reason: 'permission_denied' };
      }

      return await syncVapidSubscriptionOnLogin(state.currentUser.username);
    } catch (e) {
      console.warn('Push subscription failed:', e);
      return { ok: false, reason: 'error', detail: e?.message };
    }
  }

  async function unsubscribeFromPush() {
    try {
      if (!('serviceWorker' in navigator)) return;
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        const { data: userData } = await supabase.auth.getUser();
        if (userData?.user) {
          await supabase
            .from('user_device_tokens')
            .delete()
            .eq('user_id', userData.user.id);
        }
        await subscription.unsubscribe();
      }
    } catch (e) {
      console.warn('Push unsubscribe failed:', e);
    }
  }

  const PUSH_FAILURE_MESSAGES = {
    not_supported: 'Push notifications are not supported on this browser/device.',
    not_configured: 'Push notifications are not configured for this app yet.',
    permission_denied: 'Notification permission was not granted. Enable notifications for this site in your browser settings and try again.',
    no_auth_user: 'Could not verify your account. Try signing out and back in.',
    sw_not_ready: 'The background service worker never started. Check that sw.js is deployed and registers without errors (see the console).',
    push_subscribe_failed: 'The browser rejected the push subscription — this usually means the VAPID public key is wrong or missing.',
    db_error: 'Could not save your notification subscription to the database.',
    error: 'Something went wrong turning on notifications. Please try again.',
  };

  async function syncNotificationToggleState() {
    try {
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        DOM.notifToggle.checked = false;
        DOM.notifToggle.disabled = true;
        return;
      }
      DOM.notifToggle.disabled = false;

      if (typeof Notification !== 'undefined' && Notification.permission === 'denied') {
        DOM.notifToggle.checked = false;
        return;
      }

      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      DOM.notifToggle.checked = !!subscription;
    } catch (e) {
      console.warn('Could not check notification status:', e);
    }
  }

  async function setNotificationsEnabled(enabled) {
    DOM.notifToggle.disabled = true;

    try {
      if (enabled) {
        const { ok, reason, detail } = await subscribeToPush();

        DOM.notifToggle.checked = ok;
        if (!ok) {
          const base = PUSH_FAILURE_MESSAGES[reason] || PUSH_FAILURE_MESSAGES.error;
          alert(detail ? `${base}\n\nDetails: ${detail}` : base);
        }
      } else {
        await unsubscribeFromPush();
        DOM.notifToggle.checked = false;
      }
    } finally {
      DOM.notifToggle.disabled = false;
    }
  }

  async function sendVapidNotificationsToOfflineStudents(senderId, messageContent, channelId) {
    try {
      if (!CONFIG.PUSH || !CONFIG.PUSH.VAPID_PUBLIC_KEY) {
        console.log('Push notifications disabled - no VAPID key');
        return;
      }

      const { data: members, error: memberError } = await supabase
        .from(CONFIG.SUPABASE.TABLES.MEMBERS)
        .select('username')
        .eq('channel_id', channelId)
        .neq('username', senderId);

      if (memberError) {
        console.error("Failed to look up channel members:", memberError.message);
        return;
      }

      const memberUsernames = (members || []).map((m) => m.username);
      if (!memberUsernames.length) {
        console.log('No other channel members to notify');
        return;
      }

      const { data: offlineStudents, error: queryError } = await supabase
        .from('user_device_tokens')
        .select('username, subscription_data, endpoint')
        .in('username', memberUsernames);

      if (queryError) {
        console.error("Failed to lookup student push destinations:", queryError.message);
        return;
      }

      if (!offlineStudents || offlineStudents.length === 0) {
        console.log('No offline students with VAPID subscriptions found');
        return;
      }

      const senderName = getDisplayName(senderId);
      const channelName = state.currentChannel?.name || 'Class';

      const payload = {
        title: `${senderName} in ${channelName}`,
        body: messageContent.length > 100 ? messageContent.substring(0, 100) + '…' : messageContent,
        icon: CONFIG.BRANDING.LOGO.PATH || '/favicon.ico',
        badge: '/favicon.ico',
        data: {
          url: window.location.href,
          type: 'chat_message',
          channel_id: channelId,
          sender: senderId
        }
      };

      console.log(`📨 Sending VAPID notifications to ${offlineStudents.length} offline students via Edge Function`);

      const { data, error } = await supabase.functions.invoke('send-push-notifications', {
        body: {
          subscriptions: offlineStudents.map(s => s.subscription_data).filter(s => s !== null),
          payload: payload
        }
      });

      if (error) {
        console.error('Edge Function error:', error);
        return;
      }

      console.log('✅ VAPID notifications sent successfully:', data);

    } catch (error) {
      console.error('Failed to send VAPID notifications:', error);
    }
  }

  // ============================================================
  // 15. EVENT BINDINGS
  // ============================================================
  DOM.loginBtn.addEventListener('click', handleLogin);
  DOM.usernameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleLogin(); }
  });
  DOM.passwordInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleLogin(); }
  });

  DOM.bottomNav.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.addEventListener('pointerup', () => goToScreen(btn.dataset.tab));
  });

  DOM.chatSearchInput.addEventListener('input', () => filterChatList(DOM.chatSearchInput.value));

  // FIX: "make the selection unselected when we click on empty space of
  // sessions panel" — e.target === DOM.channelList only matches the bare
  // container background (below the last row, or the blank area under a
  // short list); a click anywhere inside an actual .chat-row lands on
  // that row or one of its children instead, so this never fires for a
  // normal "open this chat" click. See deselectChannel().
  DOM.channelList.addEventListener('click', (e) => {
    if (e.target === DOM.channelList) deselectChannel();
  });

  DOM.backFromChat.addEventListener('click', () => goToScreen('chats'));

  // FIX: #messageInput is now an auto-growing <textarea> instead of a
  // single-line <input> (see index.html) so it can actually hold
  // multiple lines. This resizes it to fit its content on every
  // keystroke, capped by the CSS max-height (the field itself scrolls
  // internally beyond that).
  function autoGrowMessageInput() {
    if (!DOM.messageInput) return;
    // FIX: was locking in a collapsed 0px inline height whenever this ran
    // while the composer sat behind the ".chat-welcome" placeholder (no
    // channel selected yet) — a hidden (display:none) element always
    // reports scrollHeight 0, and that 0 then got written to
    // style.height and stuck around even after a channel was opened,
    // which is what made the box look clipped/shrunk. offsetParent is
    // null for anything not currently laid out, so skip measuring then;
    // selectChannel() calls this again once the composer is actually
    // visible, so it still gets sized correctly right away.
    if (DOM.messageInput.offsetParent === null) return;
    const MAX_HEIGHT = 120; // keep in sync with .composer .field max-height in styles.css
    DOM.messageInput.style.height = 'auto';
    const contentHeight = DOM.messageInput.scrollHeight;
    DOM.messageInput.style.height = `${Math.min(contentHeight, MAX_HEIGHT)}px`;
    DOM.messageInput.style.overflowY = contentHeight > MAX_HEIGHT ? 'auto' : 'hidden';
  }

  // FIX: auto-load older messages when the user scrolls to within 120px
  // of the top of the chat — the same infinite-scroll-upward pattern used
  // by WhatsApp and Telegram so history feels seamless rather than
  // requiring repeated button clicks.
  if (DOM.chatContainer) {
    DOM.chatContainer.addEventListener('scroll', () => {
      if (
        DOM.chatContainer.scrollTop < 120 &&
        state.hasOlderMessages &&
        !isLoadingOlderMessages
      ) {
        loadOlderMessages();
      }
    }, { passive: true });
  }
  DOM.backFromUpdates.addEventListener('click', () => goToScreen('chats'));
  DOM.chatDetailTitleBtn.addEventListener('click', () => {
    if (!state.currentChannel) return;
    updateProfileScreen();
    goToScreen('profile');
  });

  DOM.sendMsgBtn.addEventListener('mousedown', (e) => e.preventDefault());

  DOM.sendMsgBtn.addEventListener('click', async () => {
    const content = DOM.messageInput.value.trim();
    const file = DOM.fileInput.files[0];
    if (!content && !file) return;
    broadcastStoppedTyping();

    DOM.messageInput.value = '';
    DOM.fileInput.value = '';
    DOM.filePreview.classList.add('hidden');
    autoGrowMessageInput();

    const sent = await sendMessage(content, file);

    if (!sent && content) {
      DOM.messageInput.value = content;
      autoGrowMessageInput();
    }

    if (state.inactivityTimer) {
      clearTimeout(state.inactivityTimer);
      state.inactivityTimer = null;
    }
  });

  // FIX: on touchscreen devices, plain Enter should never send — it
  // should just insert a newline like Shift+Enter does on desktop.
  // Two reasons: (1) phones have no physical Shift key, so there'd be no
  // way to add a line break at all if Enter always sent; (2) Android
  // soft keyboards drive text entry through IME composition, where a
  // 'keydown' for Enter often doesn't fire the way it does with a
  // physical keyboard, so trying to intercept it is unreliable anyway.
  // Simplest fix: skip the interception entirely on coarse-pointer
  // (touch) devices and let the textarea's default Enter-inserts-a-
  // newline behavior happen; mobile users tap the send button instead
  // (same as WhatsApp/Telegram).
  const isTouchDevice = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;

  // FIX: was a 'keypress' listener that sent on every plain Enter with no
  // way to type a newline at all — messageInput used to be a single-line
  // <input>, which can't hold newlines regardless. Now that it's a
  // <textarea>, Enter still sends (standard chat convention) but
  // Shift+Enter is left alone so it inserts a real line break instead of
  // sending. 'keydown' (not 'keypress', which is deprecated and fires
  // after the character/newline is already inserted) so preventDefault()
  // here reliably blocks the newline on a plain Enter.
  DOM.messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !isTouchDevice) {
      e.preventDefault();
      DOM.sendMsgBtn.click();
    }
    if (state.inactivityTimer) {
      clearTimeout(state.inactivityTimer);
      state.inactivityTimer = null;
    }
  });

  DOM.messageInput.addEventListener('input', () => {
    broadcastTyping();
    autoGrowMessageInput();
  });

  // FIX: run once at startup too — otherwise the very first paint uses
  // whatever height the browser's UA stylesheet gives a fresh
  // rows="1" textarea, which is what was producing the stray scrollbar
  // on load before any typing had happened.
  autoGrowMessageInput();

  DOM.messageInput.addEventListener('focus', () => {
    if (state.inactivityTimer) {
      clearTimeout(state.inactivityTimer);
      state.inactivityTimer = null;
    }
  });

  DOM.postStatusBtn.addEventListener('click', () => openStatusComposer());
  if (DOM.postStatusFab) DOM.postStatusFab.addEventListener('click', () => openStatusComposer());

  DOM.joinLiveBtn.addEventListener('click', () => {
    if (!CONFIG.FEATURES.ENABLE_VIDEO_CONFERENCE) { alert('Video conferencing is disabled.'); return; }
    if (getLiveButtonMode() === 'hidden') { return; }
    joinLiveClass();
  });

  if (DOM.viewCalendarBtn) {
    DOM.viewCalendarBtn.addEventListener('click', () => {
      goToScreen('calendar');
      subscribeToAllSchedules();
      loadAllSchedules();
    });
  }

  if (DOM.backFromCalendar) {
    DOM.backFromCalendar.addEventListener('click', () => {
      unsubscribeFromAllSchedules();
      goToScreen('settings');
    });
  }

  if (DOM.viewAttendanceReportBtn) {
    DOM.viewAttendanceReportBtn.addEventListener('click', () => {
      goToScreen('attendance');
      initAttendanceReportScreen();
    });
  }

  if (DOM.backFromAttendance) {
    DOM.backFromAttendance.addEventListener('click', () => goToScreen('settings'));
  }

  if (DOM.attendanceReportTypeSelect) {
    DOM.attendanceReportTypeSelect.addEventListener('change', () => {
      const isIndividual = DOM.attendanceReportTypeSelect.value === 'individual';
      if (DOM.attendanceStudentFieldWrap) DOM.attendanceStudentFieldWrap.classList.toggle('hidden', !isIndividual);
      if (isIndividual && DOM.attendanceGroupSelect.value) {
        populateAttendanceStudentSelect(DOM.attendanceGroupSelect.value);
      }
    });
  }

  if (DOM.attendanceGroupSelect) {
    DOM.attendanceGroupSelect.addEventListener('change', () => {
      if (DOM.attendanceReportTypeSelect && DOM.attendanceReportTypeSelect.value === 'individual') {
        populateAttendanceStudentSelect(DOM.attendanceGroupSelect.value);
      }
    });
  }

  if (DOM.generateAttendanceReportBtn) {
    DOM.generateAttendanceReportBtn.addEventListener('click', async () => {
      const channelId = DOM.attendanceGroupSelect ? DOM.attendanceGroupSelect.value : '';
      if (!channelId) { alert('Select a group first.'); return; }
      const isIndividual = DOM.attendanceReportTypeSelect && DOM.attendanceReportTypeSelect.value === 'individual';
      const studentUsername = isIndividual && DOM.attendanceStudentSelect ? DOM.attendanceStudentSelect.value : '';
      if (isIndividual && !studentUsername) { alert('Select a student first.'); return; }
      const fromVal = DOM.attendanceFromDateInput ? DOM.attendanceFromDateInput.value : '';
      const toVal = DOM.attendanceToDateInput ? DOM.attendanceToDateInput.value : '';
      if (!fromVal || !toVal) { alert('Pick a from-date and to-date.'); return; }
      const fromDate = new Date(`${fromVal}T00:00:00`);
      const toDate = new Date(`${toVal}T00:00:00`);
      if (toDate.getTime() < fromDate.getTime()) { alert('The to-date must be on or after the from-date.'); return; }

      DOM.generateAttendanceReportBtn.disabled = true;
      const originalLabel = DOM.generateAttendanceReportBtn.innerHTML;
      DOM.generateAttendanceReportBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating…';
      try {
        const report = await computeAttendanceReport(channelId, studentUsername || null, fromDate, toDate);
        renderAttendanceReport(report);
      } catch (e) {
        console.error('computeAttendanceReport failed:', e);
        alert('Could not generate the report: ' + (e.message || e));
      } finally {
        DOM.generateAttendanceReportBtn.disabled = false;
        DOM.generateAttendanceReportBtn.innerHTML = originalLabel;
      }
    });
  }

  if (DOM.downloadAttendancePdfBtn) {
    DOM.downloadAttendancePdfBtn.addEventListener('click', () => {
      if (!lastAttendanceReport) { alert('Generate a report first.'); return; }
      generateAttendancePdf(lastAttendanceReport);
    });
  }

  // FIX: root cause of "why is there a cross button when there's a
  // meeting end button available" (per-request follow-up) — the outer X
  // button is gone now. There's no separate "leave my own view" control
  // in this toolbar at all; leaving a call is meant to happen through
  // PlugNmeet's own leave/end control inside the iframe (see the
  // "PLUGNMEET SESSION-ENDED DETECTION" section below for how the app
  // notices that and returns to the chat automatically). "End for
  // Everyone" remains the one explicit, admin-only control in this outer
  // toolbar.
  if (DOM.endLiveSessionBtn) {
    DOM.endLiveSessionBtn.addEventListener('click', () => endLiveSessionForEveryone());
  }

  // FIX: root cause of "screen is still at [PlugNmeet's own 'meeting has
  // ended'] page when the meeting is ended by any teacher or admin" —
  // PlugNmeet's own logout_url redirect (above) turns out not to fire on
  // every disconnect path it has (see the detailed comment above
  // PLUGNMEET_SESSION_ENDED_MARKER), so it can't be relied on as the ONLY
  // way back to the chat. #returnToChatBtn is a plain, always-works
  // fallback: it never has to read anything from inside PlugNmeet's
  // (possibly stuck) iframe — it just runs the same closeLiveSession()
  // this app already uses for every other end-of-call path. It only ends
  // the call for the person clicking it, same as PlugNmeet's own
  // leave/end control would; it does not affect anyone else's call.
  if (DOM.returnToChatBtn) {
    DOM.returnToChatBtn.addEventListener('click', () => closeLiveSession());
  }

  // See the "PLUGNMEET SESSION-ENDED DETECTION" section (11b) above —
  // handleVideoIframeLoad() is what actually closes #videoContainer once
  // PlugNmeet redirects the iframe home after a disconnect.
  if (DOM.videoIframe) {
    DOM.videoIframe.addEventListener('load', handleVideoIframeLoad);
  }

  // FIX: root cause of "user can't see the buttons for minimizing/
  // maximizing in live meeting so they can text in group when needed" —
  // #minimizeVideoBtn didn't exist before, so there was nothing to wire
  // up. This just flips state.videoMinimized via setVideoMinimized() —
  // same button doubles as "maximize" once minimized (see its icon swap
  // in setVideoMinimized()) — leaving the call itself completely alone.
  if (DOM.minimizeVideoBtn) {
    DOM.minimizeVideoBtn.addEventListener('click', () => {
      setVideoMinimized(!state.videoMinimized);
    });
  }

  // ============================================================
  // NOUS_COMPLEX_PLUGNMEET_HEADER_BRIDGE
  // ============================================================
  // Lets a Minimize/Maximize and an "End for Everyone" button, injected
  // directly into PlugNmeet's own header UI (client/dist/index.html on the
  // Oracle server — search that file for NOUS_COMPLEX_HEADER_CONTROLS),
  // reach the exact same setVideoMinimized()/endLiveSessionForEveryone()
  // this app's own toolbar buttons already use. PlugNmeet renders in a
  // cross-origin iframe (meet.nouscomplex.com), so postMessage is the only
  // channel a button drawn inside it has back to this page — this listens
  // for that.
  //
  // Security: event.origin is checked against PlugNmeet's real origin so a
  // malicious page can't forge these commands by embedding this app and
  // posting fake messages. The "nc_role=admin" flag joinLiveClass() below
  // appends to the join URL only controls whether PlugNmeet's injected
  // script *draws* the End-for-Everyone button — it's just a URL a student
  // could edit in devtools, so it is NOT trusted as the real permission
  // check here. state.isAdmin (this session's actual, server-verified
  // role) is the real gate, same as the app's own #endLiveSessionBtn.
  window.addEventListener('message', (event) => {
    if (event.origin !== 'https://meet.nouscomplex.com') return;
    const data = event.data;
    if (!data || data.source !== 'nous-complex-plugnmeet') return;
    if (data.type === 'nous-minimize') {
      setVideoMinimized(true);
    } else if (data.type === 'nous-maximize') {
      setVideoMinimized(false);
    } else if (data.type === 'nous-end-for-everyone') {
      if (state.isAdmin) endLiveSessionForEveryone();
    }
  });

  // FIX: root cause of "why is the minimized meeting not movable and
  // resizable" — beginPipDrag()/beginPipResize() (see the "VIDEO PIP
  // DRAG + RESIZE" section above) existed nowhere to attach to; the pip
  // was purely CSS-positioned with no gesture handling at all. Pointer
  // Events (not mouse/touch separately) so this works the same with a
  // mouse, trackpad, or a finger on mobile. pointerdown starts a gesture
  // and captures the pointer on the SAME element (setPointerCapture in
  // beginPipDrag/beginPipResize) so pointermove/pointerup keep firing on
  // it even once the finger/cursor drifts outside the small toolbar or
  // resize grip — without that capture, a fast drag would "lose" the
  // gesture the instant the pointer left those tiny hit areas.
  if (DOM.videoToolbar) {
    DOM.videoToolbar.addEventListener('pointerdown', beginPipDrag);
    DOM.videoToolbar.addEventListener('pointermove', onPipDragMove);
    DOM.videoToolbar.addEventListener('pointerup', endPipDrag);
    DOM.videoToolbar.addEventListener('pointercancel', endPipDrag);
  }
  if (DOM.videoResizeHandle) {
    DOM.videoResizeHandle.addEventListener('pointerdown', beginPipResize);
    DOM.videoResizeHandle.addEventListener('pointermove', onPipResizeMove);
    DOM.videoResizeHandle.addEventListener('pointerup', endPipResize);
    DOM.videoResizeHandle.addEventListener('pointercancel', endPipResize);
  }
  // Re-clamp into view on rotation/resize so the pip can't get stranded
  // off-screen (e.g. a phone rotated after being dragged near an edge).
  window.addEventListener('resize', () => {
    if (!state.videoMinimized) return;
    const offset = pipContainerOffset();
    applyPipRect(clampPipRect(offset.left, offset.top, offset.width, offset.height));
  });

  DOM.fileInput.addEventListener('change', function() {
    const file = this.files[0];
    if (!file) { DOM.filePreview.classList.add('hidden'); return; }
    if (!isCompressibleImageType(file) && file.size > CONFIG.UPLOAD.MAX_FILE_SIZE) {
      alert(`File exceeds ${CONFIG.UPLOAD.MAX_FILE_SIZE / (1024 * 1024)}MB limit.`);
      this.value = '';
      DOM.filePreview.classList.add('hidden');
      return;
    }
    DOM.filePreviewName.textContent = file.name;
    DOM.filePreview.classList.remove('hidden');
    
    if (state.inactivityTimer) {
      clearTimeout(state.inactivityTimer);
      state.inactivityTimer = null;
    }
  });

  DOM.filePreviewRemove.addEventListener('click', () => {
    DOM.fileInput.value = '';
    DOM.filePreview.classList.add('hidden');
  });

  async function handleCreateChannel() {
    const name = prompt('Enter new channel name:');
    if (name) await createChannel(name);
  }
  DOM.createChannelBtn.addEventListener('click', handleCreateChannel);

  function toggleAdminPanel(toggleBtn, panelEl) {
    if (!toggleBtn || !panelEl) return;
    const willShow = panelEl.classList.contains('hidden');
    panelEl.classList.toggle('hidden', !willShow);
    toggleBtn.setAttribute('aria-expanded', willShow ? 'true' : 'false');
  }
  if (DOM.addUserToggleBtn) {
    DOM.addUserToggleBtn.addEventListener('click', () => {
      toggleAdminPanel(DOM.addUserToggleBtn, DOM.adminCreateUserCard);
    });
  }
  if (DOM.manageUsersToggleBtn) {
    DOM.manageUsersToggleBtn.addEventListener('click', () => {
      toggleAdminPanel(DOM.manageUsersToggleBtn, DOM.adminUserManagementCard);
    });
  }

  DOM.generatePasswordBtn.addEventListener('click', () => {
    DOM.newUserPassword.value = generatePassword();
  });
  DOM.createUserBtn.addEventListener('click', () => {
    createUserAccount(
      DOM.newUserUsername.value.trim(),
      DOM.newUserDisplayName.value.trim(),
      DOM.newUserRole.value,
      DOM.newUserPassword.value.trim()
    );
  });

  DOM.loadUserBtn.addEventListener('click', () => {
    loadUserForEdit(DOM.manageUserSearch.value);
  });

  if (DOM.closeUserEditBtn) {
    DOM.closeUserEditBtn.addEventListener('click', () => {
      closeUserEditForm();
    });
  }

  DOM.manageUserSearch.addEventListener('input', () => {
    renderRegisteredUsersList();
  });

  DOM.updateUserBtn.addEventListener('click', async () => {
    const currentUser = DOM.editUsername.value;
    const newUser = DOM.editNewUsername.value || currentUser;
    const displayName = DOM.editDisplayName.value || currentUser;
    const role = DOM.editRole.value;
    const password = DOM.editPassword.value;

    DOM.updateUserBtn.disabled = true;
    try {
      await updateUserAccount(currentUser, newUser, displayName, role, password);
    } finally {
      DOM.updateUserBtn.disabled = false;
    }
  });

  DOM.deleteUserBtn.addEventListener('click', () => {
    deleteUserAccount(DOM.editUsername.value);
  });

  DOM.manageUserGroupsBtn.addEventListener('click', () => {
    openGroupAssignmentModal(DOM.editUsername.value);
  });

  if (DOM.scheduleTeacherSelect) {
    DOM.scheduleTeacherSelect.addEventListener('change', () => {
      DOM.scheduleTeacherInput.value = DOM.scheduleTeacherSelect.value;
    });
  }

  DOM.setScheduleBtn.addEventListener('click', async () => {
    const sameTime = !DOM.scheduleSameTimeCheckbox || DOM.scheduleSameTimeCheckbox.checked;
    const defaultStart = DOM.scheduleStartTimeInput.value;
    const defaultDuration = parseInt(DOM.scheduleDurationInput.value, 10);
    const defaultRecord = !!(DOM.scheduleRecordCheckbox && DOM.scheduleRecordCheckbox.checked);

    // FIX: "add record this session option for individual session instead
    // of whole group" — record is now read per date: the shared checkbox
    // in "same time for every date" mode, or each date's own checkbox
    // (schedulePerDateOverrides, set by renderSchedulePerDateList()'s
    // listeners) once per-date customization is on. A date that was never
    // individually touched falls back to the shared checkbox's value,
    // same as start/duration already do.
    const occurrences = Array.from(scheduleSelectedDates).sort().map((dateKey) => {
      if (sameTime) return { dateKey, start: defaultStart, duration: defaultDuration, record: defaultRecord };
      const override = schedulePerDateOverrides.get(dateKey);
      return {
        dateKey,
        start: override ? override.start : defaultStart,
        duration: override ? override.duration : defaultDuration,
        record: override && typeof override.record === 'boolean' ? override.record : defaultRecord,
      };
    });

    const ok = await setClassSchedule(
      DOM.scheduleTeacherInput.value.trim(),
      occurrences,
    );
    if (!ok) return;
    // FIX: this used to just blank the input directly. With the teacher
    // field now possibly showing an auto-selected single teacher or a
    // dropdown (see renderScheduleTeacherField()), blanking the
    // underlying #scheduleTeacherInput alone would leave it empty even
    // though the visible UI still shows a teacher selected — clearing it
    // first, then re-rendering, restores the correct auto-selected/
    // dropdown-synced value for the one/multiple-teacher cases, while
    // still clearing it for the "no teachers in this group yet" manual-
    // entry fallback, matching the original behavior there.
    DOM.scheduleTeacherInput.value = '';
    renderScheduleTeacherField();
    DOM.scheduleStartTimeInput.value = '';
    DOM.scheduleDurationInput.value = '45';
    if (DOM.scheduleSameTimeCheckbox) DOM.scheduleSameTimeCheckbox.checked = true;
    if (DOM.scheduleRecordCheckbox) DOM.scheduleRecordCheckbox.checked = false;
    resetScheduleSelection();
    renderScheduleCalendar();
    renderScheduleSelectedDates();
    renderSchedulePerDateList();
    updateScheduleEndPreview();
  });

  if (DOM.scheduleCalPrevBtn) {
    DOM.scheduleCalPrevBtn.addEventListener('click', () => {
      scheduleCalendarViewMonth = new Date(scheduleCalendarViewMonth.getFullYear(), scheduleCalendarViewMonth.getMonth() - 1, 1);
      renderScheduleCalendar();
    });
  }
  if (DOM.scheduleCalNextBtn) {
    DOM.scheduleCalNextBtn.addEventListener('click', () => {
      scheduleCalendarViewMonth = new Date(scheduleCalendarViewMonth.getFullYear(), scheduleCalendarViewMonth.getMonth() + 1, 1);
      renderScheduleCalendar();
    });
  }

  if (DOM.scheduleStartTimeInput && DOM.scheduleDurationInput) {
    ['input', 'change'].forEach((evt) => {
      DOM.scheduleStartTimeInput.addEventListener(evt, () => {
        updateScheduleEndPreview();
        renderSchedulePerDateList();
      });
      DOM.scheduleDurationInput.addEventListener(evt, () => {
        updateScheduleEndPreview();
        renderSchedulePerDateList();
      });
    });
  }

  if (DOM.scheduleSameTimeCheckbox) {
    DOM.scheduleSameTimeCheckbox.addEventListener('change', () => {
      renderSchedulePerDateList();
    });
  }

  DOM.assignStudentBtn.addEventListener('click', async () => {
    const username = DOM.assignStudentInput.value.trim();
    const role = DOM.assignRoleSelect.value;
    await addMemberToChannel(username, role);
    DOM.assignStudentInput.value = '';
  });

  initFormatToolbar(DOM.descFormatToolbar, DOM.channelDescInput);

  // FIX: opens the previously-always-open editor panel — see the FIX
  // comment in loadChannelDescription() above. Re-populates from the
  // currently saved description each time it's opened, so re-clicking
  // Edit after a Cancel (or after switching away and back) never shows
  // stale half-typed text from a previous session.
  DOM.channelDescEditBtn.addEventListener('click', () => {
    if (!state.currentChannel) return;
    populateRichEditor(DOM.channelDescInput, state.currentChannel.description || '');
    DOM.adminDescEdit.classList.remove('hidden');
    DOM.channelDescEditBtn.classList.add('hidden');
    DOM.channelDescInput.focus();
  });

  DOM.cancelDescEditBtn.addEventListener('click', () => {
    DOM.adminDescEdit.classList.add('hidden');
    DOM.channelDescEditBtn.classList.remove('hidden');
  });

  DOM.updateDescBtn.addEventListener('click', () => {
    if (!state.currentChannel) return;
    // updateChannelDescription() re-runs loadChannelDescription() on
    // success, which closes this panel back down and re-shows the Edit
    // button — no separate collapse call needed here.
    updateChannelDescription(state.currentChannel.id, editorToMarkerValue(DOM.channelDescInput).trim());
  });

  // FIX: was a 'keypress' listener that saved on every plain Enter — that
  // made sense back when this was a single-line <input>, but it's now a
  // contenteditable rich-text editor (see index.html) so people can
  // actually write multi-line descriptions. Plain Enter starts a new
  // line/paragraph like any normal text editor; Ctrl/Cmd+Enter is the save
  // shortcut instead. 'keydown' (not 'keypress', which is deprecated and
  // unreliable with modifier keys) so the shortcut is caught before the
  // newline would otherwise be inserted.
  DOM.channelDescInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      DOM.updateDescBtn.click();
    }
  });

  DOM.backFromMembers.addEventListener('click', () => goToScreen('profile'));
  DOM.memberSearchInput.addEventListener('input', () => renderMembers());
  DOM.profileMembersBtn.addEventListener('click', () => {
    if (!state.currentChannel) { alert('Select a channel first.'); return; }
    renderMembers();
    goToScreen('members');
  });

  DOM.backFromProfile.addEventListener('click', () => goToScreen('chatDetail'));

  // FIX: "make separate folder in share media one for images and one for
  // video" — was one combined "See All"/click pair for a mixed grid; now
  // each grid (photos/videos) has its own independent pair, each only
  // touching its own dataset.showAll flag and its own render function.
  // FIX: root cause of "See All works only for expansion not for
  // contraction" — this unconditionally set showAll to 'true', so a second
  // click (and every click after that) just re-set it to the same 'true'
  // and re-rendered the identical expanded state; there was no path back
  // to 'false' at all. Reads the current state and flips it instead.
  DOM.profileSeeAllPhotos.addEventListener('click', (e) => {
    e.preventDefault();
    const expanded = DOM.sharedPhotosGrid.dataset.showAll === 'true';
    DOM.sharedPhotosGrid.dataset.showAll = expanded ? 'false' : 'true';
    renderSharedPhotos();
  });
  DOM.sharedPhotosGrid.addEventListener('click', (e) => {
    const tile = e.target.closest('img[data-media-url]');
    if (!tile) return;
    const idx = parseInt(tile.dataset.mediaIndex, 10);
    openImageLightbox(tile.dataset.mediaUrl, state.sharedMediaUrls, Number.isNaN(idx) ? undefined : idx);
  });

  // FIX: same root cause and fix as profileSeeAllPhotos above.
  DOM.profileSeeAllVideos.addEventListener('click', (e) => {
    e.preventDefault();
    const expanded = DOM.sharedVideosGrid.dataset.showAll === 'true';
    DOM.sharedVideosGrid.dataset.showAll = expanded ? 'false' : 'true';
    renderSharedVideos();
  });
  DOM.sharedVideosGrid.addEventListener('click', (e) => {
    const tile = e.target.closest('[data-media-url]');
    if (!tile) return;
    openVideoLightbox(tile.dataset.mediaUrl);
  });

  DOM.closeStatusModal.addEventListener('click', closeStatusViewer);
  DOM.statusModal.addEventListener('click', (e) => {
    if (Date.now() < suppressStatusOpenClicksUntil) return;
    if (e.target === DOM.statusModal) closeStatusViewer();
  });
  DOM.statusPauseBtn.addEventListener('click', toggleStatusPause);

  if (DOM.statusViewerBody) {
    DOM.statusViewerBody.addEventListener('click', (e) => {
      if (Date.now() < suppressStatusOpenClicksUntil) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      const sharedLink = e.target.closest('a.msg-link, a.msg-link-preview');
      if (sharedLink) {
        e.preventDefault();
        e.stopPropagation();
        openExternalLink(sharedLink.getAttribute('href'));
      }
    });
  }

  DOM.notifToggle.addEventListener('change', () => setNotificationsEnabled(DOM.notifToggle.checked));
  DOM.darkToggle.addEventListener('change', () => {
    document.body.classList.toggle('theme-dark', DOM.darkToggle.checked);
    try { localStorage.setItem('orbit-theme', DOM.darkToggle.checked ? 'dark' : 'light'); } catch (e) { /* ignore */ }
  });
  DOM.darkToggle.checked = document.body.classList.contains('theme-dark');

  DOM.signOutBtn.addEventListener('click', handleSignOut);

  // ============================================================
  // 16. BOOTSTRAP
  // ============================================================
  setupLogos();

  if (history.replaceState) {
    history.replaceState({ orbitScreen: null }, '', location.pathname + location.search);
  }

  window.addEventListener('popstate', handleBackNavigation);

  restoreSession();
  console.log('✅ Application initialized successfully.');

})();
